"""Explicit recording-to-calibration RX frame conversions, before glove IK."""
from fnmatch import fnmatchcase
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation


def corrected_rx_orientations(quaternions, *, episode, side, sn, urdf_sha256,
                              correction_path=None):
    """Post-compose each measured RX rotation with its calibrated frame offset.

    Raw positions, confidence and source headers are untouched. Rules identify a
    known recording convention; no gesture or desired pinch distance is inferred.
    Unmatched recordings retain their exact input quaternions.
    """
    info = {'policy': 'recorded_rx_orientation', 'corrected_frames': 0,
            'recording_episode': Path(episode).name}
    if not correction_path:
        return quaternions, info
    path = Path(correction_path).expanduser().resolve()
    raw = path.read_bytes()
    config = json.loads(raw)
    if config.get('schema') != 'wuji.emf_rx_orientation_corrections.v1':
        raise ValueError(f'Unsupported EMF orientation corrections: {path}')
    matches = [rule for rule in config['rules']
               if rule['side'] == side and rule['sn'] == sn
               and fnmatchcase(Path(episode).name, rule['episode_glob'])]
    if len(matches) > 1:
        raise ValueError(f'Overlapping EMF orientation rules: {episode}, {side}')
    info.update(config_path=str(path), config_sha256=hashlib.sha256(raw).hexdigest())
    if not matches:
        return quaternions, info
    rule = matches[0]
    if rule['urdf_sha256'] != urdf_sha256:
        raise ValueError(f'{side}: EMF correction requires its verified calibration URDF')
    offsets = np.asarray(rule['rx_post_rotation_xyzw'], dtype=np.float64)
    if (offsets.shape != (5, 4) or not np.isfinite(offsets).all()
            or not np.allclose(np.linalg.norm(offsets, axis=-1), 1, atol=1e-6)):
        raise ValueError('EMF RX correction must contain five unit XYZW quaternions')
    q = np.asarray(quaternions)
    result = (Rotation.from_quat(q.reshape(-1, 4)) *
              Rotation.from_quat(np.tile(offsets, (len(q), 1)))).as_quat().reshape(q.shape)
    # Preserve unaffected receivers bit for bit, including their quaternion sign.
    identity = np.all(offsets[:, :3] == 0, axis=-1)
    result[:, identity] = q[:, identity]
    info.update(policy='explicit_rx_frame_conversion', corrected_frames=len(q),
                episode_glob=rule['episode_glob'], reason=rule.get('reason'),
                rx_post_rotation_xyzw=offsets.tolist())
    return result, info
