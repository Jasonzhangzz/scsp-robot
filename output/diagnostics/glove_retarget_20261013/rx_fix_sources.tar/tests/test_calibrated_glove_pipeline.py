"""PYTHONPATH=.:utils:replay python -m unittest discover -s tests -p test_calibrated_glove_pipeline.py"""
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
import h5py
import numpy as np
from scipy.spatial.transform import Rotation
from wuji_retarget.glove_ik import recorded_world_from_wrist
from wuji_retarget.sdk_retarget import sequence_from_sdk

ROOT = Path(__file__).resolve().parents[1]
COLLECTION = Path('/mnt/jfs/x2robot-prod/x2robot-data/collection/18/RP001_VR/'
    'XRRD11ZD2604070080/20261008170930-stack_cup_random_CQQ_rpAAAA')
EPISODE = COLLECTION / (COLLECTION.name + '@MASTER_SLAVE_MODE@2026_10_08_17_19_04')


class CalibratedFrameTests(unittest.TestCase):
    def test_current_extrinsics_replace_capture_wrist_frame(self):
        """Capture used a different wrist->TX offset; world TX stays fixed."""
        with tempfile.TemporaryDirectory() as directory:
            episode = Path(directory)
            with h5py.File(episode/'wuji_glove_tf.h5', 'w') as h:
                tf = h.create_group('tf_static')
                tf['parent_frame'] = np.array(['r_wrist', 'r_wrist'], dtype=h5py.string_dtype())
                tf['child_frame'] = np.array(['r_hand_emf_tx'] * 2, dtype=h5py.string_dtype())
                tf['timestamps'] = [1, 15]
                tf['translation'] = [[.01, .02, .03], [.04, .02, .03]]
                tf['rotation'] = [[0, 0, 0, 1]] * 2
            with h5py.File(episode/'source.h5', 'w') as h:
                group = h.create_group('right')
                group['hand_skeleton/joint_names'] = np.array(['wrist'], dtype=h5py.string_dtype())
                group['hand_skeleton/world/position'] = [[[1, 2, 3]], [[1, 2, 3]]]
                rotation = Rotation.from_euler('z', np.pi/2).as_quat()
                group['hand_skeleton/world/orientation_xyzw'] = np.tile(rotation, (2, 1, 1))
                current_tx_from_wrist = np.eye(4)
                current_tx_from_wrist[:3, 3] = [-.1, -.2, -.3]
                result = recorded_world_from_wrist(episode, group, 'right',
                    np.array([10, 20]), current_tx_from_wrist)
            np.testing.assert_allclose(result[:, :3, 3],
                [[1.18, 1.91, 2.73], [1.18, 1.94, 2.73]], atol=1e-12)

    def test_alignment_sequence_uses_solved_bones(self):
        from wuji_retarget.hand_retarget import SkeletonSequence
        old = {side: np.zeros((2, 21, 3)) for side in ('left', 'right')}
        sequence = SkeletonSequence(np.array([2, 5]), np.array([0., .1]),
            old, {}, {}, {})
        commands = {}
        for side in old:
            commands[side+'_skeleton_position_world'] = np.arange(126).reshape(2, 21, 3)
            commands[side+'_skeleton_orientation_world_xyzw'] = np.tile([0, 0, 0, 1], (2, 21, 1))
        updated = sequence_from_sdk(sequence, commands)
        np.testing.assert_array_equal(updated.positions['right'], commands['right_skeleton_position_world'])
        np.testing.assert_array_equal(updated.tip_positions['right'], updated.positions['right'][:, [4, 8, 12, 16, 20]])
        np.testing.assert_array_equal(sequence.positions['right'], 0)
        np.testing.assert_array_equal(updated.frame_indices, [2, 5])


@unittest.skipUnless((EPISODE/'wuji_glove_offline.h5').is_file() and
                    (ROOT/'hand_models/cqq_v2/right_hand.urdf').is_file(),
                    'CQQ regression fixture unavailable')
class RecordedCalibrationTests(unittest.TestCase):
    def test_rx_conversion_relaxed_start_and_synchronized_world_bones(self):
        from wuji_retarget.emf_offline import compute_episode
        with tempfile.TemporaryDirectory(prefix='unrelated_batch_staging_') as directory:
            staging = Path(directory)
            for name in ('wuji_glove_offline.h5', 'wuji_glove_tf.h5', EPISODE.name+'.json'):
                (staging/name).symlink_to(EPISODE/name)
            native, camera, info = compute_episode(staging, glove_urdfs={
                side: ROOT/f'hand_models/cqq_v2/{side}_hand.urdf'
                for side in ('left', 'right')},
                glove_emf_rx_corrections=ROOT/'hand_models/cqq_v2/emf_rx_corrections.json')
        points = native['right_skeleton_position']
        # User identifies this first recorded frame as naturally relaxed.
        distance = np.linalg.norm(points[:, 4] - points[:, 8], axis=-1)
        self.assertAlmostEqual(float(distance[0]), .049054667, places=6)
        self.assertEqual(info['sides']['right']['emf_rx_orientation']['policy'],
                         'explicit_rx_frame_conversion')
        self.assertEqual(info['sides']['left']['emf_rx_orientation']['corrected_frames'], 0)
        with h5py.File(EPISODE/'wuji_glove_offline.h5', 'r', locking=False) as h:
            for side in ('left', 'right'):
                np.testing.assert_array_equal(native[side+'_source_timestamp_ns'], h[side+'/source_timestamp_ns'][:])
                self.assertEqual(len(native[side+'_hand_q']), len(h[side+'/source_seq']))
                self.assertTrue(np.isfinite(native[side+'_hand_q']).all())
                indices = camera[side+'_native_frame_indices']
                np.testing.assert_array_equal(camera[side+'_hand_q'], native[side+'_hand_q'][indices])
                world = camera[side+'_skeleton_position_world']
                local = camera[side+'_skeleton_position']
                np.testing.assert_allclose(np.linalg.norm(world[:, 4]-world[:, 8], axis=-1),
                    np.linalg.norm(local[:, 4]-local[:, 8], axis=-1), atol=2e-8)
                self.assertEqual(info['sides'][side]['ik_initialization']['synthetic_frames'], 0)
        self.assertEqual(len(camera['frame_indices']), 399)


if __name__ == '__main__':
    unittest.main()
