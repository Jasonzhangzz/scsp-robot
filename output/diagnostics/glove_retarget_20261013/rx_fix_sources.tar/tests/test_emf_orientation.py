import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from wuji_retarget.emf_orientation import corrected_rx_orientations


class RxOrientationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)/'rx.json'
        self.path.write_text(json.dumps({
            'schema': 'wuji.emf_rx_orientation_corrections.v1',
            'rules': [{'episode_glob': 'collection@2026_10_08_*',
                       'side': 'right', 'sn': 'recorded_sn', 'urdf_sha256': 'verified',
                       'rx_post_rotation_xyzw': [[0,1,0,0]]*3+[[0,0,0,1]]*2}]}))
        # Nontrivial rotation verifies receiver-frame (post) rather than TX-frame
        # (pre) composition; the two give different answers.
        self.q = np.tile(np.array([.2, .3, .4, .5])/np.sqrt(.54), (2,5,1))
        self.kw = dict(episode='collection@2026_10_08_17_19_04', side='right',
                       sn='recorded_sn', urdf_sha256='verified', correction_path=self.path)

    def test_post_rotation_and_raw_payload_preservation(self):
        original = self.q.copy()
        result, info = corrected_rx_orientations(self.q, **self.kw)
        expected = self.q[:,:3][:,:,[2,3,0,1]]*[-1,1,1,-1]
        np.testing.assert_allclose(result[:,:3], expected, atol=1e-15)
        np.testing.assert_array_equal(result[:,3:], self.q[:,3:])
        np.testing.assert_array_equal(self.q, original)
        self.assertEqual(info['corrected_frames'], 2)

    def test_other_day_side_and_device_are_unchanged(self):
        for key, value in [('episode','collection@2026_10_09_10_23_40'),
                           ('side','left'), ('sn','another_sn')]:
            result, info = corrected_rx_orientations(self.q, **{**self.kw, key:value})
            np.testing.assert_array_equal(result, self.q)
            self.assertEqual(info['corrected_frames'], 0)

    def test_wrong_calibration_hash_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'verified calibration URDF'):
            corrected_rx_orientations(self.q, **{**self.kw, 'urdf_sha256':'different'})


if __name__ == '__main__':
    unittest.main()
