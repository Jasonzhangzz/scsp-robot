import json
from pathlib import Path
import tempfile
import unittest
import h5py
import numpy as np
from wuji_retarget.emf_offline import (load_model_config, solve_native, align_camera,
                                      validate_stream, fingerprint, _nearest_action_index,
                                      longest_consecutive_dropped, trajectory_frame_loss,
                                      DEFAULT_CONFIG, model_config_from_urdfs)

SOURCE=Path('/mnt/jfs/x2robot-prod/x2robot-data/collection/18/RP001_VR/XRRD11ZD2604070080/20260918180420-pick_doll_CQQ_rpAAAA/20260918180420-pick_doll_CQQ_rpAAAA@MASTER_SLAVE_MODE@2026_09_18_18_09_17')

@unittest.skipUnless((SOURCE/'wuji_glove_offline.h5').exists(),'recorded EMF fixture unavailable')
class EmfOfflineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.ep=Path(self.temp.name)/'sample';self.ep.mkdir()
        # Only raw EMF fields: no stored skeleton or old retarget output exists.
        with h5py.File(SOURCE/'wuji_glove_offline.h5','r',locking=False) as src, h5py.File(self.ep/'wuji_glove_offline.h5','w') as dst:
            for k,v in src.attrs.items():dst.attrs[k]=v
            for side in ('left','right'):
                for key in ('emf_poses/position','emf_poses/orientation_xyzw','emf_poses/confidence',
                            'source_timestamp_ns','source_seq','source_frame_id','action_timestamp_ns'):
                    dst.create_dataset(side+'/'+key,data=src[side+'/'+key][:8],dtype=src[side+'/'+key].dtype)
        self.cfg = (load_model_config() if DEFAULT_CONFIG.is_file() else
            model_config_from_urdfs({'right': Path(__file__).resolve().parents[1] /
                                    'hand_models/cqq_v2/right_hand.urdf'}))

    def test_native_matches_direct_sdk_without_stored_skeleton(self):
        from wuji_sdk import (WujiGlove,RetargetSession,HandModel,Handedness,
                              FrameHeader,EmfPoseArray,EmfPose,Pose,Quaternion)
        native,info,_=solve_native(self.ep,self.cfg)
        self.assertEqual(info['sides']['right']['urdf_source'],'override')
        self.assertEqual(info['sides']['left']['urdf_source'],'builtin_default')
        for side in ('left','right'):
            pipe=WujiGlove.offline_pipeline(sn=info['sides'][side]['sn'],hand_side=side,urdf_path=self.cfg.get(side+'_urdf'))
            from wuji_retarget.glove_ik import initialize_glove_ik
            with h5py.File(self.ep/'wuji_glove_offline.h5','r') as h:
                initialize_glove_ik(pipe,self.cfg.get(side+'_urdf'),side,
                    int(h[side+'/source_timestamp_ns'][0]//1000),
                    str(h[side+'/source_frame_id'].asstr()[0]))
            session=RetargetSession.for_hand(HandModel.WujiHand,
                side=Handedness.Left if side=='left' else Handedness.Right)
            with h5py.File(self.ep/'wuji_glove_offline.h5','r') as h:
                p,q,c,ts,seq,ats,ids=validate_stream(h[side],side)
            for i in range(8):
                frame=EmfPoseArray(header=FrameHeader(seq=int(seq[i]),timestamp_us=int(ts[i]//1000),frame_id=ids[i]),poses=[
                    EmfPose(pose=Pose(position=p[i,j].tolist(),orientation=Quaternion(*q[i,j].tolist())),confidence=float(c[i,j])) for j in range(5)])
                skeleton=pipe.hand_skeleton().compute(frame)
                points=np.asarray([j.pose.position for j in skeleton.joints],np.float32)
                np.testing.assert_array_equal(points,native[side+'_skeleton_position'][i])
                np.testing.assert_array_equal(session.step(points),native[side+'_hand_q'][i])

    def test_exact_payload_alignment_and_explicit_missing_frame(self):
        native,_,lookup=solve_native(self.ep,self.cfg)
        frames=[]
        with h5py.File(self.ep/'wuji_glove_offline.h5','r') as h:
            for row in range(3):
                frame={'timestamp':int(h['left/action_timestamp_ns'][row])}
                for side,offset in (('left',0),('right',1)):
                    p,q,c,*_=validate_stream(h[side],side);i=row+offset
                    frame[side+'_glove_emf_poses']={'poses':[{'pose':{
                        'position':dict(zip('xyz',p[i,j].tolist())),
                        'orientation':dict(zip('xyzw',q[i,j].tolist()))},'confidence':float(c[i,j])} for j in range(5)]}
                frames.append(frame)
        frames[1]['right_glove_emf_poses']['poses'][0]['pose']['position']['x']+=1
        with h5py.File(self.ep/'wuji_glove_offline.h5','r') as h:
            left_ts=h['left/action_timestamp_ns'][:]
            right_ts=h['right/action_timestamp_ns'][:]
        far=json.loads(json.dumps(frames[0]))
        far['timestamp']=int(left_ts[-1])+10_000_000_000
        for side in ('left','right'):
            far[side+'_glove_emf_poses']['poses'][0]['pose']['position']['x']+=1
        frames.append(far)
        (self.ep/'sample.json').write_text(json.dumps({'data':frames}))
        camera,info=align_camera(self.ep,native,lookup)
        nearest_right,_=_nearest_action_index(right_ts,int(left_ts[1]))
        self.assertEqual(info['dropped_frame_indices'],[3])
        self.assertIn(1,info['nearest_action_frame_indices']['right'])
        np.testing.assert_array_equal(camera['frame_indices'],[0,1,2])
        np.testing.assert_array_equal(camera['right_hand_q'],native['right_hand_q'][[1,nearest_right,3]])
        np.testing.assert_array_equal(camera['left_hand_q'],native['left_hand_q'][[0,1,2]])

    def test_world_emf_input_rejected(self):
        with h5py.File(self.ep/'wuji_glove_offline.h5','r+') as h:
            h['right/source_frame_id'][0]='world'
            with self.assertRaises(ValueError):validate_stream(h['right'],'right')

    def test_model_hash_is_enforced(self):
        config=dict(self.cfg)
        config['right_urdf']=self.cfg['right_urdf'];config['right_sha256']='wrong'
        p=self.ep/'config.json';p.write_text(json.dumps(config))
        with self.assertRaises(ValueError):load_model_config(p)

class NearestActionAlignmentTests(unittest.TestCase):
    def test_inexact_payload_within_one_period_is_kept(self):
        n = 4
        period = 16_000_000
        native = {}
        lookups = {}
        for side in ('left', 'right'):
            position = np.zeros((n, 5, 3), dtype=np.float64)
            position[:, :, 0] = np.arange(n)[:, None]
            orientation = np.zeros((n, 5, 4), dtype=np.float64)
            orientation[:, :, 3] = 1
            confidence = np.ones((n, 5), dtype=np.float64)
            times = np.arange(n, dtype=np.int64) * period
            native[f'{side}_action_timestamp_ns'] = times
            native[f'{side}_source_timestamp_ns'] = times
            native[f'{side}_hand_q'] = np.arange(n * 20, dtype=np.float64).reshape(n, 20) + (0 if side == 'left' else 100)
            native[f'{side}_skeleton_position'] = position
            native[f'{side}_skeleton_orientation_xyzw'] = orientation
            native[f'{side}_skeleton_confidence'] = confidence
            native[f'{side}_hand_q_names'] = np.asarray([f'{side}_{i}' for i in range(20)])
            lookup = {}
            for index in range(n):
                lookup.setdefault(fingerprint(position[index], orientation[index], confidence[index]), []).append(index)
            lookups[side] = lookup

        def pose_message(position_row, orientation_row, confidence_row):
            return {'poses': [{
                'pose': {
                    'position': dict(zip('xyz', position_row[joint].tolist())),
                    'orientation': dict(zip('xyzw', orientation_row[joint].tolist())),
                },
                'confidence': float(confidence_row[joint]),
            } for joint in range(5)]}

        frames = []
        for index in (0, 1):
            frame = {'timestamp': int(native['left_action_timestamp_ns'][index])}
            for side in ('left', 'right'):
                frame[f'{side}_glove_emf_poses'] = pose_message(
                    native[f'{side}_skeleton_position'][index],
                    native[f'{side}_skeleton_orientation_xyzw'][index],
                    native[f'{side}_skeleton_confidence'][index],
                )
            frames.append(frame)
        frames[1]['right_glove_emf_poses']['poses'][0]['pose']['position']['x'] += 1
        far = json.loads(json.dumps(frames[0]))
        far['timestamp'] = int(native['left_action_timestamp_ns'][-1]) + 10 * period
        for side in ('left', 'right'):
            far[f'{side}_glove_emf_poses']['poses'][0]['pose']['position']['x'] += 1
        frames.append(far)
        with tempfile.TemporaryDirectory() as directory:
            episode = Path(directory)
            (episode / 'sample.json').write_text(json.dumps({'data': frames}))
            camera, info = align_camera(episode, native, lookups, episode / 'sample.json')
        nearest, delta = _nearest_action_index(native['right_action_timestamp_ns'], frames[1]['timestamp'])
        self.assertLessEqual(delta, period)
        self.assertEqual(info['dropped_frame_indices'], [2])
        self.assertEqual(info['nearest_action_frame_indices']['right'], [1])
        self.assertEqual(info['nearest_action_frame_indices']['left'], [])
        np.testing.assert_array_equal(camera['frame_indices'], [0, 1])
        np.testing.assert_array_equal(camera['left_hand_q'], native['left_hand_q'][[0, 1]])
        np.testing.assert_array_equal(camera['right_hand_q'], native['right_hand_q'][[0, nearest]])
        self.assertEqual(str(camera['hand_sdk_step_policy']), 'native_emf_then_nearest_action_timestamp')


class TrajectoryFrameLossTests(unittest.TestCase):
    def test_isolated_and_trailing_drops_keep_the_trajectory(self):
        self.assertEqual(longest_consecutive_dropped([4, 9, 20]), 1)
        self.assertIsNone(trajectory_frame_loss([4, 9, 20]))
        self.assertIsNone(trajectory_frame_loss([]))

    def test_long_hole_skips_the_trajectory(self):
        dropped = list(range(1938, 1958))
        self.assertEqual(longest_consecutive_dropped(dropped), 20)
        reason = trajectory_frame_loss(dropped)
        self.assertIn("longest consecutive run 20", reason)
        self.assertIn("skipping trajectory", reason)


if __name__=='__main__':unittest.main()
