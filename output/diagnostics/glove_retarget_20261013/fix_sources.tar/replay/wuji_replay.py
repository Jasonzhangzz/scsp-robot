"""Run Wuji hand retargeting, Laplacian refinement, and arm IK.

Example::

    conda run -n pi0 python -m wuji_replay \
        --test_data /path/to/episode.json
"""

from __future__ import annotations

import argparse
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
from typing import Mapping, Sequence
import xml.etree.ElementTree as ET

import numpy as np
from scipy.spatial.transform import Rotation

_THIS_FILE = Path(__file__).resolve()
_REPO_ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "assets").is_dir() and (parent / "thirdparty").is_dir()
)
for _extra in (_REPO_ROOT, _REPO_ROOT / "replay", _REPO_ROOT / "utils"):
    _text = str(_extra)
    if _text not in sys.path:
        sys.path.insert(0, _text)

from adapters import wuji_glove_utils as wg
from arm_ik import solve_arm_q_trajectory
from optimize import (
    DEFAULT_COMPOSITE_URDF,
    DEFAULT_TABLE_NORMAL_WEIGHT,
    OptimizationResult,
    apply_world_to_base,
    optimize_first_frame_fixed_rotation,
    optimize_first_frame_lbfgsb,
    optimize_first_frame_projected_lm,
    table_normal_tilt_rad,
)
from retarget_seed import (
    TIANJI_FIRST_FRAME_PALM_NORMAL_BASE,
    correct_first_frame_wrist_rotations_facing_table,
    is_tianji_urdf,
    world_to_base_rotation_for_first_frame_palms,
)
from calibrated.laplacian_optimizer import DEFAULT_COLLISION_CONFIG
from tactile.contact_detect import FINGER_NAMES, detect_contacts
from motion_planning import plan_replay
from calibrated.topo import load_or_build_topology_trajectory
from wuji2_retarget.hand_retarget import (
    DEFAULT_HAND_URDFS,
    load_world_skeletons,
    resolve_hand_urdfs_for_composite,
    retarget_episode,
    smooth_world_skeleton_sequence,
)


_ARM_BASE_LINKS = {
    "left": "left_arm_base_link",
    "right": "right_arm_base_link",
}


def _fixed_base_to_link_transform(urdf: str | Path, target_link: str) -> np.ndarray:
    """Read a fixed ``base_link -> target_link`` chain from a URDF."""

    root = ET.parse(urdf).getroot()
    child_to_joint = {}
    for joint in root.findall("joint"):
        child = joint.find("child")
        if child is not None:
            child_to_joint[child.attrib["link"]] = joint

    chain = []
    link = target_link
    while link != "base_link":
        try:
            joint = child_to_joint[link]
        except KeyError as exc:
            raise ValueError(
                f"No URDF chain from base_link to {target_link!r}"
            ) from exc
        if joint.attrib.get("type", "fixed") != "fixed":
            raise ValueError(
                f"base_link to {target_link!r} contains non-fixed joint "
                f"{joint.attrib.get('name')!r}"
            )
        chain.append(joint)
        parent = joint.find("parent")
        if parent is None:
            raise ValueError(f"Joint {joint.attrib.get('name')!r} has no parent")
        link = parent.attrib["link"]

    transform = np.eye(4, dtype=np.float64)
    for joint in reversed(chain):
        origin = joint.find("origin")
        xyz = np.fromstring(
            "0 0 0" if origin is None else origin.attrib.get("xyz", "0 0 0"),
            sep=" ",
            dtype=np.float64,
        )
        rpy = np.fromstring(
            "0 0 0" if origin is None else origin.attrib.get("rpy", "0 0 0"),
            sep=" ",
            dtype=np.float64,
        )
        if xyz.shape != (3,) or rpy.shape != (3,):
            raise ValueError(
                f"Joint {joint.attrib.get('name')!r} has invalid xyz/rpy"
            )
        joint_transform = np.eye(4, dtype=np.float64)
        joint_transform[:3, :3] = Rotation.from_euler("xyz", rpy).as_matrix()
        joint_transform[:3, 3] = xyz
        transform = transform @ joint_transform
    return transform


def _urdf_tf_metadata(urdf: str | Path) -> dict[str, np.ndarray]:
    """Return auditable arm-root TF metadata for the replay output."""

    path = Path(urdf).expanduser().resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    result = {
        "composite_urdf_path": np.asarray(str(path)),
        "composite_urdf_sha256": np.asarray(digest),
        "arm_base_tf_source": np.asarray("selected composite URDF fixed-joint chain"),
    }
    for side, link in _ARM_BASE_LINKS.items():
        result[f"base_to_{side}_arm_base_transform"] = (
            _fixed_base_to_link_transform(path, link)
        )
    return result


def _initial_position_from_arm_base_midpoint(
    tf_metadata: Mapping[str, np.ndarray],
    delta: Sequence[float] | np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Resolve a user workspace delta relative to the two arm-base midpoint."""

    delta_value = np.asarray(delta, dtype=np.float64)
    if delta_value.shape != (3,) or not np.all(np.isfinite(delta_value)):
        raise ValueError("initial_position delta must contain three finite values")
    arm_base_positions = np.stack(
        [
            np.asarray(
                tf_metadata[f"base_to_{side}_arm_base_transform"],
                dtype=np.float64,
            )[:3, 3]
            for side in ("left", "right")
        ]
    )
    midpoint = arm_base_positions.mean(axis=0)
    return midpoint + delta_value, midpoint


DEFAULT_HAND_PIPELINE = "official"
DEFAULT_LAPLACIAN_SOLVER = "hjcd"
DEFAULT_LAPLACIAN_ITERATIONS = {"bae": 30, "hjcd": 30}
# Base-link XYZ delta from the URDF-derived midpoint of both arm-base links.
# This is the ordinary wrist-midpoint TF calibration used by the recent
# replay version; it is deliberately independent of thumb/contact points.
DEFAULT_INITIAL_POSITION = (0.43, 0.0, 0.25)
DEFAULT_CONTACT_TARGET_DISTANCE_M = 0.001
DEFAULT_CONTACT_PINCH_DISTANCE_WEIGHT = 3_000_000.0
_UNIFIED_Q_VELOCITY_COST = 1.0
_UNIFIED_WRIST_VELOCITY_POSITION_COST = 200.0
_UNIFIED_WRIST_VELOCITY_ORIENTATION_COST = 5.0
_UNIFIED_Q_ACCELERATION_COST = 5.0
_UNIFIED_WRIST_ACCELERATION_POSITION_COST = 1000.0
_UNIFIED_WRIST_ACCELERATION_ORIENTATION_COST = 20.0
_ARM_Q_VELOCITY_COST = 1.0
_ARM_Q_ACCELERATION_COST = 5.0
HAND_PIPELINES = ("official", "lbfgs_mink", "unified_gn")
LAST_REPLAY: dict[str, np.ndarray] | None = None
_LAST_REPLAY_LOCAL = threading.local()


def _alignment_workspace_points(
    sequence,
    pinch_mask: np.ndarray,
    *,
    retargeted_tip_positions_world: np.ndarray | None = None,
    retargeted_joint_names: Sequence[str] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Return legacy diagnostic points for replay metadata.

    Point 0 is the right-thumb tip at the first frame of the first sufficiently
    long pinch run; point 1 is the first-frame midpoint of the two wrists.  If
    the retargeted robot tip positions are supplied, they are used for point 0
    so the anchor refers to the actual robot thumb-tip link rather than a raw
    glove tracker point.  The
    These fields are retained for archive compatibility only.  The active TF
    solver uses ordinary wrist-midpoint calibration and does not consume them.
    """
    left = np.asarray(sequence.positions["left"], dtype=np.float64)
    right = np.asarray(sequence.positions["right"], dtype=np.float64)
    wrist_index = list(wg.JOINT_ORDER).index("wrist")
    thumb_index = list(wg.JOINT_ORDER).index("thumb_tip")
    midpoint0 = 0.5 * (left[0, wrist_index] + right[0, wrist_index])
    tips = np.asarray(sequence.tip_positions["right"], dtype=np.float64)
    if tips.ndim != 3 or tips.shape[0] != len(right) or tips.shape[1] < 1:
        tips = right[:, thumb_index : thumb_index + 1]
    thumb = tips[:, 0]
    # Prefer the scaled robot target when available.  The raw glove thumb tip
    # and the Wuji ``right_finger1_tip_link`` are not coincident after hand
    # retargeting, so anchoring the former does not constrain the latter.
    if retargeted_tip_positions_world is not None:
        candidate = np.asarray(retargeted_tip_positions_world, dtype=np.float64)
        if candidate.ndim == 3 and candidate.shape[0] == len(right) and candidate.shape[2] == 3:
            tip_index = 3  # thumb_tip in the canonical 20-joint mapping
            if retargeted_joint_names is not None:
                names = tuple(str(name) for name in retargeted_joint_names)
                if "thumb_tip" in names:
                    tip_index = names.index("thumb_tip")
            if tip_index < candidate.shape[1]:
                retargeted_thumb = candidate[:, tip_index]
                if np.all(np.isfinite(retargeted_thumb)):
                    thumb = retargeted_thumb
    mask = np.asarray(pinch_mask, dtype=bool).reshape(-1)
    candidates = np.empty(0, dtype=np.int64)
    if mask.shape == (len(right),):
        # Match batch_replay's stable grasp definition: at least 12 contiguous
        # pinch frames and a measurable wrist lift.  This prevents a short
        # detector blip from becoming the TF anchor.
        start = None
        for index, active in enumerate(np.concatenate((mask, [False]))):
            if active and start is None:
                start = index
            elif not active and start is not None:
                end = index - 1
                if end - start + 1 >= 12:
                    wrist_z = right[start : end + 1, wrist_index, 2]
                    if np.all(np.isfinite(wrist_z)) and float(np.ptp(wrist_z)) >= 0.010:
                        candidates = np.arange(start, end + 1, dtype=np.int64)
                        break
                start = None
    # Fall back to the complete trajectory for recordings whose detector
    # produced no stable pinch label; batch_replay will discard those episodes.
    if not candidates.size:
        candidates = np.arange(len(right), dtype=np.int64)
    finite = np.all(np.isfinite(thumb[candidates]), axis=1)
    if not np.any(finite):
        thumb_point = np.asarray(right[0, thumb_index], dtype=np.float64)
    else:
        valid_indices = candidates[finite]
        thumb_point = thumb[valid_indices[np.argmin(thumb[valid_indices, 2])]]
    points = np.stack((thumb_point, midpoint0), axis=0)
    targets = np.asarray(((0.44, 0.0, 0.9), (0.0, 0.0, 0.0)), dtype=np.float64)
    return points, targets




# Keep this identical to visualize_replay.py: publisher calibrated table height
# visualize_replay adds DEFAULT_TABLE_TOP_RAISE (1 cm) only for its display check.
DEFAULT_REPLAY_TABLE_TOP_Z = 0.007402736499
DEFAULT_THUMB_TABLE_CLEARANCE_M = 0.010


def _as_xyz3(value) -> np.ndarray:
    """Return a finite world/base XYZ vector from numpy or a CUDA tensor."""

    if hasattr(value, "detach"):
        value = value.detach().float().cpu().numpy()
    point = np.asarray(value, dtype=np.float64).reshape(-1)
    if point.size != 3 or not np.all(np.isfinite(point)):
        raise ValueError("expected a finite 3-vector")
    return point.copy()


def _as_rotation3(value) -> np.ndarray:
    """Return a finite 3x3 rotation from numpy or a CUDA tensor."""

    if hasattr(value, "detach"):
        value = value.detach().float().cpu().numpy()
    matrix = np.asarray(value, dtype=np.float64)
    if matrix.shape != (3, 3) or not np.all(np.isfinite(matrix)):
        raise ValueError("expected a finite 3x3 rotation")
    return matrix.copy()


def _first_frame_dual_palm_height_above_table(
    alignment: OptimizationResult,
    left_palm_world,
    right_palm_world,
    *,
    table_top_z: float = DEFAULT_REPLAY_TABLE_TOP_Z,
) -> tuple[float, float]:
    """Height of the first-frame dual ``palm_link`` origin midpoint above the table.

    ``left_palm_world`` / ``right_palm_world`` are the first-frame
    ``*_palm_link`` origins in world.  After ``world_to_base``, the midpoint
    of those two origins is the workspace height reference: ``mid_z - table``.
    """

    palms_world = np.stack(
        (_as_xyz3(left_palm_world), _as_xyz3(right_palm_world)),
        axis=0,
    )
    palms_base = (
        np.einsum("ij,nj->ni", alignment.world_to_base_rotation, palms_world)
        + alignment.world_to_base_translation
    )
    mid_z = float(0.5 * (palms_base[0, 2] + palms_base[1, 2]))
    if not np.isfinite(mid_z):
        raise ValueError("first-frame dual palm_link midpoint z is not finite")
    return mid_z - float(table_top_z), mid_z


def _correct_alignment_scaled_thumb_height(
    alignment: OptimizationResult, scaled_thumb_world: np.ndarray, *,
    grasp_indices: np.ndarray, table_top_z: float = DEFAULT_REPLAY_TABLE_TOP_Z,
    clearance_m: float = DEFAULT_THUMB_TABLE_CLEARANCE_M,
) -> tuple[OptimizationResult, float, float]:
    """Translate base_link so the first grasp's lowest scaled thumb is 10 mm above table."""
    thumb_world = np.asarray(scaled_thumb_world, dtype=np.float64)
    indices = np.asarray(grasp_indices, dtype=np.int64).reshape(-1)
    if thumb_world.ndim != 2 or thumb_world.shape[1] != 3 or not np.all(np.isfinite(thumb_world)):
        raise ValueError("scaled right thumb trajectory must be finite with shape [T,3]")
    if indices.size == 0 or np.any(indices < 0) or np.any(indices >= len(thumb_world)):
        raise ValueError("grasp_indices must select at least one valid frame")
    thumb_base = (np.einsum("ij,nj->ni", alignment.world_to_base_rotation, thumb_world[indices]) + alignment.world_to_base_translation)
    lowest_z = float(np.min(thumb_base[:, 2]))
    correction = float(table_top_z + clearance_m - lowest_z)
    translation = np.asarray(alignment.world_to_base_translation, dtype=np.float64).copy()
    translation[2] += correction
    base_to_world_translation = -(np.asarray(alignment.world_to_base_rotation, dtype=np.float64).T @ translation)
    return replace(alignment, world_to_base_translation=translation, base_to_world_translation=base_to_world_translation), correction, lowest_z

def _first_stable_right_grasp_indices(contact_tip_masks: np.ndarray, skeleton_sequence, *, minimum_frames: int = 12, minimum_wrist_excursion_m: float = 0.010) -> tuple[np.ndarray, str]:
    # Normalise per-frame or per-finger contact masks to one active flag per frame.
    contact = np.asarray(contact_tip_masks, dtype=bool)
    if contact.ndim == 0:
        contact = contact.reshape(1)
    if contact.ndim == 1:
        active = contact
    else:
        active = np.any(contact, axis=tuple(range(1, contact.ndim)))
    wrist_index = list(wg.JOINT_ORDER).index("wrist")
    wrist_z = np.asarray(skeleton_sequence.positions["right"], dtype=np.float64)[:, wrist_index, 2]
    start = None
    for idx, value in enumerate(np.concatenate((active, [False]))):
        if value and start is None:
            start = idx
        elif not value and start is not None:
            end = idx - 1
            if end - start + 1 >= minimum_frames and float(np.ptp(wrist_z[start:end + 1])) >= minimum_wrist_excursion_m:
                return np.arange(start, end + 1, dtype=np.int64), f"first stable right contact run [{start},{end}]"
            start = None
    return np.arange(len(active), dtype=np.int64), "fallback full trajectory (no stable contact run)"


def get_last_replay() -> dict[str, np.ndarray] | None:
    """Return the current thread's in-process replay without disk I/O."""

    return getattr(_LAST_REPLAY_LOCAL, "replay", None)


def clear_last_replay() -> None:
    _LAST_REPLAY_LOCAL.replay = None

def _synchronize_cuda_for_timing() -> None:
    try:
        import torch

        if torch.cuda.is_available():
            # Synchronize only the stream owned by this replay job.  A
            # device-wide synchronize serializes otherwise independent
            # trajectories when batch_replay runs several jobs on one GPU.
            torch.cuda.current_stream().synchronize()
    except (ImportError, RuntimeError):
        pass


def _record_solve_timing(
    records: dict[str, float], name: str, started: float, *, cuda: bool = False
) -> None:
    if cuda:
        _synchronize_cuda_for_timing()
    elapsed = time.perf_counter() - started
    records[name] = elapsed
    print(f"[wuji_replay][timing] {name} = {elapsed:.3f}s", flush=True)


def _attach_solve_timings(
    replay: dict[str, np.ndarray], records: Mapping[str, float], started: float
) -> None:
    total = time.perf_counter() - started
    all_records = dict(records)
    all_records["total trajectory solve"] = total
    for name, seconds in all_records.items():
        key = "trajectory_timing_" + name.lower().replace("/", "_").replace(
            " ", "_"
        )
        replay[key] = np.asarray(seconds, dtype=np.float64)
    print(
        f"[wuji_replay][timing] total trajectory solve = {total:.3f}s",
        flush=True,
    )


def _laplacian_optimizer_for_solver(solver: str):
    """Resolve the requested hand trajectory optimizer."""

    normalized = str(solver).lower()
    if normalized == "lbfgs":
        raise ValueError("Laplacian L-BFGS was removed; use --solver hjcd")
    if normalized == "bae":
        from laplacian_optimizer_sqp import (
            optimize_laplacian_trajectory as optimize_laplacian_trajectory_bae,
        )

        return normalized, optimize_laplacian_trajectory_bae
    if normalized == "hjcd":
        from calibrated.laplacian_optimizer import (
            optimize_laplacian_trajectory as optimize_laplacian_trajectory_hjcd,
        )

        def run_hjcd(replay, topology, **kwargs):
            for key in (
                "q_velocity_cost", "q_jerk_cost",
                "wrist_velocity_position_cost",
                "wrist_velocity_orientation_cost",
                "q_acceleration_cost",
                "wrist_acceleration_position_cost",
                "wrist_acceleration_orientation_cost",
                "smoothness_warmup_iterations", "smoothness_ramp_iterations",
                "linear_backend",
            ):
                kwargs.pop(key, None)
            kwargs["optimizer_name"] = "hjcd"
            return optimize_laplacian_trajectory_hjcd(replay, topology, **kwargs)

        return normalized, run_hjcd
    raise ValueError("solver must be 'bae' or 'hjcd'")


def _smooth_hand_joint_trajectory(values: np.ndarray, passes: int = 3) -> np.ndarray:
    """Suppress one-frame joint target changes after contact-state switches.

    The Laplacian objective smooths the solved geometry, but a tactile tip can
    be released between adjacent frames and leave a large one-frame q change.
    A short symmetric three-point pass preserves the frame count/endpoints and
    removes those isolated discontinuities before publishing hand commands.
    """
    result = np.asarray(values, dtype=np.float64).copy()
    if result.ndim != 2 or len(result) < 3:
        return result
    for _ in range(max(0, int(passes))):
        result[1:-1] = (
            0.25 * result[:-2] + 0.5 * result[1:-1] + 0.25 * result[2:]
        )
    return result


def _closest_tip_fallback_masks(
    source_positions: Mapping[str, np.ndarray],
    tactile_contact_masks: Mapping[str, np.ndarray],
) -> dict[str, np.ndarray]:
    """Select one closest cross-hand tip pair when a frame has no contact."""

    tip_ids = np.asarray(
        [
            wg.joint_index(wg.FINGER_TIP_AUX[finger][0])
            for finger in FINGER_NAMES
        ],
        dtype=np.int64,
    )
    left = np.asarray(source_positions["left"], dtype=np.float64)[:, tip_ids]
    right = np.asarray(source_positions["right"], dtype=np.float64)[:, tip_ids]
    if left.shape != right.shape or left.ndim != 3 or left.shape[1:] != (5, 3):
        raise ValueError("Source skeleton tips must have aligned shape [T,5,3]")
    tactile = {
        side: np.asarray(tactile_contact_masks[side], dtype=bool)
        for side in ("left", "right")
    }
    for side in ("left", "right"):
        if tactile[side].shape != (len(left), 5):
            raise ValueError(f"{side} tactile contact mask must have shape [T,5]")

    fallback = {
        side: np.zeros((len(left), 5), dtype=bool)
        for side in ("left", "right")
    }
    no_contact = ~(tactile["left"].any(axis=1) | tactile["right"].any(axis=1))
    # Keep one nearest-pair identity through each no-contact segment. A
    # per-frame argmin can switch between adjacent fingers when distances are
    # close, creating a discontinuous Mink alignment target.
    previous_pair: tuple[int, int] | None = None
    switch_penalty_m = 0.010
    for frame in range(len(left)):
        if not no_contact[frame]:
            previous_pair = None
            continue
        distances = np.linalg.norm(
            left[frame, :, None] - right[frame, None, :], axis=-1
        )
        if previous_pair is None:
            left_tip, right_tip = np.unravel_index(
                int(np.argmin(distances)), distances.shape
            )
        else:
            penalized = distances + switch_penalty_m
            penalized[previous_pair] = distances[previous_pair]
            left_tip, right_tip = np.unravel_index(
                int(np.argmin(penalized)), penalized.shape
            )
        previous_pair = (int(left_tip), int(right_tip))
        fallback["left"][frame, left_tip] = True
        fallback["right"][frame, right_tip] = True
    return fallback


def _probe_video_metadata(
    path: str | Path,
) -> tuple[float, int, float] | None:
    """Return encoded ``(fps, frame_count, duration_seconds)`` via ffprobe."""

    path = Path(path)
    if not path.is_file():
        return None
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=avg_frame_rate,nb_frames,duration:format=duration",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(completed.stdout)
        stream = payload["streams"][0]
        numerator, denominator = stream["avg_frame_rate"].split("/", 1)
        fps = float(numerator) / float(denominator)
        duration = float(
            stream.get("duration") or payload.get("format", {}).get("duration")
        )
        frame_count = int(stream.get("nb_frames") or round(duration * fps))
    except (
        FileNotFoundError,
        KeyError,
        IndexError,
        TypeError,
        ValueError,
        json.JSONDecodeError,
        subprocess.CalledProcessError,
    ):
        return None
    if (
        not np.isfinite(fps)
        or fps <= 0.0
        or frame_count <= 0
        or not np.isfinite(duration)
        or duration <= 0.0
    ):
        return None
    return fps, frame_count, duration


def _reference_video(
    directory: str | Path,
) -> tuple[Path, float, int, float] | None:
    """Prefer the face camera and return its encoded timing metadata."""

    directory = Path(directory)
    for name in ("faceImg.mp4", "leftImg.mp4", "rightImg.mp4"):
        path = directory / name
        metadata = _probe_video_metadata(path)
        if metadata is not None:
            return path, *metadata
    return None


def _timestamp_playback_fps(timestamps: np.ndarray) -> float | None:
    """Infer FPS from second or absolute-nanosecond trajectory timestamps."""

    values = np.asarray(timestamps, dtype=np.float64)
    if values.ndim != 1 or len(values) < 2 or not np.all(np.isfinite(values)):
        return None
    differences = np.diff(values)
    if np.any(differences <= 0.0):
        return None
    period = float(np.median(differences))
    if period > 1e6:
        period *= 1e-9
    if not np.isfinite(period) or period <= 0.0:
        return None
    return 1.0 / period


def replay_episode(
    test_data: str | Path,
    *,
    composite_urdf: str | Path = DEFAULT_COMPOSITE_URDF,
    hand_urdfs: Mapping[str, str | Path] = DEFAULT_HAND_URDFS,
    glove_urdfs: Mapping[str, str | Path] | None = None,
    glove_sdk_user: str | None = None,
    model_config: str | Path | None = None,
    generation: str | None = None,
    initial_position: Sequence[float] | None = None,
    initial_arm_q: np.ndarray | None = None,
    stride: int = 1,
    max_frames: int | None = None,
    min_confidence: float = 0.0,
    contact_threshold_k: float = 3.0,
    thumb_table_clearance_m: float = DEFAULT_THUMB_TABLE_CLEARANCE_M,
    table_top_z: float = DEFAULT_REPLAY_TABLE_TOP_Z,
    contact_mink_position_cost: float = 2000.0,
    contact_mink_orientation_cost: float = 2.0,
    use_recorded_tip_targets: bool = True,
    anchor_skeleton_joint: str = "mcp",
    retarget_weight: str = "normal",
    hand_pipeline: str = DEFAULT_HAND_PIPELINE,
    topology_cache: str | Path | None = None,
    laplacian_cache: str | Path | None = None,
    force_topology: bool = False,
    solver: str = DEFAULT_LAPLACIAN_SOLVER,
    collision_config: str | Path = DEFAULT_COLLISION_CONFIG,
    laplacian_kappa: float = 20.0,
    laplacian_iterations: int | None = None,
    laplacian_learning_rate: float = 2e-3,
    laplacian_weight_decay: float = 1e-4,
    laplacian_early_stop_delta: float = 1e-6,
    laplacian_weight: float = 1.0,
    laplacian_vertex_position_weight: float = 1000.0,
    bone_weight: float = 1.0,
    temporal_weight: float = 0.1,
    penetration_weight: float = 0.0,
    contact_edge_multiplier: float = 1000.0,
    noncontact_edge_multiplier: float = 1.0,
    contact_position_weight: float = 100.0,
    contact_orientation_weight: float = 0.1,
    contact_position_x_weight: float = 1.0,
    contact_position_y_weight: float = 1.0,
    contact_position_z_weight: float = 1.0,
    patch_chamfer_weight: float = 50.0,
    right_pinch_activation_distance: float | None = None,
    left_pinch_target_distance: float | None = None,
    right_pinch_target_distance: float = 0.007,
    right_pinch_distance_weight: float = 0.0,
    collision_margin: float = 0.002,
    laplacian_device: str = "auto",
    laplacian_gn_linear_backend: str = "warp_sparse",
    alignment_solver: str = "warp",
    alignment_iterations: int = 20,
    alignment_initial_damping: float = 1e-3,
    alignment_early_stop_delta: float = 1e-10,
    position_weight: float = 100.0,
    orientation_weight: float = 10.0,
    configuration_weight: float = 1e-3,
    midpoint_weight: float = 100.0,
    table_normal_weight: float = DEFAULT_TABLE_NORMAL_WEIGHT,
    arm_ik_iterations: int = 100,
    arm_ik_dt: float = 0.05,
    arm_ik_early_stop_delta: float = 1e-5,
    arm_position_cost: float = 100.0,
    arm_orientation_cost: float = 20.0,
    arm_posture_cost: float = 1e-3,
    arm_ik_solver: str = "mink",
    arm_inter_arm_distance_weight: float = 1e3,
    arm_inter_arm_distance_threshold: float = 0.2,
    arm_inter_arm_huber_delta: float = 0.02,
    arm_inter_arm_position_budget: float = 0.002,
    arm_inter_arm_orientation_budget: float = 0.02,
    motion_planning: bool = False,
    motion_smoothing_weight: float = 0.1,
    motion_preserve_endpoints: bool = True,
    motion_keyframe_indices: Sequence[int] | None = None,
    motion_keyframe_stride: int = 1,
    motion_output_fps: float = 30.0,
    motion_max_acceleration: float = 6.0,
    motion_max_jerk: float = 100000.0,
    motion_max_hand_acceleration: float = 20.0,
    motion_max_hand_jerk: float = 300000.0,
    motion_preserve_hand_details: bool = True,
    stop_after_alignment: bool = False,
    device: str = "cpu",
    verbose: bool = True,
    skip_laplacian: bool | None = None,
) -> tuple[dict[str, np.ndarray], OptimizationResult]:
    """Run all solving stages and return frame-aligned replay arrays."""

    hand_urdfs = resolve_hand_urdfs_for_composite(composite_urdf, hand_urdfs)
    solve_started = time.perf_counter()
    solve_timings: dict[str, float] = {}
    if str(arm_ik_solver).lower() in {"warp", "hjcd"}:
        from calibrated.arm_ik_lm_fused import require_arm_ik_module

        require_arm_ik_module()
    from wuji_retarget.sdk_retarget import use_sdk_for_hand1, preserve_sdk_q, sdk_metadata
    from wuji_retarget.wuji_hand_names import detect_generation_from_urdf
    resolved_generation = generation or detect_generation_from_urdf(composite_urdf)
    use_sdk_for_hand1(resolved_generation)
    from wuji_retarget.sdk_retarget import use_emf_input
    use_emf_input(test_data)
    sdk_preserve = True
    skip_laplacian = True
    hand_pipeline = "sdk_emf"
    requested_right_pinch_distance_weight = float(right_pinch_distance_weight)
    requested_contact_position_weight = float(contact_position_weight)
    solver, laplacian_optimizer = "disabled_sdk_preserve", None
    resolved_laplacian_iterations = 0
    resolved_left_pinch_target_distance = (
        right_pinch_target_distance
        if left_pinch_target_distance is None
        else left_pinch_target_distance
    )
    from mocap.glove_skeleton_io import resolve_episode_json
    from wuji_retarget.hand_retarget import normalize_ik_anchor

    episode_json = resolve_episode_json(Path(test_data))
    anchor_skeleton_joint = normalize_ik_anchor(
        anchor_skeleton_joint, field="anchor"
    )
    print(f"[wuji_replay] episode JSON -> {episode_json}")
    raw_skeleton_sequence = load_world_skeletons(
        episode_json,
        stride=stride,
        max_frames=max_frames,
        min_confidence=min_confidence,
    )
    if sdk_preserve:
        # SDK hand-only retargeting does not require tactile measurements.
        contact_frames = range(int(raw_skeleton_sequence.frame_indices[-1]) + 1)
        contact_labels = {
            side: {finger: np.zeros(len(contact_frames), dtype=bool)
                   for finger in FINGER_NAMES}
            for side in ("left", "right")
        }
    else:
        contact_labels, contact_frames = detect_contacts(
            episode_json, threshold_k=contact_threshold_k
        )
    detected_contact_tip_masks = {
        side: np.stack(
            [contact_labels[side][finger] for finger in FINGER_NAMES],
            axis=1,
        )
        for side in ("left", "right")
    }
    raw_contact_tip_masks = {
        side: values.copy() for side, values in detected_contact_tip_masks.items()
    }
    # Batch replay admits a trajectory by the right index tactile signal and
    # the thumb/index distance. Keep the other right-hand fingers on their
    # natural scaled-skeleton targets: treating their incidental tactile labels
    # as absolute fingertip constraints pulls their distal links inward and can
    # make them fold around the object. Their raw labels remain available in
    # ``right_detected_contact_tip_mask`` for diagnostics.
    raw_contact_tip_masks["right"][:, 2:] = False
    skeleton_sequence = raw_skeleton_sequence
    contact_tip_masks = {
        side: raw_contact_tip_masks[side][skeleton_sequence.frame_indices]
        for side in ("left", "right")
    }
    # Tactile contact can flicker for one or two frames while the hand is
    # still holding the object. A per-finger mask switch makes Mink jump
    # between an absolute contact target and the free scaled-skeleton target.
    # Repair only short holes inside a continuous thumb/index grasp.
    contact_fill_frames = 5
    for side in ("left", "right"):
        mask = contact_tip_masks[side].copy()
        pinch = mask[:, 0] | mask[:, 1]
        active = np.flatnonzero(pinch)
        if len(active) >= 2:
            repaired = pinch.copy()
            for a, b in zip(active[:-1], active[1:]):
                if int(b - a - 1) <= contact_fill_frames:
                    repaired[a : b + 1] = True
            for frame in np.flatnonzero(repaired & ~pinch):
                mask[frame, 0] = True
                mask[frame, 1] = True
            contact_tip_masks[side] = mask
            raw_contact_tip_masks[side][skeleton_sequence.frame_indices] = mask
    # With no tactile contact, Mink already tracks the complete scaled
    # skeleton target. Do not add a synthetic nearest cross-hand fingertip
    # anchor: it is not part of the physical tracking objective and can switch
    # finger identity near release frames.
    fallback_tip_masks = {
        side: np.zeros_like(contact_tip_masks[side], dtype=bool)
        for side in ("left", "right")
    }
    if verbose and not skip_laplacian:
        summary = "; ".join(
            f"{side}="
            + ",".join(
                f"{finger}:{int(contact_labels[side][finger].sum())}"
                for finger in FINGER_NAMES
            )
            for side in ("left", "right")
        )
        print(
            f"[wuji_replay] tactile contacts over {len(contact_frames)} raw "
            f"frames: {summary}"
        )
    from optimize import R_POSE_LINK

    stage_started = time.perf_counter()
    hand_result = retarget_episode(
        Path(test_data),
        composite_urdf=composite_urdf,
        hand_urdfs=hand_urdfs,
        glove_urdfs=glove_urdfs,
        glove_sdk_user=glove_sdk_user,
        model_config=model_config,
        generation=resolved_generation,
        stride=stride,
        max_frames=max_frames,
        min_confidence=min_confidence,
        contact_tip_masks=contact_tip_masks,
        fallback_tip_masks=fallback_tip_masks,
        contact_tip_position_cost=contact_mink_position_cost,
        contact_tip_orientation_cost=contact_mink_orientation_cost,
        tip_pose_link_rotations={
            side: np.broadcast_to(R_POSE_LINK[side], (5, 3, 3)).copy()
            for side in ("left", "right")
        },
        use_recorded_tip_targets=use_recorded_tip_targets,
        anchor_skeleton_joint=anchor_skeleton_joint,
        retarget_weight=retarget_weight,
        iterations=60,
        verbose=verbose,
        sequence=raw_skeleton_sequence,
    )
    kept = np.asarray(hand_result["frame_indices"], dtype=np.int64)
    original = np.asarray(skeleton_sequence.frame_indices, dtype=np.int64)
    if not np.array_equal(kept, original):
        locator = {int(index): row for row, index in enumerate(original)}
        rows = np.asarray([locator[int(index)] for index in kept], dtype=np.int64)
        skeleton_sequence = skeleton_sequence.take(rows)
        raw_skeleton_sequence = skeleton_sequence
        contact_tip_masks = {
            side: values[rows] for side, values in contact_tip_masks.items()
        }
        fallback_tip_masks = {
            side: values[rows] for side, values in fallback_tip_masks.items()
        }
        dropped = [int(index) for index in original if int(index) not in set(map(int, kept))]
        from wuji_retarget.emf_offline import TrajectoryFrameLoss, trajectory_frame_loss

        reason = trajectory_frame_loss(dropped)
        if reason is not None:
            raise TrajectoryFrameLoss(reason)
        if verbose:
            print(
                f"[wuji_replay] dropped {len(dropped)} frames without an EMF "
                f"sample within one action period: {dropped[:20]}",
                flush=True,
            )
    from wuji_retarget.sdk_retarget import sequence_from_sdk
    skeleton_sequence = sequence_from_sdk(skeleton_sequence, hand_result)
    raw_skeleton_sequence = skeleton_sequence
    _record_solve_timing(
        solve_timings, "raw EMF SDK finger retarget", stage_started
    )
    hand_result["contact_finger_names"] = np.asarray(FINGER_NAMES)
    hand_result["right_raw_detected_contact_tip_mask"] = detected_contact_tip_masks[
        "right"
    ][skeleton_sequence.frame_indices]
    hand_result["contact_threshold_k"] = np.asarray(
        contact_threshold_k, dtype=np.float64
    )
    hand_result["contact_detection_source"] = np.asarray(
        "disabled_sdk_preserve" if sdk_preserve
        else "contact_detect.compute_finger_contact_labels"
    )
    hand_result["mink_fallback_tip_selection"] = np.asarray(
        "disabled; no-tactile frames track the complete scaled skeleton"
    )
    hand_result["right_trajectory_contact_finger_names"] = np.asarray(
        ("thumb", "index")
    )
    output_dir = episode_json.parent
    no_npz_transport = os.environ.get("GEORT_NO_NPZ", "0") == "1"
    hand_result["laplacian_iterations"] = np.asarray(0)
    hand_result["laplacian_cost_total"] = np.asarray(0.0)
    hand_result["laplacian_solver"] = np.asarray("disabled_sdk_preserve")
    hand_result["left_pinch_target_distance_m"] = np.asarray(
        resolved_left_pinch_target_distance, dtype=np.float64
    )
    hand_result["hand_pipeline"] = np.asarray(hand_pipeline)
    hand_result["requested_right_pinch_distance_weight"] = np.asarray(
        requested_right_pinch_distance_weight, dtype=np.float64
    )
    hand_result["effective_right_pinch_distance_weight"] = np.asarray(
        0.0 if sdk_preserve else right_pinch_distance_weight, dtype=np.float64
    )
    hand_result["requested_contact_position_weight"] = np.asarray(
        requested_contact_position_weight, dtype=np.float64
    )
    hand_result["effective_contact_position_weight"] = np.asarray(
        0.0 if sdk_preserve else contact_position_weight, dtype=np.float64
    )
    if "laplacian_solver" not in hand_result:
        hand_result["laplacian_solver"] = np.asarray(solver)

    hand_result["hand_trajectory_solver"] = np.asarray(
        "wuji_sdk_retarget_session" if preserve_sdk_q(hand_result)
        else "unified_laplacian_contact_temporal_sparse_gn"
    )

    from calibrated.device_bridge import (
        apply_world_to_base_cuda,
        matrix_to_quaternion_xyzw_cuda,
        pop_cuda_state,
    )

    cuda_traj = pop_cuda_state(hand_result)
    if (
        cuda_traj is not None
        and "wrist_p" in cuda_traj
        and "wrist_R" in cuda_traj
        and str(alignment_solver).lower() == "warp"
    ):
        first_positions = {
            "left": cuda_traj["wrist_p"][0, 0],
            "right": cuda_traj["wrist_p"][0, 1],
        }
        first_rotations = {
            "left": cuda_traj["wrist_R"][0, 0],
            "right": cuda_traj["wrist_R"][0, 1],
        }
    else:
        first_positions = {
            side: np.asarray(hand_result[f"{side}_wrist_position"])[0]
            for side in ("left", "right")
        }
        first_rotations = {
            side: np.array(
                Rotation.from_quat(
                    np.asarray(hand_result[f"{side}_wrist_quaternion_xyzw"])[0]
                ).as_matrix().tolist(),
                dtype=np.float64,
            )
            for side in ("left", "right")
        }
    urdf_tf_metadata = _urdf_tf_metadata(composite_urdf)
    initial_position_delta = (
        DEFAULT_INITIAL_POSITION if initial_position is None else initial_position
    )
    resolved_initial_position, arm_base_midpoint = _initial_position_from_arm_base_midpoint(
        urdf_tf_metadata, initial_position_delta
    )
    # EX001's base z≈0 sits on the table, so delta.z=0.25 m is ~0.25 m above
    # the table.  Tianji arm bases are 0.49 m above the table; keep the same
    # table clearance by placing the first-frame wrist midpoint at
    # table_top_z + delta.z.
    if is_tianji_urdf(composite_urdf):
        resolved_initial_position = np.asarray(
            resolved_initial_position, dtype=np.float64
        ).copy()
        resolved_initial_position[2] = float(table_top_z) + float(
            initial_position_delta[2]
        )
    initial_position_source = (
        "default arm-base midpoint + XYZ delta"
        if initial_position is None
        else "explicit arm-base midpoint + XYZ delta"
    )
    if verbose:
        print(
            "[wuji_replay] initial_position source="
            f"{initial_position_source}; resolved_base={resolved_initial_position.tolist()}"
        )
    _synchronize_cuda_for_timing()
    stage_started = time.perf_counter()
    normalized_alignment_solver = str(alignment_solver).lower()
    if normalized_alignment_solver == "lbfgsb":
        alignment_function = optimize_first_frame_lbfgsb
        alignment_max_iterations = alignment_iterations
        alignment_extra_kwargs = {}
        alignment_label = "L-BFGS-B CPU"
        alignment_metadata = "lbfgsb_cpu"
    elif normalized_alignment_solver == "warp":
        if is_tianji_urdf(composite_urdf):
            alignment_function = optimize_first_frame_fixed_rotation
            alignment_max_iterations = alignment_iterations
            alignment_extra_kwargs = {}
            alignment_label = "tianji CUDA LM"
            alignment_metadata = "tianji_cuda_lm"
        else:
            from calibrated.align_lm_fused import optimize_first_frame_warp

            alignment_function = optimize_first_frame_warp
            alignment_max_iterations = alignment_iterations
            alignment_extra_kwargs = {}
            alignment_label = "HJCD warp LM"
            alignment_metadata = "hjcd_warp"
    elif normalized_alignment_solver == "projected_lm":
        alignment_function = optimize_first_frame_projected_lm
        alignment_max_iterations = alignment_iterations
        alignment_extra_kwargs = {
            "initial_damping": alignment_initial_damping,
            "early_stop_delta": alignment_early_stop_delta,
        }
        alignment_label = "projected dense LM/GN"
        alignment_metadata = "projected_dense_lm_cpu"
    else:
        raise ValueError("alignment_solver must be lbfgsb, projected_lm, or warp")
    alignment_workspace_points, alignment_workspace_targets = _alignment_workspace_points(
        skeleton_sequence,
        np.asarray(hand_result.get("right_pinch_frame_mask", np.zeros(len(skeleton_sequence.frame_indices), dtype=bool))),
        retargeted_tip_positions_world=hand_result.get(
            "right_target_joint_positions_world"
        ),
        retargeted_joint_names=hand_result.get("right_skeleton_joint_names"),
    )
    use_cuda_first_wrists = (
        cuda_traj is not None
        and "wrist_p" in cuda_traj
        and "wrist_R" in cuda_traj
        and str(alignment_solver).lower() == "warp"
        and not is_tianji_urdf(composite_urdf)
    )
    first_positions_align = (
        first_positions
        if use_cuda_first_wrists
        else {side: _as_xyz3(first_positions[side]) for side in ("left", "right")}
    )
    first_rotations_align = (
        first_rotations
        if use_cuda_first_wrists
        else {
            side: _as_rotation3(first_rotations[side]) for side in ("left", "right")
        }
    )
    first_positions_np = {
        side: _as_xyz3(first_positions[side]) for side in ("left", "right")
    }
    first_rotations_np = {
        side: _as_rotation3(first_rotations[side]) for side in ("left", "right")
    }
    first_frame_palm_rotation = None
    if is_tianji_urdf(composite_urdf):
        first_rotations_np = correct_first_frame_wrist_rotations_facing_table(
            first_rotations_np
        )
        first_frame_palm_rotation = world_to_base_rotation_for_first_frame_palms(
            first_rotations_np,
            wrist_positions_world=first_positions_np,
        )
        if verbose:
            palm_centers_base = {
                side: -(first_frame_palm_rotation @ first_rotations_np[side])[:, 1]
                for side in ("left", "right")
            }
            left_of_right = first_frame_palm_rotation @ (
                first_positions_np["left"] - first_positions_np["right"]
            )
            print(
                "[wuji_replay] tianji first-frame 掌心 (-Y) target "
                f"{list(TIANJI_FIRST_FRAME_PALM_NORMAL_BASE)}; "
                f"left={palm_centers_base['left'].tolist()} "
                f"right={palm_centers_base['right'].tolist()} "
                f"left-right={left_of_right.tolist()}"
            )

    def _solve_first_frame_alignment(workspace_target: np.ndarray) -> OptimizationResult:
        if first_frame_palm_rotation is not None:
            return optimize_first_frame_fixed_rotation(
                first_positions_np,
                first_rotations_np,
                world_to_base_rotation=first_frame_palm_rotation,
                urdf=composite_urdf,
                initial_position=workspace_target,
                initial_arm_q=initial_arm_q,
                max_iterations=alignment_max_iterations,
                position_weight=position_weight,
                orientation_weight=orientation_weight,
                configuration_weight=configuration_weight,
                midpoint_weight=midpoint_weight,
                verbose=verbose,
            )
        return alignment_function(
            first_positions_align,
            first_rotations_align,
            urdf=composite_urdf,
            initial_position=workspace_target,
            initial_arm_q=initial_arm_q,
            max_iterations=alignment_max_iterations,
            position_weight=position_weight,
            orientation_weight=orientation_weight,
            configuration_weight=configuration_weight,
            midpoint_weight=midpoint_weight,
            table_normal_weight=table_normal_weight,
            verbose=verbose,
            **alignment_extra_kwargs,
        )

    alignment = _solve_first_frame_alignment(resolved_initial_position)
    palm_height_above_table, palm_mid_z = _first_frame_dual_palm_height_above_table(
        alignment,
        first_positions["left"],
        first_positions["right"],
        table_top_z=table_top_z,
    )
    if verbose:
        print(
            "[wuji_replay] first-frame workspace z = "
            f"{float(resolved_initial_position[2]):.6f} "
            f"(table_top_z + initial_position.z "
            f"if Tianji, else arm-base midpoint + delta); "
            f"data palm mid_z={palm_mid_z:.6f} "
            f"height_above_table={palm_height_above_table:.6f}"
        )
    align_cuda = getattr(alignment, "_cuda", None)
    thumb_height_correction = 0.0
    lowest_thumb_z = palm_mid_z
    grasp_indices = np.zeros(1, dtype=np.int64)
    grasp_source = "initial_position.z (arm-base midpoint + XYZ delta)"
    _record_solve_timing(
        solve_timings,
        f"first-frame base/arm alignment ({alignment_label})",
        stage_started,
    )

    combined = dict(hand_result)
    combined.update(alignment.as_dict())
    combined["alignment_solver"] = np.asarray(alignment_metadata)
    combined.update(urdf_tf_metadata)
    combined["arm_base_midpoint_base"] = arm_base_midpoint
    combined["initial_position_delta_from_arm_base_midpoint"] = np.asarray(
        resolved_initial_position - arm_base_midpoint, dtype=np.float64
    )
    combined["initial_position_target_base"] = resolved_initial_position.copy()
    combined["alignment_workspace_points_world"] = alignment_workspace_points
    combined["alignment_workspace_point_targets_base"] = alignment_workspace_targets
    combined["table_thumb_height_correction_m"] = np.asarray(thumb_height_correction)
    combined["table_thumb_lowest_z_before_correction_m"] = np.asarray(lowest_thumb_z)
    combined["replay_table_top_z_base_m"] = np.asarray(table_top_z)
    combined["thumb_table_clearance_m"] = np.asarray(thumb_table_clearance_m)
    combined["table_thumb_grasp_frame_indices"] = grasp_indices
    combined["table_thumb_grasp_segment_source"] = np.asarray(grasp_source)
    combined["first_frame_palm_midpoint_z_base_m"] = np.asarray(palm_mid_z)
    combined["first_frame_palm_midpoint_height_above_table_m"] = np.asarray(
        palm_height_above_table
    )
    if first_frame_palm_rotation is not None:
        combined["first_frame_palm_normal_target_base"] = np.asarray(
            TIANJI_FIRST_FRAME_PALM_NORMAL_BASE, dtype=np.float64
        )
        combined["first_frame_palm_world_to_base_rotation"] = (
            first_frame_palm_rotation.copy()
        )
    alignment_workspace_points_base = (
        alignment.world_to_base_rotation @ alignment_workspace_points.T
    ).T + alignment.world_to_base_translation
    combined["alignment_workspace_points_base"] = alignment_workspace_points_base
    if verbose:
        print(
            "[wuji_replay] alignment workspace points base: "
            f"{alignment_workspace_points_base.tolist()} target="
            f"{alignment_workspace_targets.tolist()}"
        )
    wrist_p_base_cuda = None
    wrist_R_base_cuda = None
    if (
        cuda_traj is not None
        and align_cuda is not None
        and "wrist_p" in cuda_traj
        and "wrist_R" in cuda_traj
    ):
        rotation_bw = align_cuda["world_to_base_rotation"].to(
            dtype=cuda_traj["wrist_p"].dtype, device=cuda_traj["wrist_p"].device
        )
        translation_bw = align_cuda["world_to_base_translation"].to(
            dtype=cuda_traj["wrist_p"].dtype, device=cuda_traj["wrist_p"].device
        )
        wrist_p_base_cuda, wrist_R_base_cuda = apply_world_to_base_cuda(
            cuda_traj["wrist_p"], cuda_traj["wrist_R"], rotation_bw, translation_bw
        )
        for index, side in enumerate(("left", "right")):
            combined[f"{side}_wrist_position_base"] = (
                wrist_p_base_cuda[:, index].detach().cpu().numpy().astype(np.float64)
            )
            combined[f"{side}_wrist_quaternion_base_xyzw"] = (
                matrix_to_quaternion_xyzw_cuda(wrist_R_base_cuda[:, index])
                .detach()
                .cpu()
                .numpy()
                .astype(np.float64)
            )
        _add_base_frame_trajectories(combined, alignment, skip_wrists=True)
    else:
        _add_base_frame_trajectories(combined, alignment)
    if stop_after_alignment:
        # Camera calibration needs the exact retarget/Laplacian wrist targets
        # and first-frame base/world alignment, but none of the downstream arm
        # trajectory IK, motion planning, or collision refinement stages.
        _attach_solve_timings(combined, solve_timings, solve_started)
        return combined, alignment

    if wrist_p_base_cuda is not None and wrist_R_base_cuda is not None:
        wrist_positions_base = wrist_p_base_cuda
        wrist_rotations_base = wrist_R_base_cuda
        arm_seed = (
            align_cuda["arm_q"]
            if align_cuda is not None and "arm_q" in align_cuda
            else alignment.arm_q
        )
    else:
        wrist_positions_base = {
            side: np.asarray(combined[f"{side}_wrist_position_base"])
            for side in ("left", "right")
        }
        wrist_rotations_base = {
            side: np.array(
                Rotation.from_quat(
                    np.asarray(combined[f"{side}_wrist_quaternion_base_xyzw"])
                ).as_matrix().tolist(),
                dtype=np.float64,
            )
            for side in ("left", "right")
        }
        arm_seed = alignment.arm_q
    stage_started = time.perf_counter()
    arm_ik = solve_arm_q_trajectory(
        wrist_positions_base,
        wrist_rotations_base,
        initial_arm_q=arm_seed,
        urdf=composite_urdf,
        iterations=arm_ik_iterations,
        dt=arm_ik_dt,
        early_stop_delta=arm_ik_early_stop_delta,
        position_cost=arm_position_cost,
        orientation_cost=arm_orientation_cost,
        posture_cost=arm_posture_cost,
        collision_config=collision_config,
        inter_arm_distance_weight=arm_inter_arm_distance_weight,
        inter_arm_distance_threshold=arm_inter_arm_distance_threshold,
        inter_arm_huber_delta=arm_inter_arm_huber_delta,
        inter_arm_position_budget=arm_inter_arm_position_budget,
        inter_arm_orientation_budget=arm_inter_arm_orientation_budget,
        q_velocity_cost=_ARM_Q_VELOCITY_COST,
        q_acceleration_cost=_ARM_Q_ACCELERATION_COST,
        solver=arm_ik_solver,
        verbose=verbose,
    )
    _record_solve_timing(solve_timings, "arm IK trajectory", stage_started)
    # This deliberately overwrites optimize.py's single first-frame arm seed:
    # arm_q in the final NPZ is always the freshly solved [T, 12] trajectory,
    # including frame zero.
    combined.update(arm_ik.as_dict())
    combined["arm_ik_diagnostics_match_arm_q"] = np.asarray(True, dtype=bool)
    combined["wuji_hand_q"] = np.concatenate(
        [
            np.asarray(combined[f"{side}_hand_q"])
            for side in ("right", "left")
        ],
        axis=1,
    )
    combined["wuji_hand_q_names"] = np.concatenate(
        [
            np.asarray(combined[f"{side}_hand_q_names"])
            for side in ("right", "left")
        ]
    )
    if motion_planning and preserve_sdk_q(combined):
        raise ValueError("SDK preserve mode requires motion_planning=False; "
                         "raw EMF SDK joint commands must remain unchanged")
    if motion_planning:
        combined = plan_replay(
            combined,
            urdf=composite_urdf,
            smoothing_weight=motion_smoothing_weight,
            preserve_endpoints=motion_preserve_endpoints,
            keyframe_indices=motion_keyframe_indices,
            keyframe_stride=motion_keyframe_stride,
            output_fps=motion_output_fps,
            max_acceleration=motion_max_acceleration,
            max_jerk=motion_max_jerk,
            max_hand_acceleration=motion_max_hand_acceleration,
            max_hand_jerk=motion_max_hand_jerk,
            preserve_hand_details=motion_preserve_hand_details,
        )
        combined["arm_ik_diagnostics_match_arm_q"] = np.asarray(
            False, dtype=bool
        )
    else:
        combined["motion_planning_enabled"] = np.asarray(False, dtype=bool)
    # Short output-side hand-q smoothing after the last solve stage. This
    # addresses release-frame finger jumps while keeping the original frame
    # count and endpoint poses unchanged.
    for side in ("left", "right"):
        key = f"{side}_hand_q"
        if key in combined and not preserve_sdk_q(combined):
            combined[f"{key}_before_output_smoothing"] = np.asarray(
                combined[key], dtype=np.float64
            ).copy()
            combined[key] = _smooth_hand_joint_trajectory(combined[key])
    combined["wuji_hand_q"] = np.concatenate(
        [np.asarray(combined[f"{side}_hand_q"]) for side in ("right", "left")],
        axis=1,
    )
    combined["hand_output_smoothing_enabled"] = np.asarray(not preserve_sdk_q(combined))
    combined["hand_output_smoothing_passes"] = np.asarray(0 if preserve_sdk_q(combined) else 3)
    if combined["arm_q"].shape[0] != combined["wuji_hand_q"].shape[0]:
        raise RuntimeError("arm_q and wuji_hand_q lost frame alignment")
    _attach_solve_timings(combined, solve_timings, solve_started)
    return combined, alignment


def _add_base_frame_trajectories(
    result: dict[str, np.ndarray],
    alignment: OptimizationResult,
    *,
    skip_wrists: bool = False,
) -> None:
    """Transform all world-frame hand results using the optimized first-frame TF."""

    for side in ("left", "right"):
        if not skip_wrists:
            wrist_positions = np.asarray(result[f"{side}_wrist_position"])
            wrist_rotations = np.array(
                Rotation.from_quat(
                    np.asarray(result[f"{side}_wrist_quaternion_xyzw"])
                ).as_matrix().tolist(),
                dtype=np.float64,
            )
            wrist_p_base, wrist_R_base = apply_world_to_base(
                wrist_positions, wrist_rotations, alignment
            )
            result[f"{side}_wrist_position_base"] = wrist_p_base
            result[f"{side}_wrist_quaternion_base_xyzw"] = Rotation.from_matrix(
                wrist_R_base
            ).as_quat()

        joint_positions = np.asarray(result[f"{side}_target_joint_positions_world"])
        joint_rotations = np.array(
            Rotation.from_quat(
                np.asarray(result[f"{side}_target_joint_quaternions_xyzw"]).reshape(-1, 4)
            ).as_matrix().tolist(),
            dtype=np.float64,
        ).reshape(*joint_positions.shape[:-1], 3, 3)
        joint_p_base, joint_R_base = apply_world_to_base(
            joint_positions, joint_rotations, alignment
        )
        result[f"{side}_target_joint_positions_base"] = joint_p_base
        result[f"{side}_target_joint_quaternions_base_xyzw"] = Rotation.from_matrix(
            joint_R_base.reshape(-1, 3, 3)
        ).as_quat().reshape(*joint_positions.shape[:-1], 4)


def main(argv: Sequence[str] | None = None) -> Path:
    parser = argparse.ArgumentParser(description=__doc__.split("\n", 1)[0])
    parser.add_argument(
        "--test_data",
        "--tast_data",
        "--episode",
        dest="test_data",
        required=True,
        help="Wuji episode JSON or a directory containing it",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Laplacian-refined replay NPZ (default: beside test_data)",
    )
    parser.add_argument("--composite_urdf", default=str(DEFAULT_COMPOSITE_URDF))
    parser.add_argument("--left_hand_urdf", default=str(DEFAULT_HAND_URDFS["left"]))
    parser.add_argument("--right_hand_urdf", default=str(DEFAULT_HAND_URDFS["right"]))
    parser.add_argument(
        "--left_glove_urdf",
        default="",
        help=(
            "Left glove URDF for the SDK offline pipeline. "
            "Empty uses the SDK builtin model."
        ),
    )
    parser.add_argument(
        "--right_glove_urdf",
        default="",
        help=(
            "Right glove URDF for the SDK offline pipeline. "
            "Empty uses the SDK builtin model."
        ),
    )
    parser.add_argument(
        "--glove_sdk_user",
        default=os.environ.get("GEORT_WUJI_SDK_USER", ""),
        help=(
            "SDK user id whose ~/.wuji/sdk/users/<id>/models/{left,right}_hand.urdf "
            "should override the bundled glove URDF when those files exist."
        ),
    )
    parser.add_argument(
        "--model_config",
        "--model-config",
        dest="model_config",
        default="",
        help=(
            "Optional legacy wuji-v3 model JSON. Glove URDFs come from "
            "--left_glove_urdf / --right_glove_urdf; omit this to use those "
            "URDFs directly."
        ),
    )
    parser.add_argument(
        "--generation",
        choices=("hand1", "hand2"),
        default=None,
        help=(
            "SDK hand model. hand1=WujiHand, hand2=WujiHand2. "
            "Default: infer from --composite_urdf."
        ),
    )
    parser.add_argument(
        "--initial_position",
        "--intial_position",
        nargs=3,
        type=float,
        default=None,
        metavar=("X", "Y", "Z"),
        help=(
            "First-frame wrist-midpoint offset from the two arm-base midpoint, "
            "in base_link XYZ metres. Z is the first-frame action height "
            f"(default {DEFAULT_INITIAL_POSITION[2]:g} m). "
            "If omitted, EX001 uses "
            f"{DEFAULT_INITIAL_POSITION}; Tianji keeps rest-pose xy and this z."
        ),
    )
    parser.add_argument(
        "--initial_arm_q",
        nargs=12,
        type=float,
        default=None,
        metavar=tuple(f"Q{i}" for i in range(1, 13)),
        help="Initial arm q: right joints 1..6, then left joints 1..6 (default: zeros)",
    )

    parser.add_argument("--stride", type=int, default=1)
    parser.add_argument("--max_frames", type=int, default=None)
    parser.add_argument("--min_confidence", type=float, default=0.0)
    parser.add_argument("--contact_threshold_k", type=float, default=3.0)
    parser.add_argument(
        "--anchor",
        "--which_to_track",
        dest="anchor",
        default="mcp",
        help=(
            "Floating-hand IK hard pin and glove→Wuji scale origin: "
            "mcp (default; aliases: index_to_pinky_mcp) rigidly aligns "
            "index–pinky MCP poses on every frame; fingertips (aliases: "
            "index_to_pinky_fingertips) keep glove palm_link orientation "
            "and only match index–pinky tip positions; tips (aliases: "
            "five_fingertips) match the five-finger tip centroid with "
            "that same orientation; thumb_tip "
            "(aliases: thumb) or wrist (aliases: palm, "
            "palm_link) pin that single link."
        ),
    )
    parser.add_argument(
        "--retarget_weight",
        "--retarget-weight",
        dest="retarget_weight",
        choices=("normal", "tips"),
        default="normal",
        help=(
            "Official AdaptiveOptimizerAnalytical fingertip weight. "
            "normal keeps YAML w_pos=1 and an equal wrist→PIP/DIP/TIP "
            "FullHand term. tips multiplies pinch fingertip position "
            "(w_pos) by 3 and the open-palm wrist→tip term by 3."
        ),
    )
    parser.add_argument("--thumb_table_clearance_m", type=float, default=DEFAULT_THUMB_TABLE_CLEARANCE_M)
    parser.add_argument(
        "--table_top_z",
        type=float,
        default=DEFAULT_REPLAY_TABLE_TOP_Z,
        help="Replay table top in base_link metres (used for first-frame palm height)",
    )
    parser.add_argument(
        "--contact_mink_position_cost", type=float, default=2000.0
    )
    parser.add_argument(
        "--tip_ik_targets",
        choices=("scaled", "recorded"),
        default="recorded",
        help=(
            "Contact-weighted fingertip IK targets: scaled Hand skeleton, or "
            "raw recorded/glove tip poses.  Naive replay should use scaled."
        ),
    )
    parser.add_argument(
        "--contact_mink_orientation_cost", type=float, default=2.0
    )
    parser.add_argument(
        "--hand_pipeline",
        choices=HAND_PIPELINES,
        default=DEFAULT_HAND_PIPELINE,
        help=(
            "Hand solver pipeline (default: wuji-v3 SDK finger q; "
            "unified_gn is experimental)"
        ),
    )
    parser.add_argument("--topology_cache", default=None)
    parser.add_argument("--laplacian_cache", default=None)
    parser.add_argument("--force_topology", action="store_true")
    laplacian_group = parser.add_mutually_exclusive_group()
    laplacian_group.add_argument(
        "--skip_laplacian",
        dest="skip_laplacian",
        action="store_true",
        help="Skip topology/Laplacian (default for --hand_pipeline official)",
    )
    laplacian_group.add_argument(
        "--laplacian",
        dest="skip_laplacian",
        action="store_false",
        help="Force the Laplacian / HJCD hand trajectory stage on",
    )
    parser.set_defaults(skip_laplacian=None)
    parser.add_argument(
        "--solver",
        choices=tuple(DEFAULT_LAPLACIAN_ITERATIONS),
        default=DEFAULT_LAPLACIAN_SOLVER,
        help=(
            "Internal hand optimizer backend: BAE sparse LM/SQP or UMR HJCD"
        ),
    )
    parser.add_argument("--collision_config", default=str(DEFAULT_COLLISION_CONFIG))
    parser.add_argument("--laplacian_kappa", type=float, default=20.0)
    parser.add_argument(
        "--laplacian_iterations",
        type=int,
        default=None,
        help="Default: 30 for unified GN",
    )
    parser.add_argument(
        "--laplacian_learning_rate",
        type=float,
        default=2e-3,
        help="Initial PyPose LM damping when --solver=bae",
    )
    parser.add_argument("--laplacian_weight_decay", type=float, default=1e-4)
    parser.add_argument("--laplacian_early_stop_delta", type=float, default=1e-6)
    parser.add_argument("--laplacian_weight", type=float, default=1.0)
    parser.add_argument(
        "--laplacian_vertex_position_weight", type=float, default=1000.0
    )
    parser.add_argument(
        "--link_direction_weight",
        "--bone_weight",
        dest="link_direction_weight",
        type=float,
        default=1.0,
    )
    parser.add_argument("--temporal_weight", type=float, default=0.1)
    parser.add_argument(
        "--penetration_weight",
        type=float,
        default=0.0,
        help=(
            "Legacy/debug hand-sphere penetration weight; default 0 because "
            "dexterous-hand grasp contact is allowed"
        ),
    )
    parser.add_argument(
        "--contact_edge_multiplier", type=float, default=1000.0
    )
    parser.add_argument(
        "--noncontact_edge_multiplier", type=float, default=1.0
    )
    parser.add_argument(
        "--contact_position_weight", type=float, default=100.0
    )
    parser.add_argument(
        "--contact_orientation_weight", type=float, default=0.1
    )
    parser.add_argument("--contact_position_x_weight", type=float, default=1.0)
    parser.add_argument("--contact_position_y_weight", type=float, default=1.0)
    parser.add_argument("--contact_position_z_weight", type=float, default=1.0)
    parser.add_argument("--patch_chamfer_weight", type=float, default=50.0)
    parser.add_argument("--right_pinch_activation_distance", type=float, default=None)
    parser.add_argument("--left_pinch_target_distance", type=float, default=None)
    parser.add_argument("--right_pinch_target_distance", type=float, default=0.007)
    parser.add_argument("--right_pinch_distance_weight", type=float, default=0.0)
    parser.add_argument("--collision_margin", type=float, default=0.002)
    parser.add_argument("--laplacian_device", default="auto")
    parser.add_argument(
        "--laplacian_gn_linear_backend",
        choices=("warp_sparse", "torch_sparse"),
        default="warp_sparse",
    )

    parser.add_argument(
        "--alignment_solver",
        choices=("lbfgsb", "projected_lm", "warp"),
        default="warp",
        help=(
            "First-frame T_base_world solver. warp is HJCD coarse sampling + CUDA LM "
            "with the L-BFGS-B cost; lbfgsb and projected_lm stay available."
        ),
    )
    parser.add_argument("--alignment_iterations", type=int, default=20)
    parser.add_argument("--alignment_initial_damping", type=float, default=1e-3)
    parser.add_argument("--alignment_early_stop_delta", type=float, default=1e-10)
    parser.add_argument("--position_weight", type=float, default=100.0)
    parser.add_argument("--orientation_weight", type=float, default=10.0)
    parser.add_argument("--configuration_weight", type=float, default=1e-3)
    parser.add_argument("--midpoint_weight", type=float, default=100.0)
    parser.add_argument(
        "--table_normal_weight",
        type=float,
        default=DEFAULT_TABLE_NORMAL_WEIGHT,
        help=(
            "First-frame T_base_world residual that keeps base_link +Z on "
            "recorded world +Z so the replay table stays level with the "
            "skeleton.  Yaw about that axis stays free.  0 disables it."
        ),
    )
    parser.add_argument("--device", default="cuda:0")

    parser.add_argument("--arm_ik_iterations", type=int, default=100)
    parser.add_argument("--arm_ik_dt", type=float, default=0.05)
    parser.add_argument("--arm_ik_early_stop_delta", type=float, default=1e-5)
    parser.add_argument("--arm_position_cost", type=float, default=100.0)
    parser.add_argument("--arm_orientation_cost", type=float, default=20.0)
    parser.add_argument("--arm_posture_cost", type=float, default=1e-3)
    parser.add_argument(
        "--arm_ik_solver",
        choices=("auto", "mink", "batched_gn", "warp", "hjcd"),
        default="mink",
        help=(
            "Arm trajectory IK backend. mink is the default; warp is the fused "
            "per-frame CUDA LM with the same Mink palm/posture/inter-arm cost."
        ),
    )
    parser.add_argument("--arm_inter_arm_distance_weight", type=float, default=1e3)
    parser.add_argument("--arm_inter_arm_distance_threshold", type=float, default=0.2)
    parser.add_argument("--arm_inter_arm_huber_delta", type=float, default=0.02)
    parser.add_argument("--arm_inter_arm_position_budget", type=float, default=0.002)
    parser.add_argument("--arm_inter_arm_orientation_budget", type=float, default=0.02)
    motion_group = parser.add_mutually_exclusive_group()
    motion_group.add_argument(
        "--motion_planning",
        dest="motion_planning",
        action="store_true",
        help="Opt in to a dynamically time-scaled spline.",
    )
    motion_group.add_argument(
        "--no_motion_planning",
        dest="motion_planning",
        action="store_false",
        help=argparse.SUPPRESS,
    )
    parser.set_defaults(motion_planning=False)
    parser.add_argument("--motion_smoothing_weight", type=float, default=0.1)
    parser.add_argument("--motion_free_endpoints", action="store_true")
    parser.add_argument("--motion_keyframes", nargs="*", type=int, default=None)
    parser.add_argument("--motion_keyframe_stride", type=int, default=1)
    parser.add_argument(
        "--motion_output_fps",
        type=float,
        default=30.0,
        help="Execution trajectory FPS; 30 keeps it aligned with the RGB videos",
    )
    parser.add_argument("--motion_max_acceleration", type=float, default=6.0)
    parser.add_argument("--motion_max_jerk", type=float, default=100000.0)
    parser.add_argument("--motion_max_hand_acceleration", type=float, default=20.0)
    parser.add_argument("--motion_max_hand_jerk", type=float, default=300000.0)
    parser.add_argument(
        "--motion_smooth_hand_keyframes",
        action="store_true",
        help=(
            "Use the sparse arm keyframes for hand smoothing too; by default "
            "every Laplacian hand frame is preserved"
        ),
    )

    parser.add_argument(
        "--fps",
        type=float,
        default=None,
        help=(
            "Saved replay FPS. Default: encoded FPS of faceImg.mp4 in the "
            "episode directory; otherwise infer it from trajectory timestamps."
        ),
    )
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)

    hand_urdfs = {"left": args.left_hand_urdf, "right": args.right_hand_urdf}
    glove_urdfs = {
        "left": args.left_glove_urdf,
        "right": args.right_glove_urdf,
    }
    combined, alignment = replay_episode(
        args.test_data,
        composite_urdf=args.composite_urdf,
        hand_urdfs=hand_urdfs,
        glove_urdfs=glove_urdfs,
        glove_sdk_user=args.glove_sdk_user or None,
        model_config=args.model_config or None,
        generation=args.generation,
        initial_position=args.initial_position,
        initial_arm_q=args.initial_arm_q,
        stride=args.stride,
        max_frames=args.max_frames,
        min_confidence=args.min_confidence,
        contact_threshold_k=args.contact_threshold_k,
        thumb_table_clearance_m=args.thumb_table_clearance_m,
        table_top_z=args.table_top_z,
        contact_mink_position_cost=args.contact_mink_position_cost,
        contact_mink_orientation_cost=args.contact_mink_orientation_cost,
        use_recorded_tip_targets=args.tip_ik_targets == "recorded",
        anchor_skeleton_joint=args.anchor,
        retarget_weight=args.retarget_weight,
        hand_pipeline=args.hand_pipeline,
        skip_laplacian=args.skip_laplacian,
        topology_cache=args.topology_cache,
        laplacian_cache=args.laplacian_cache,
        force_topology=args.force_topology,
        solver=args.solver,
        collision_config=args.collision_config,
        laplacian_kappa=args.laplacian_kappa,
        laplacian_iterations=args.laplacian_iterations,
        laplacian_learning_rate=args.laplacian_learning_rate,
        laplacian_weight_decay=args.laplacian_weight_decay,
        laplacian_early_stop_delta=args.laplacian_early_stop_delta,
        laplacian_weight=args.laplacian_weight,
        laplacian_vertex_position_weight=(
            args.laplacian_vertex_position_weight
        ),
        bone_weight=args.link_direction_weight,
        temporal_weight=args.temporal_weight,
        penetration_weight=args.penetration_weight,
        contact_edge_multiplier=args.contact_edge_multiplier,
        noncontact_edge_multiplier=args.noncontact_edge_multiplier,
        contact_position_weight=args.contact_position_weight,
        contact_orientation_weight=args.contact_orientation_weight,
        contact_position_x_weight=args.contact_position_x_weight,
        contact_position_y_weight=args.contact_position_y_weight,
        contact_position_z_weight=args.contact_position_z_weight,
        patch_chamfer_weight=args.patch_chamfer_weight,
        right_pinch_activation_distance=args.right_pinch_activation_distance,
        left_pinch_target_distance=args.left_pinch_target_distance,
        right_pinch_target_distance=args.right_pinch_target_distance,
        right_pinch_distance_weight=args.right_pinch_distance_weight,
        collision_margin=args.collision_margin,
        laplacian_device=args.laplacian_device,
        laplacian_gn_linear_backend=args.laplacian_gn_linear_backend,
        alignment_solver=args.alignment_solver,
        alignment_iterations=args.alignment_iterations,
        alignment_initial_damping=args.alignment_initial_damping,
        alignment_early_stop_delta=args.alignment_early_stop_delta,
        position_weight=args.position_weight,
        orientation_weight=args.orientation_weight,
        configuration_weight=args.configuration_weight,
        midpoint_weight=args.midpoint_weight,
        table_normal_weight=args.table_normal_weight,
        arm_ik_iterations=args.arm_ik_iterations,
        arm_ik_dt=args.arm_ik_dt,
        arm_ik_early_stop_delta=args.arm_ik_early_stop_delta,
        arm_position_cost=args.arm_position_cost,
        arm_orientation_cost=args.arm_orientation_cost,
        arm_posture_cost=args.arm_posture_cost,
        arm_ik_solver=args.arm_ik_solver,
        arm_inter_arm_distance_weight=args.arm_inter_arm_distance_weight,
        arm_inter_arm_distance_threshold=args.arm_inter_arm_distance_threshold,
        arm_inter_arm_huber_delta=args.arm_inter_arm_huber_delta,
        arm_inter_arm_position_budget=args.arm_inter_arm_position_budget,
        arm_inter_arm_orientation_budget=args.arm_inter_arm_orientation_budget,
        motion_planning=args.motion_planning,
        motion_smoothing_weight=args.motion_smoothing_weight,
        motion_preserve_endpoints=not args.motion_free_endpoints,
        motion_keyframe_indices=args.motion_keyframes,
        motion_keyframe_stride=args.motion_keyframe_stride,
        motion_output_fps=args.motion_output_fps,
        motion_max_acceleration=args.motion_max_acceleration,
        motion_max_jerk=args.motion_max_jerk,
        motion_max_hand_acceleration=args.motion_max_hand_acceleration,
        motion_max_hand_jerk=args.motion_max_hand_jerk,
        motion_preserve_hand_details=not args.motion_smooth_hand_keyframes,
        device=args.device,
        verbose=not args.quiet,
    )

    from mocap.glove_skeleton_io import resolve_episode_json

    test_data = Path(args.test_data)
    episode_json = resolve_episode_json(test_data)
    output_dir = test_data if test_data.is_dir() else episode_json.parent
    reference_video = _reference_video(output_dir)
    inferred_fps = _timestamp_playback_fps(combined["timestamps"])
    if args.fps is not None:
        if not np.isfinite(args.fps) or args.fps <= 0.0:
            raise ValueError("--fps must be finite and positive")
        playback_fps = float(args.fps)
        timing_source = "explicit --fps"
    elif reference_video is not None:
        video_path, video_fps, video_frame_count, video_duration = (
            reference_video
        )
        playback_fps = video_fps
        timing_source = f"encoded FPS of {video_path.name}"
        combined["reference_video_path"] = np.asarray(str(video_path))
        combined["reference_video_fps"] = np.asarray(
            video_fps, dtype=np.float64
        )
        combined["reference_video_frame_count"] = np.asarray(
            video_frame_count, dtype=np.int64
        )
        combined["reference_video_duration_seconds"] = np.asarray(
            video_duration, dtype=np.float64
        )
        if len(combined["timestamps"]) != video_frame_count:
            print(
                "[wuji_replay] warning: replay/video frame count differs: "
                f"{len(combined['timestamps'])} vs {video_frame_count}; "
                "playback still uses the video's encoded FPS"
            )
    elif bool(combined["motion_planning_enabled"]):
        playback_fps = float(combined["motion_planning_output_fps"])
        timing_source = "motion-planning output FPS"
    elif inferred_fps is not None:
        playback_fps = inferred_fps
        timing_source = "trajectory timestamps"
    else:
        playback_fps = 30.0
        timing_source = "30 FPS fallback"
    combined["playback_fps"] = np.asarray(playback_fps, dtype=np.float64)
    combined["playback_timing_source"] = np.asarray(timing_source)
    combined["playback_duration_seconds"] = np.asarray(
        len(combined["timestamps"]) / playback_fps,
        dtype=np.float64,
    )
    global LAST_REPLAY
    LAST_REPLAY = combined
    _LAST_REPLAY_LOCAL.replay = combined
    out = Path(args.out) if args.out else output_dir / "wuji_replay.npz"
    if os.environ.get("GEORT_NO_NPZ", "0") != "1":
        out.parent.mkdir(parents=True, exist_ok=True)
        np.savez(out, **combined)
    hand_stage_label = (
        "unified GN"
        if str(np.asarray(combined.get("hand_pipeline", "")).item())
        == "unified_gn"
        else "Laplacian"
    )
    laplacian_iterations = int(combined.get("laplacian_iterations", 0))
    laplacian_cost = float(combined.get("laplacian_cost_total", 0.0))
    if os.environ.get("GEORT_NO_NPZ", "0") == "1":
        print(
            f"[wuji_replay] prepared {len(combined['frame_indices'])} frames "
            f"in-memory for batch JSON publishing; "
            f"{hand_stage_label} iterations={laplacian_iterations}, "
            f"{hand_stage_label} final_cost="
            f"{laplacian_cost:.8g}; "
            f"alignment iterations={alignment.iterations}, "
            f"alignment final_cost={alignment.final_cost_terms['total']:.8g}"
        )
    else:
        print(
            f"[wuji_replay] saved {len(combined['frame_indices'])} frames to {out}; "
            f"{hand_stage_label} iterations={laplacian_iterations}, "
            f"{hand_stage_label} final_cost="
            f"{laplacian_cost:.8g}; "
            f"alignment iterations={alignment.iterations}, "
            f"alignment final_cost={alignment.final_cost_terms['total']:.8g}"
        )
    print(
        f"[wuji_replay] solved arm_q trajectory {combined['arm_q'].shape}, "
        f"wuji_hand_q trajectory {combined['wuji_hand_q'].shape}; "
        f"arm IK success={np.count_nonzero(combined['arm_ik_success'])}/"
        f"{len(combined['arm_ik_success'])}"
    )
    print(
        "[wuji_replay] arm IK minimum link6 distance cost metric="
        f"{float(np.min(combined['arm_ik_inter_arm_min_clearance'])):.6g} m "
        f"(threshold={float(combined['arm_ik_inter_arm_distance_threshold']):.6g} m); "
        "minimum link6 origin distance="
        f"{float(np.min(combined['arm_ik_inter_arm_link6_distance'])):.6g} m"
    )
    if bool(combined["motion_planning_enabled"]):
        print(
            "[wuji_replay] motion planning: "
            f"method={combined['motion_planning_method']}, "
            "arm_keyframes="
            f"{len(combined['motion_planning_keyframe_indices'])}, "
            "hand_keyframes="
            f"{len(combined.get('motion_planning_hand_keyframe_indices', []))}, "
            f"time_scale={float(combined['motion_planning_time_scale']):.6g}, "
            "max |delta q|="
            f"{float(combined['motion_planning_max_position_delta']):.8g}"
        )
    print(
        "[wuji_replay] playback timing: "
        f"fps={playback_fps:.8g}, frames={len(combined['timestamps'])}, "
        f"duration={float(combined['playback_duration_seconds']):.8g} s, "
        f"source={timing_source}"
    )
    print("[wuji_replay] T_base_world:")
    T_base_world = np.eye(4)
    T_base_world[:3, :3] = alignment.world_to_base_rotation
    T_base_world[:3, 3] = alignment.world_to_base_translation
    print(np.array2string(T_base_world, precision=7, suppress_small=True))
    print(
        "[wuji_replay] table tilt (base +Z vs world +Z): "
        f"{np.degrees(table_normal_tilt_rad(alignment.world_to_base_rotation)):.3f} deg"
    )
    for side in ("left", "right"):
        arm_base_tf = np.asarray(
            combined[f"base_to_{side}_arm_base_transform"], dtype=np.float64
        )
        print(
            f"[wuji_replay] URDF T_base_{side}_arm_base: "
            f"xyz={arm_base_tf[:3, 3].tolist()}"
        )

    return out


if __name__ == "__main__":
    main()
