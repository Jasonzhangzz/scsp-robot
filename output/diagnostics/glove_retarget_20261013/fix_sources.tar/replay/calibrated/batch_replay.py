#!/usr/bin/env python3
"""UMR copy of ``v2/batch_replay.py`` with HJCD / wuji-v3 SDK finger defaults.

The download, interpolate, and publish loop is the v2 batch driver.  Workers
call :mod:`calibrated.wuji_replay` (wuji-v3 SDK offline EMF retarget + HJCD
Laplacian skip + warp alignment + HJCD arm IK).

``v2.batch_replay`` is unchanged and still defaults to L-BFGS /
L-BFGS-B / Mink.

Solve, interpolate, and standardize YAML-selected v2 replay collections.

The YAML ``list`` names collection folders below the configured remote root,
either by basename or by absolute remote path. Its absolute ``output`` path is
the remote publication root on the same configured SSH server. YAML ``arm``
selects the composite URDF (``ex001_wuji`` / ``ex001_wuji2`` /
``tianji_wuji2``) and the matching official SDK hand model (WujiHand or
WujiHand2). It replaces CLI ``--robot``.
For every collection, at most ``num_per_folder`` episodes are sampled before
anything is downloaded.  A worker invokes :mod:`calibrated.wuji_replay`
(:mod:`calibrated.wuji_replay`).  Trajectories are passed to
:mod:`v2.interpolate_video`.  The published episode is then
assembled entirely through :mod:`data_format`, which is the single
authority for the file inventory, the video names and encoding, every JSON key,
the timestamp clock and the calibration; this module defines none of them itself.
The result is atomically committed under
``<output-root>/<episode>``.  Parent device and collection directories are
not created.  Replay NPZ files are temporary
intra-worker transport and are deleted before publication.

By default one compute-bound trajectory worker runs on each GPU.  Use
``--workers-per-gpu`` for an explicit higher limit when throughput has been
benchmarked on the target GPU.

Examples::

    python -m calibrated.batch_replay \
        --config calibrated/batch_replay.yaml

    # If this name is absent locally, stream a bounded number of its episodes
    # through replay_data/my_collection while the GPUs solve them.
    python -m calibrated.batch_replay --test_data my_collection

    python -m calibrated.batch_replay --data /data/device/topic \
        --devices cuda:0 cuda:1 --workers-per-gpu 3 --skip-existing

Unknown options are forwarded to ``wuji_replay.py``.  For example::

    python -m calibrated.batch_replay /data/episodes \
        --max_frames 100 --laplacian_iterations 50
"""

from __future__ import annotations

import atexit
import argparse
from contextlib import contextmanager
import errno
import hashlib
import io
import json
import logging
import math
import os
import random
import shutil
import shlex
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import xml.etree.ElementTree as ET
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import asdict, dataclass, replace
from pathlib import Path, PurePosixPath
from queue import Queue
from typing import Any, Mapping, Sequence

import numpy as np
from tqdm.auto import tqdm

# Walk to the repository root before importing sibling packages.  After the
# move this file lives at replay/calibrated/batch_replay.py.
_PKG_ROOT = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "assets").is_dir() and (parent / "thirdparty").is_dir()
)
for _extra in (_PKG_ROOT, _PKG_ROOT / "replay", _PKG_ROOT / "utils"):
    _text = str(_extra)
    if _text not in sys.path:
        sys.path.insert(0, _text)


def _pythonpath_with_layout() -> str:
    parts = [str(_PKG_ROOT), str(_PKG_ROOT / "replay"), str(_PKG_ROOT / "utils")]
    existing = [
        item for item in os.environ.get("PYTHONPATH", "").split(os.pathsep) if item
    ]
    merged: list[str] = []
    for item in parts + existing:
        if item and item not in merged:
            merged.append(item)
    return os.pathsep.join(merged)

# Every published name, key, encoding and serialisation rule comes from here.
# This module must not restate any of them: one definition, one chain.
import data_format  # noqa: E402
from retarget_seed import (  # noqa: E402
    is_tianji_urdf,
    worker_retarget_seed_args,
    zero_q_transform,
)
_DEFAULT_CONDA = "/mnt/cpfs/zbl-cpfs-new/USERS/jasonzhang/miniconda3/bin/conda"
_CONDA = os.environ.get(
    "GEORT_CONDA",
    _DEFAULT_CONDA if Path(_DEFAULT_CONDA).is_file() else str(Path.home() / "miniconda3" / "bin" / "conda"),
)
_CONDA_ENV = os.environ.get("GEORT_CONDA_ENV", "pi0")
_WORKER_PYTHON = os.environ.get("GEORT_WORKER_PYTHON", "").strip()
_DEFAULT_REMOTE_HOST = "8.147.67.185"
_DEFAULT_REMOTE_PORT = 1016
_DEFAULT_REMOTE_ROOT = (
    "/mnt/cpfs/zbl-cpfs-new/x2robot_data/collection/18/RP001_VR/"
    "XRRD11ZD2604070080"
)
_DEFAULT_REPLAY_DATA = _PKG_ROOT / "replay_data"
_REMOTE_FETCH_MARKER = ".remote_fetch_complete.json"
_REMOTE_EPISODE_MARKER = ".remote_episode_complete.json"
_REMOTE_STREAM_MARKER = ".remote_stream.json"
_REQUIRED_OUTPUT_KEYS = {
    "arm_q",
    "arm_q_names",
    "arm_ik_success",
    "wuji_hand_q",
    "wuji_hand_q_names",
    "timestamps",
    "playback_fps",
    "left_wrist_position_base",
    "right_wrist_position_base",
    "left_wrist_quaternion_base_xyzw",
    "right_wrist_quaternion_base_xyzw",
}
# All processing is staged locally.  Remote publication is configured
# separately with --remote-output-root (the YAML ``output`` field).
_DEFAULT_OUTPUT_ROOT = _PKG_ROOT / "replay_output"
#: Recorded in the numeric sidecar as the code that produced the episode.
_CONVERTER_NAME = "v2.batch_replay"
# Trajectory worker module. tactile.batch_replay rebinds this to
# ``tactile.wuji_replay`` before calling ``main``.
REPLAY_ENTRY = "calibrated.wuji_replay"
_SOURCE_VIDEO_NAMES = data_format.recorder_video_names()
_INTERPOLATED_VIDEO_NAMES = data_format.interpolated_staging_names()
_PUBLISHED_VIDEO_NAMES = data_format.standard_video_names()
_REMOTE_OUTPUT_RSYNC_CHMOD = "a+rwx"
_WORLD_WRITABLE_MODE = 0o777


def _chmod_world_writable(path: Path) -> None:
    """Force ``777`` so every account can read and write published data."""

    try:
        os.chmod(path, _WORLD_WRITABLE_MODE)
    except OSError:
        return


def _chmod_tree_world_writable(root: Path) -> None:
    """Apply ``777`` to ``root`` and its immediate children (episode dirs are flat)."""

    if not root.exists():
        return
    _chmod_world_writable(root)
    if not root.is_dir() or root.is_symlink():
        return
    for child in root.iterdir():
        _chmod_world_writable(child)


def _ensure_world_writable_dir(path: Path) -> Path:
    """Create ``path`` (and parents) then mark the created chain ``777``."""

    path.mkdir(parents=True, exist_ok=True)
    current = path
    while True:
        _chmod_world_writable(current)
        parent = current.parent
        if parent == current:
            break
        current = parent
    return path


_COPIED_EPISODE_METADATA = data_format.COPIED_METADATA_NAMES


class _ThreadLocalTextRouter(io.TextIOBase):
    """Route worker prints to per-episode logs without serializing workers."""

    def __init__(self, fallback) -> None:
        self._fallback = fallback
        self._local = threading.local()

    @contextmanager
    def route(self, stream):
        previous = getattr(self._local, "stream", None)
        self._local.stream = stream
        try:
            yield
        finally:
            self._local.stream = previous

    def _usable(self, stream):
        if stream is None or getattr(stream, "closed", False):
            return None
        return stream

    def _stream(self):
        return (
            self._usable(getattr(self._local, "stream", None))
            or self._usable(self._fallback)
            or io.StringIO()
        )

    def write(self, value):
        stream = self._stream()
        try:
            return stream.write(value)
        except ValueError:
            fallback = self._usable(self._fallback)
            if fallback is None or fallback is stream:
                return 0
            return fallback.write(value)

    def flush(self) -> None:
        stream = self._stream()
        try:
            stream.flush()
        except ValueError:
            fallback = self._usable(self._fallback)
            if fallback is not None and fallback is not stream:
                fallback.flush()

    def isatty(self) -> bool:
        return bool(getattr(self._stream(), "isatty", lambda: False)())

    @property
    def encoding(self):
        return getattr(self._stream(), "encoding", "utf-8")

    def fileno(self) -> int:
        return self._stream().fileno()


class _PersistentRifeWorker:
    """Keep one Practical-RIFE model resident for a batch GPU.

    The batch scheduler may have several episode threads assigned to one GPU.
    RIFE inference is not thread-safe and competing model instances waste both
    memory and startup time, so a per-GPU lock serializes interpolation while
    allowing trajectory workers on other GPUs to proceed.
    """

    def __init__(self, device: str, *, scale: float, fp16: bool, batch_size: int) -> None:
        self.device = device
        self.scale = scale
        self.fp16 = fp16
        self.batch_size = batch_size
        self.lock = threading.Lock()
        self._interpolator = None

    def run(
        self,
        *,
        test_data: Path,
        replay: Path | None,
        replay_data: Mapping[str, np.ndarray] | None,
        out_replay: Path | None,
        output_fps: float,
        candidate_count: int,
        pose_method: str,
        max_acceleration: float,
        max_hand_acceleration: float,
        max_velocity: float,
        max_hand_velocity: float,
        minimum_playback_rate: float,
        maximum_playback_rate: float,
        log_handle,
        urdf: str | Path | None = None,
    ) -> dict[str, np.ndarray] | None:
        from interpolate_video import (
            CartesianInterpolate,
            LieGroupInterpolate,
            RifeInterpolator,
            interpolate_test_data,
        )

        stdout_router, stderr_router = _install_thread_local_output_routers()
        with self.lock, stdout_router.route(log_handle), stderr_router.route(log_handle):
            if self._interpolator is None:
                self._interpolator = RifeInterpolator(
                    rife_root=_PKG_ROOT / "thirdparty/Practical-RIFE",
                    rife_model=_PKG_ROOT / "thirdparty/Practical-RIFE/train_log",
                    device="gpu",
                    torch_device=self.device,
                    scale=self.scale,
                    fp16=self.fp16,
                    batch_size=self.batch_size,
                )
            planned: dict[str, np.ndarray] = {}
            interpolate_test_data(
                test_data,
                replay_path=None if replay_data is not None else replay,
                urdf=_replay_composite_urdf(replay_data, replay, fallback=urdf),
                output_fps=output_fps,
                candidate_count=candidate_count,
                max_acceleration=max_acceleration,
                max_jerk=100000.0,
                max_hand_acceleration=max_hand_acceleration,
                max_hand_jerk=300000.0,
                max_velocity=max_velocity,
                max_hand_velocity=max_hand_velocity,
                minimum_playback_rate=minimum_playback_rate,
                position_scale_m=0.01,
                orientation_scale_rad=0.1,
                interpolator=self._interpolator,
                pose_interpolator=(
                    LieGroupInterpolate()
                    if pose_method == "lie_group"
                    else CartesianInterpolate()
                ),
                replay_device=self.device,
                out_replay=out_replay,
                replay_data=replay_data,
                replay_sink=planned,
                save_output_replay=False,
                maximum_playback_rate=maximum_playback_rate,
                overwrite=True,
            )
            return planned


class _PersistentTrajectoryWorker:
    """One long-lived solve process per GPU slot. Torch is imported once."""

    def __init__(self, *, selector: str, environment: Mapping[str, str]) -> None:
        env = dict(environment)
        env["CUDA_VISIBLE_DEVICES"] = selector
        env["PYTHONUNBUFFERED"] = "1"
        env.update(_sdk_env_updates())
        self._selector = selector
        self._environment = env
        self._proc: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def _spawn(self) -> None:
        self._proc = subprocess.Popen(
            [
                *_worker_prefix(),
                "-u",
                "-m",
                "calibrated.batch_replay",
                "--_trajectory-worker",
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            cwd=str(_PKG_ROOT),
            env=self._environment,
            text=True,
            bufsize=1,
        )

    def _alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def solve(self, argv: Sequence[str], log_path: Path) -> None:
        with self._lock:
            if not self._alive():
                self._spawn()
            assert self._proc is not None and self._proc.stdin and self._proc.stdout
            self._proc.stdin.write(
                json.dumps({"argv": list(argv), "log": str(log_path)}) + "\n"
            )
            self._proc.stdin.flush()
            line = self._proc.stdout.readline()
            if not line:
                raise RuntimeError("persistent trajectory worker exited")
            payload = json.loads(line)
            if not payload.get("ok"):
                raise RuntimeError(
                    payload.get("error") or "persistent trajectory worker failed"
                )

    def close(self) -> None:
        with self._lock:
            if self._proc is None:
                return
            try:
                if self._proc.stdin is not None:
                    self._proc.stdin.write(json.dumps({"cmd": "stop"}) + "\n")
                    self._proc.stdin.close()
                self._proc.wait(timeout=8)
            except Exception:
                self._proc.kill()
            self._proc = None


_THREAD_TRAJECTORY_WORKER = threading.local()


def _thread_local_trajectory_worker(
    *, selector: str, environment: Mapping[str, str]
) -> _PersistentTrajectoryWorker:
    worker = getattr(_THREAD_TRAJECTORY_WORKER, "worker", None)
    if worker is None:
        worker = _PersistentTrajectoryWorker(
            selector=selector, environment=environment
        )
        _THREAD_TRAJECTORY_WORKER.worker = worker
    return worker


def _trajectory_worker_loop() -> None:
    """Lazy-load the solver once, then serve episode jobs until stdin closes."""

    replay_main = None
    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        job = json.loads(line)
        if job.get("cmd") == "stop":
            break
        if replay_main is None:
            from calibrated.wuji_replay import main as replay_main
        log_path = Path(job["log"])
        log_path.parent.mkdir(parents=True, exist_ok=True)
        error = None
        with log_path.open("a", encoding="utf-8") as log_handle:
            previous_out, previous_err = sys.stdout, sys.stderr
            sys.stdout = sys.stderr = log_handle
            try:
                replay_main(list(job["argv"]))
            except Exception as exc:
                traceback.print_exc()
                error = f"{type(exc).__name__}: {exc}"
            finally:
                sys.stdout, sys.stderr = previous_out, previous_err
        sys.stdout.write(json.dumps({"ok": error is None, "error": error}) + "\n")
        sys.stdout.flush()


class _ReplayArchiveContext:
    """Context wrapper for either an in-memory replay or an NPZ archive."""

    def __init__(self, value):
        self.value = value

    def __enter__(self):
        return self.value

    def __exit__(self, exc_type, exc_value, traceback):
        close = getattr(self.value, "close", None)
        if close is not None:
            close()
        return False


_OUTPUT_ROUTER_LOCK = threading.Lock()
_STDOUT_ROUTER: _ThreadLocalTextRouter | None = None
_STDERR_ROUTER: _ThreadLocalTextRouter | None = None
_CONTROLLER_TRANSFORM_CACHE: dict[
    str, tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
] = {}
_CONTROLLER_TRANSFORM_CACHE_LOCK = threading.Lock()


def _install_thread_local_output_routers() -> tuple[
    _ThreadLocalTextRouter, _ThreadLocalTextRouter
]:
    global _STDOUT_ROUTER, _STDERR_ROUTER
    with _OUTPUT_ROUTER_LOCK:
        if _STDOUT_ROUTER is None:
            _STDOUT_ROUTER = _ThreadLocalTextRouter(sys.stdout)
            sys.stdout = _STDOUT_ROUTER
        if _STDERR_ROUTER is None:
            _STDERR_ROUTER = _ThreadLocalTextRouter(sys.stderr)
            sys.stderr = _STDERR_ROUTER
    return _STDOUT_ROUTER, _STDERR_ROUTER
# Limits are calibrated from the 2026-08-15 Wuji follow-arm recording.  Its
# observed peaks were about 3.16/46.1 rad/s and rad/s^2 for the arms, and
# 6.73/184.7 for the hands.  Rounded headroom avoids retiming normal recorded
# motion while retaining finite guards.  Video playback stays at or below
# real time; RGB frames are generated only for ticks added by action retiming.
_DEFAULT_BATCH_OUTPUT_FPS = 20.0
# Keep the replay clock close to the recorded 20 Hz source clock.  These
# ceilings are intentionally well above the observed follow-arm peaks; the
# publisher still enforces finite values and reports the measured peaks, but
# ordinary motion should no longer be dilated into a second set of action
# frames.  The hand limits are raised as well because the synchronized arm /
# hand clock takes the larger required segment duration from either group.
_DEFAULT_BATCH_MAX_VELOCITY = 15.75
_DEFAULT_BATCH_MAX_HAND_VELOCITY = 31.5
_DEFAULT_BATCH_MAX_ACCELERATION = 5000.0
_DEFAULT_BATCH_MAX_HAND_ACCELERATION = 20000.0
_DEFAULT_BATCH_MAX_PLAYBACK_RATE = 1.0
_DEFAULT_BATCH_MIN_PLAYBACK_RATE = 1.0
# ``desktop_wuji``'s Cartesian controller exposes the pose of ``*_arm_link6``
# relative to its zero-configuration frame (``*_arm_neutral``).  These zero
# transforms come from the deployed robot_description used by the controller:
# arm_base_link -> arm_link6 at q = 0.  Keep this controller calibration out of
# the composite replay URDF: changing the latter would also change IK/collision
# solving, while this transform is only an output-coordinate conversion.
_DESKTOP_WUJI_NEUTRAL_LINK6_TRANSLATION_M = np.asarray(
    [0.1185, 0.0, 0.181], dtype=np.float64
)
_ROBOT_COMPOSITE_URDFS = {
    "ex001_wuji": (
        _PKG_ROOT
        / "assets/EX001_dual_arm_14dof/EX001_dual_arm_14dof_wuji.urdf"
    ),
    "ex001_wuji2": (
        _PKG_ROOT
        / "assets/EX001_dual_arm_14dof/EX001_dual_arm_14dof_wuji2.urdf"
    ),
    "tianji_wuji2": (
        _PKG_ROOT / "assets/7_2/tianji_marvin_m6ccs_dual_arm_wuji2.urdf"
    ),
}
_ROBOT_HAND_GENERATION = {
    "ex001_wuji": "hand1",
    "ex001_wuji2": "hand2",
    "tianji_wuji2": "hand2",
}
_DEFAULT_ROBOT = "ex001_wuji2"
_DEFAULT_COMPOSITE_URDF = _ROBOT_COMPOSITE_URDFS[_DEFAULT_ROBOT]
WUJI_GLOVE_OFFLINE_H5 = "wuji_glove_offline.h5"
WUJI_GLOVE_TF_H5 = "wuji_glove_tf.h5"
_DEFAULT_COLLISION_CONFIG = (
    _PKG_ROOT / "data/curobo_configs/ex001_composite_curobo.yml"
)
_ROBOT_COLLISION_CONFIGS = {
    "ex001_wuji": _DEFAULT_COLLISION_CONFIG,
    "ex001_wuji2": _DEFAULT_COLLISION_CONFIG,
    "tianji_wuji2": _PKG_ROOT / "data/curobo_configs/tianji_wuji2_curobo.yml",
}
# Tianji ``*_arm_base_link`` mounts share composite ``base_link`` z.  The
# replay table top is therefore 0.49 m below that origin.
_TIANJI_ARM_BASE_ABOVE_TABLE_M = 0.49
_DEFAULT_FINGER_DISTANCE_M = 0.001
_DEFAULT_PINCH_ACTIVATION_DISTANCE_M = 0.030
_DEFAULT_PINCH_DISTANCE_WEIGHT = 3000000.0
_DEFAULT_CONTACT_POSITION_AXIS_WEIGHT = 50.0
_STABLE_PINCH_MIN_FRAMES = 12
_STABLE_PINCH_MIN_LIFT_M = 0.010


def _composite_urdf_for_robot(robot: str) -> Path:
    try:
        return _ROBOT_COMPOSITE_URDFS[robot]
    except KeyError as exc:
        raise ValueError(
            f"Unknown robot {robot!r}; choose one of "
            f"{', '.join(_ROBOT_COMPOSITE_URDFS)}"
        ) from exc


def _collision_config_for_robot(robot: str) -> Path:
    try:
        return _ROBOT_COLLISION_CONFIGS[robot]
    except KeyError as exc:
        raise ValueError(
            f"Unknown robot {robot!r}; choose one of "
            f"{', '.join(_ROBOT_COLLISION_CONFIGS)}"
        ) from exc


def _hand_generation_for_robot(robot: str) -> str:
    """SDK hand model for a composite arm preset: hand1 or hand2."""

    try:
        return _ROBOT_HAND_GENERATION[robot]
    except KeyError as exc:
        raise ValueError(
            f"Unknown robot {robot!r}; choose one of "
            f"{', '.join(_ROBOT_HAND_GENERATION)}"
        ) from exc


def _normalize_yaml_arm(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(
            "Batch YAML 'arm' must be one of "
            f"{', '.join(_ROBOT_COMPOSITE_URDFS)}"
        )
    arm = value.strip()
    if arm not in _ROBOT_COMPOSITE_URDFS:
        raise ValueError(
            f"Batch YAML 'arm' must be one of "
            f"{', '.join(_ROBOT_COMPOSITE_URDFS)}, got {value!r}"
        )
    return arm


def _replay_composite_urdf(
    replay_data: Mapping[str, np.ndarray] | None,
    replay: Path | None,
    fallback: str | Path | None = None,
) -> Path:
    stored = None
    if replay_data is not None:
        stored = replay_data.get("composite_urdf_path")
    elif replay is not None and Path(replay).is_file():
        with np.load(replay, allow_pickle=True) as archive:
            stored = archive.get("composite_urdf_path")
    if stored is not None:
        array = np.asarray(stored)
        if array.ndim == 0 and str(array.item()):
            candidate = Path(str(array.item())).expanduser()
            if candidate.is_file():
                return candidate
    if fallback is not None:
        return Path(fallback).expanduser().resolve()
    return _DEFAULT_COMPOSITE_URDF


def _contiguous_true_runs(mask: np.ndarray) -> list[tuple[int, int, int]]:
    values = np.asarray(mask, dtype=bool).reshape(-1)
    runs: list[tuple[int, int, int]] = []
    start: int | None = None
    for index, active in enumerate(np.concatenate((values, [False]))):
        if active and start is None:
            start = index
        elif not active and start is not None:
            runs.append((start, index - 1, index - start))
            start = None
    return runs


def _stable_pinch_runs(
    replay: Mapping[str, np.ndarray],
    side: str,
) -> list[tuple[int, int, int]]:
    """Return grasp runs long enough to include an actual lift arc."""

    mask = np.asarray(
        replay.get(f"{side}_pinch_frame_mask", np.zeros(0, dtype=bool)),
        dtype=bool,
    )
    position = np.asarray(
        replay.get(f"{side}_wrist_position_base", np.empty((0, 3))),
        dtype=np.float64,
    )
    if mask.ndim != 1 or position.ndim != 2 or position.shape != (len(mask), 3):
        return []
    stable: list[tuple[int, int, int]] = []
    for start, end, length in _contiguous_true_runs(mask):
        if length < _STABLE_PINCH_MIN_FRAMES:
            continue
        z = position[start : end + 1, 2]
        if np.all(np.isfinite(z)) and float(np.ptp(z)) >= _STABLE_PINCH_MIN_LIFT_M:
            stable.append((start, end, length))
    return stable


def _validate_two_grasp_contact(
    replay: Mapping[str, np.ndarray],
) -> tuple[bool, str]:
    """Require an open-close-open-close-open sequence with two stable phases."""

    per_side = {
        side: _stable_pinch_runs(replay, side) for side in ("left", "right")
    }
    sequence = {}
    for side in ("left", "right"):
        mask = np.asarray(replay.get(f"{side}_pinch_frame_mask", []), dtype=bool).reshape(-1)
        changes = np.diff(mask.astype(np.int8)) if len(mask) else np.empty(0, dtype=np.int8)
        sequence[side] = bool(
            len(mask) > 0 and not mask[0] and not mask[-1]
            and np.count_nonzero(changes == 1) >= 2
            and np.count_nonzero(changes == -1) >= 2
        )
    if any(len(runs) >= 2 and sequence[side] for side, runs in per_side.items()):
        detail = "; ".join(
            f"{side}={[(a, b, n) for a, b, n in runs]}"
            for side, runs in per_side.items()
            if runs and sequence[side]
        )
        return True, detail or "two stable grasp phases"
    detail = "; ".join(
        f"{side}={[(a, b, n) for a, b, n in runs]}, sequence={sequence[side]}"
        for side, runs in per_side.items()
    )
    return False, f"missing open-close-open-close-open stable contact sequence ({detail})"


_RAW_TO_MANO21 = np.asarray(
    [0, 5, 6, 7, 8, 9, 10, 11, 12, 17, 18, 19, 20, 13, 14, 15, 16, 1, 2, 3, 4],
    dtype=np.int64,
)
_LOG = logging.getLogger("v2.batch_replay")
_STALE_HANDLE_ERRNOS = {116, getattr(errno, "ESTALE", 116)}


class _ResilientFileHandler(logging.FileHandler):
    """Reopen the log file after NFS/CPFS stale-handle errors.

    ``FileHandler.flush`` on a CPFS path can raise ``OSError: [Errno 116]``
    mid-batch.  The stdlib then prints ``--- Logging error ---`` even though
    the episode succeeded.  Reopen once; if that still fails, drop the file
    stream so later records stay on stderr/stdout.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _chmod_world_writable(Path(self.baseFilename))

    def _open(self):
        stream = super()._open()
        _chmod_world_writable(Path(self.baseFilename))
        return stream

    def _is_stale(self, exc: BaseException) -> bool:
        return isinstance(exc, OSError) and getattr(exc, "errno", None) in (
            _STALE_HANDLE_ERRNOS
        )

    def _reopen_stream(self) -> None:
        stream = self.stream
        self.stream = None
        if stream is not None:
            try:
                stream.close()
            except OSError:
                pass
        self.stream = self._open()

    def flush(self) -> None:
        try:
            super().flush()
        except OSError as exc:
            if not self._is_stale(exc):
                raise
            try:
                self._reopen_stream()
            except OSError:
                self.stream = None

    def emit(self, record: logging.LogRecord) -> None:
        if self.stream is None:
            return
        try:
            msg = self.format(record)
            self.stream.write(msg + self.terminator)
            self.flush()
        except RecursionError:
            raise
        except OSError as exc:
            if not self._is_stale(exc):
                self.handleError(record)
                return
            try:
                self._reopen_stream()
                if self.stream is None:
                    return
                self.stream.write(self.format(record) + self.terminator)
                super().flush()
            except OSError:
                self.stream = None
        except Exception:
            self.handleError(record)


@dataclass(frozen=True)
class GpuInfo:
    """A CUDA device in the process-local namespace."""

    device: str
    selector: str
    free_mib: int | None


@dataclass(frozen=True)
class EpisodeResult:
    episode: str
    output: str
    log: str
    device: str
    status: str
    duration_seconds: float
    trajectory_solve_seconds: float = 0.0
    ik_successes: int = 0
    ik_total: int = 0
    ik_failures: int = 0
    interpolated_videos: tuple[str, ...] = ()


@dataclass(frozen=True)
class BatchInput:
    """A local collection or a remotely streamed collection cache."""

    root: Path
    remote_path: str | None = None
    remote_episode_names: tuple[str, ...] = ()

    @property
    def streams_remote_episodes(self) -> bool:
        return self.remote_path is not None


@dataclass(frozen=True)
class BatchYamlConfig:
    """Batch-selection and timing values owned by the YAML file."""

    folders: tuple[str, ...]
    output: str
    num_per_folder: int | None
    fps: float
    move_from_start: bool
    random_seed: int | None = None
    thumb_table_clearance_m: float | None = None
    interpolation_max_velocity: float | None = None
    interpolation_max_hand_velocity: float | None = None
    interpolation_max_acceleration: float | None = None
    interpolation_max_hand_acceleration: float | None = None
    left_hand_urdf: str | None = None
    right_hand_urdf: str | None = None
    left_glove_urdf: str | None = None
    right_glove_urdf: str | None = None
    grasp_type: int | None = None
    which_to_track: str = "mcp"
    anchor: str = "mcp"
    retarget_weight: str = "normal"
    model_config: str | None = None
    arm: str = _DEFAULT_ROBOT
    initial_position: tuple[float, float, float] | None = None


def _worker_prefix() -> list[str]:
    """Choose the dependency interpreter without ``conda run`` startup tax."""

    if _WORKER_PYTHON:
        return [_WORKER_PYTHON]
    # Non-interactive SSH and container entrypoints often preserve the active
    # interpreter but drop CONDA_DEFAULT_ENV.  sys.prefix remains authoritative;
    # otherwise we may accidentally select a same-named /workspace environment
    # that exists but does not contain the replay dependencies.
    if (
        os.environ.get("CONDA_DEFAULT_ENV") == _CONDA_ENV
        or Path(sys.prefix).name == _CONDA_ENV
    ):
        return [sys.executable]
    conda_python = (
        Path(_CONDA).expanduser().resolve().parent.parent
        / "envs"
        / _CONDA_ENV
        / "bin"
        / "python"
    )
    if conda_python.is_file():
        return [str(conda_python)]
    return [
        _CONDA,
        "run",
        "--no-capture-output",
        "-n",
        _CONDA_ENV,
        "python",
    ]


def _query_physical_gpus() -> list[tuple[str, str, int]]:
    """Return ``(index, uuid, free_mib)`` without importing CUDA libraries."""

    try:
        completed = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=index,uuid,memory.free",
                "--format=csv,noheader,nounits",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return []

    result: list[tuple[str, str, int]] = []
    for line in completed.stdout.splitlines():
        fields = [field.strip() for field in line.split(",")]
        if len(fields) != 3:
            continue
        try:
            free_mib = int(fields[2])
        except ValueError:
            continue
        result.append((fields[0], fields[1], free_mib))
    return result


def _visible_selectors(physical: Sequence[tuple[str, str, int]]) -> list[str]:
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if visible == "-1":
        return []
    if visible:
        return [value.strip() for value in visible.split(",") if value.strip()]
    return [index for index, _, _ in physical]


def _gpu_inventory() -> list[GpuInfo]:
    physical = _query_physical_gpus()
    free_by_selector: dict[str, int] = {}
    for index, uuid, free_mib in physical:
        free_by_selector[index] = free_mib
        free_by_selector[uuid] = free_mib

    selectors = _visible_selectors(physical)
    return [
        GpuInfo(
            device=f"cuda:{local_index}",
            selector=selector,
            free_mib=free_by_selector.get(selector),
        )
        for local_index, selector in enumerate(selectors)
    ]


def _selected_gpu_info(devices: Sequence[str]) -> list[GpuInfo]:
    inventory = {gpu.device: gpu for gpu in _gpu_inventory()}
    result: list[GpuInfo] = []
    for device in devices:
        if not device.startswith("cuda:"):
            raise ValueError(
                f"Batch replay requires CUDA devices such as cuda:0, got {device!r}"
            )
        try:
            local_index = int(device.split(":", 1)[1])
        except ValueError as exc:
            raise ValueError(f"Invalid CUDA device {device!r}") from exc
        if local_index < 0:
            raise ValueError(f"Invalid CUDA device {device!r}")
        result.append(
            inventory.get(
                device,
                GpuInfo(device=device, selector=str(local_index), free_mib=None),
            )
        )
    return result


# ``tempfile.mkdtemp`` appends 8 characters from this alphabet.
_STAGING_SUFFIX_ALPHABET = set("abcdefghijklmnopqrstuvwxyz0123456789_")


def _is_leaked_staging_name(name: str) -> bool:
    """True for ``.{episode}.{suffix}`` and ``.{episode}.download.{suffix}``."""

    stem, dot, suffix = name.rpartition(".")
    return (
        dot == "."
        and stem.startswith(".")
        and len(stem) > 1
        and len(suffix) == 8
        and all(character in _STAGING_SUFFIX_ALPHABET for character in suffix)
    )


def _remove_leaked_staging_directories(root: Path) -> int:
    """Delete unfinished mkdtemp directories left in a published root.

    Staging lives next to finished episodes so the final rename stays on one
    filesystem.  A worker that dies inside the in-process solve never reaches
    its ``finally`` block, and the ``.{episode}.{suffix}`` directory would
    otherwise stay beside the successful publish.  Those directories are not
    episodes: they still hold source symlinks and a truncated log, and they
    do not appear in the IK table.
    """

    if not root.is_dir():
        return 0
    removed = 0
    for child in list(root.iterdir()):
        if child.is_symlink() or not child.is_dir():
            continue
        if not _is_leaked_staging_name(child.name):
            continue
        if _is_complete_episode_directory(child):
            continue
        try:
            shutil.rmtree(child)
        except OSError as exc:
            print(
                f"[batch_replay] failed to remove leftover staging {child.name}: {exc}",
                flush=True,
            )
            continue
        removed += 1
        print(
            f"[batch_replay] removed leftover staging directory {child.name}",
            flush=True,
        )
    return removed


def _discover_episodes(root: Path) -> tuple[list[Path], list[Path]]:
    episodes: list[Path] = []
    invalid: list[Path] = []
    for child in sorted(path for path in root.iterdir() if path.is_dir()):
        if _is_leaked_staging_name(child.name):
            continue
        main_json = child / data_format.episode_json_name(child.name)
        partial_json = child / f"{data_format.episode_json_name(child.name)}.obdownload"
        (episodes if main_json.is_file() or partial_json.is_file() else invalid).append(
            child
        )
    return episodes, invalid


def _normalize_ik_anchor(value: object, *, key: str) -> str:
    from wuji_retarget.hand_retarget import normalize_ik_anchor

    try:
        return normalize_ik_anchor(value, field=f"Batch YAML '{key}'")
    except ValueError as exc:
        raise ValueError(str(exc)) from exc


def _sdk_model_config_path(path: str | Path | None = None) -> Path | None:
    """Resolve an explicit wuji-v3 SDK model JSON, if one was requested.

    Glove URDFs are the model input. Omitting the path does not fall back
    to a default JSON or to GEORT_WUJI_MODEL_CONFIG.
    """

    if path is None or not str(path).strip():
        return None
    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"Wuji SDK model config missing: {resolved}")
    return resolved


def _sdk_env_updates(path: str | Path | None = None) -> dict[str, str]:
    resolved = _sdk_model_config_path(path)
    if resolved is None:
        return {}
    return {"GEORT_WUJI_MODEL_CONFIG": str(resolved)}


def _optional_yaml_path(
    payload: Mapping[str, Any],
    key: str,
    *,
    yaml_dir: Path,
) -> str | None:
    """Return an optional existing file path, or None to keep the default."""

    if key not in payload or payload[key] is None:
        return None
    raw = payload[key]
    if not isinstance(raw, str):
        raise ValueError(f"Batch YAML '{key}' must be a path string or null")
    text = raw.strip()
    if not text:
        return None
    path = Path(text).expanduser()
    path = path.resolve() if path.is_absolute() else (yaml_dir / path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Batch YAML '{key}' is not a file: {path}")
    return str(path)


def _optional_yaml_urdf(
    payload: Mapping[str, Any],
    key: str,
    *,
    yaml_dir: Path,
) -> str | None:
    """Return an optional existing URDF path, or None to keep the default map."""

    return _optional_yaml_path(payload, key, yaml_dir=yaml_dir)


def _optional_yaml_xyz(value: object, key: str) -> tuple[float, float, float] | None:
    """Parse optional YAML ``[x, y, z]`` metres, or None to keep the URDF seed."""

    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(f"Batch YAML '{key}' must be [x, y, z] metres or null")
    parsed: list[float] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise ValueError(f"Batch YAML '{key}' must be three finite numbers")
        number = float(item)
        if not math.isfinite(number):
            raise ValueError(f"Batch YAML '{key}' must be three finite numbers")
        parsed.append(number)
    return (parsed[0], parsed[1], parsed[2])


def _load_batch_yaml(path: Path) -> BatchYamlConfig:
    """Load the deliberately small, strict batch YAML schema."""

    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError("PyYAML is required to read batch replay YAML") from exc

    resolved = path.expanduser().resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"Batch YAML does not exist: {resolved}")
    payload = yaml.safe_load(resolved.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Batch YAML must contain a mapping: {resolved}")
    allowed = {
        "list",
        "output",
        "num_per_folder",
        "fps",
        "move_from_start",
        "random_seed",
        "thumb_table_clearance_m",
        "interpolation_max_velocity", "interpolation_max_hand_velocity",
        "interpolation_max_acceleration", "interpolation_max_hand_acceleration",
        "left_hand_urdf",
        "right_hand_urdf",
        "left_glove_urdf",
        "right_glove_urdf",
        "grasp_type",
        "which_to_track",
        "anchor",
        "retarget_weight",
        "retargeting_solver",
        "model_config",
        "arm",
        "initial_position",
    }
    unknown = sorted(str(key) for key in payload if key not in allowed)
    if unknown:
        raise ValueError(f"Unknown batch YAML keys: {', '.join(unknown)}")
    missing = sorted(
        key
        for key in (
            "list",
            "output",
            "num_per_folder",
            "fps",
            "move_from_start",
            "arm",
        )
        if key not in payload
    )
    if missing:
        raise ValueError(f"Batch YAML is missing keys: {', '.join(missing)}")

    raw_folders = payload["list"]
    if not isinstance(raw_folders, list) or not raw_folders:
        raise ValueError("Batch YAML 'list' must be a non-empty list")
    folders: list[str] = []
    folder_names: set[str] = set()
    for value in raw_folders:
        if not isinstance(value, str):
            raise ValueError("Every batch YAML 'list' item must be a string")
        raw_folder = value.strip()
        posix_folder = PurePosixPath(raw_folder)
        folder_name = _safe_episode_name(posix_folder.name)
        if not posix_folder.is_absolute() and raw_folder != folder_name:
            raise ValueError(
                "Relative batch YAML 'list' items must be folder basenames; "
                f"got {value!r}"
            )
        if folder_name in folder_names:
            raise ValueError(
                f"Batch YAML contains duplicate folder basename {folder_name!r}"
            )
        folder_names.add(folder_name)
        folders.append(posix_folder.as_posix())

    raw_output = payload["output"]
    if not isinstance(raw_output, str) or not raw_output.strip():
        raise ValueError("Batch YAML 'output' must be an absolute POSIX path")
    output_path = PurePosixPath(raw_output.strip())
    if not output_path.is_absolute():
        raise ValueError("Batch YAML 'output' must be an absolute POSIX path")
    if any(character in raw_output for character in "\x00\r\n"):
        raise ValueError("Batch YAML 'output' contains invalid characters")
    output = output_path.as_posix()

    raw_count = payload["num_per_folder"]
    if raw_count is None:
        num_per_folder = None
    elif isinstance(raw_count, bool) or not isinstance(raw_count, int):
        raise ValueError("Batch YAML 'num_per_folder' must be a positive integer or null")
    elif raw_count < 1:
        raise ValueError("Batch YAML 'num_per_folder' must be >= 1")
    else:
        num_per_folder = raw_count

    raw_fps = payload["fps"]
    if isinstance(raw_fps, bool) or not isinstance(raw_fps, (int, float)):
        raise ValueError("Batch YAML 'fps' must be a positive number")
    fps = float(raw_fps)
    if not math.isfinite(fps) or fps <= 0.0:
        raise ValueError("Batch YAML 'fps' must be finite and positive")
    move_from_start = payload["move_from_start"]
    if not isinstance(move_from_start, bool):
        raise ValueError("Batch YAML 'move_from_start' must be true or false")
    raw_seed = payload.get("random_seed")
    if raw_seed is not None and (
        isinstance(raw_seed, bool) or not isinstance(raw_seed, int)
    ):
        raise ValueError("Batch YAML 'random_seed' must be an integer or null")
    raw_clearance = payload.get("thumb_table_clearance_m")
    if raw_clearance is not None and (isinstance(raw_clearance, bool) or not isinstance(raw_clearance, (int, float)) or not math.isfinite(float(raw_clearance)) or float(raw_clearance) < 0.0):
        raise ValueError("Batch YAML 'thumb_table_clearance_m' must be a finite non-negative number or null")
    if "anchor" in payload and payload["anchor"] is not None:
        anchor = _normalize_ik_anchor(payload["anchor"], key="anchor")
        if "which_to_track" in payload and payload["which_to_track"] is not None:
            tracked = _normalize_ik_anchor(
                payload["which_to_track"], key="which_to_track"
            )
            if tracked != anchor:
                raise ValueError(
                    "Batch YAML 'anchor' and 'which_to_track' disagree: "
                    f"{payload['anchor']!r} vs {payload['which_to_track']!r}"
                )
    elif "which_to_track" in payload and payload["which_to_track"] is not None:
        anchor = _normalize_ik_anchor(
            payload["which_to_track"], key="which_to_track"
        )
    else:
        anchor = "mcp"
    which_to_track = {
        "thumb_tip": "thumb",
        "wrist": "wrist",
        "fingertips": "fingertips",
        "tips": "tips",
        "mcp": "mcp",
    }.get(anchor, "mcp")
    if "retarget_weight" in payload and payload["retarget_weight"] is not None:
        from wuji2_retarget.official_retarget import normalize_retarget_weight

        retarget_weight = normalize_retarget_weight(
            payload["retarget_weight"], field="Batch YAML 'retarget_weight'"
        )
    else:
        retarget_weight = "normal"
    raw_grasp = payload.get("grasp_type")
    if raw_grasp is None:
        grasp_type = None
    elif isinstance(raw_grasp, bool) or not isinstance(raw_grasp, int):
        raise ValueError("Batch YAML 'grasp_type' must be an integer in [1, 33] or null")
    elif raw_grasp < 1 or raw_grasp > 33:
        raise ValueError("Batch YAML 'grasp_type' must be in [1, 33] or null")
    else:
        grasp_type = raw_grasp
    left_glove_urdf = _optional_yaml_urdf(
        payload, "left_glove_urdf", yaml_dir=resolved.parent
    )
    right_glove_urdf = _optional_yaml_urdf(
        payload, "right_glove_urdf", yaml_dir=resolved.parent
    )
    left_hand_urdf = _optional_yaml_urdf(
        payload, "left_hand_urdf", yaml_dir=resolved.parent
    )
    right_hand_urdf = _optional_yaml_urdf(
        payload, "right_hand_urdf", yaml_dir=resolved.parent
    )
    if payload.get("retargeting_solver") is not None:
        print(
            "[batch_replay] ignoring YAML retargeting_solver; "
            "finger q uses the pinned wuji-v3 SDK offline pipeline",
            flush=True,
        )
    model_config = _optional_yaml_path(
        payload, "model_config", yaml_dir=resolved.parent
    )
    arm = _normalize_yaml_arm(payload["arm"])
    initial_position = _optional_yaml_xyz(payload.get("initial_position"), "initial_position")
    return BatchYamlConfig(
        folders=tuple(folders),
        output=output,
        num_per_folder=num_per_folder,
        fps=fps,
        move_from_start=move_from_start,
        random_seed=raw_seed,
        thumb_table_clearance_m=None if raw_clearance is None else float(raw_clearance),
        interpolation_max_velocity=payload.get("interpolation_max_velocity"),
        interpolation_max_hand_velocity=payload.get("interpolation_max_hand_velocity"),
        interpolation_max_acceleration=payload.get("interpolation_max_acceleration"),
        interpolation_max_hand_acceleration=payload.get("interpolation_max_hand_acceleration"),
        left_hand_urdf=left_hand_urdf,
        right_hand_urdf=right_hand_urdf,
        left_glove_urdf=left_glove_urdf,
        right_glove_urdf=right_glove_urdf,
        grasp_type=grasp_type,
        which_to_track=which_to_track,
        anchor=anchor,
        retarget_weight=retarget_weight,
        model_config=model_config,
        arm=arm,
        initial_position=initial_position,
    )


def _sample_episodes(
    episodes: Sequence[Path],
    count: int | None,
    *,
    seed: int | None,
    folder_name: str,
) -> list[Path]:
    """Randomly select a bounded episode set, stably when a seed is supplied."""

    values = list(episodes)
    if count is None or count >= len(values):
        return values
    if seed is None:
        generator = random.SystemRandom()
    else:
        digest = hashlib.sha256(f"{seed}\0{folder_name}".encode("utf-8")).digest()
        generator = random.Random(int.from_bytes(digest[:8], "big"))
    return sorted(generator.sample(values, count), key=lambda path: path.name)


def _ssh_target(host: str, user: str | None) -> str:
    return f"{user}@{host}" if user else host


def _ssh_options(args: argparse.Namespace) -> list[str]:
    options = [
        "-p",
        str(args.remote_port),
        "-o",
        f"ConnectTimeout={args.ssh_connect_timeout}",
        "-o",
        "ServerAliveInterval=15",
        "-o",
        "ServerAliveCountMax=2",
    ]
    if not args.ssh_interactive:
        options.extend(("-o", "BatchMode=yes"))
    return options


def _validate_remote_match(path: str, remote_root: PurePosixPath) -> str:
    candidate = PurePosixPath(path)
    if not candidate.is_absolute():
        raise RuntimeError(f"Remote search returned a non-absolute path: {path!r}")
    try:
        candidate.relative_to(remote_root)
    except ValueError as exc:
        raise RuntimeError(
            f"Remote search escaped configured root {remote_root}: {path!r}"
        ) from exc
    return candidate.as_posix()


def _literal_find_pattern(name: str) -> str:
    """Escape GNU find's glob metacharacters for an exact basename match."""

    return "".join(
        f"\\{character}" if character in r"\*?[]" else character
        for character in name
    )


def _find_remote_directory(
    folder_name: str, args: argparse.Namespace
) -> str:
    remote_root = PurePosixPath(args.remote_root)
    if not remote_root.is_absolute():
        raise ValueError("--remote-root must be an absolute POSIX path")
    target = _ssh_target(args.remote_host, args.remote_user)
    direct_candidate = remote_root / folder_name
    quoted_candidate = shlex.quote(direct_candidate.as_posix())
    direct_command = (
        f"if test -d {quoted_candidate}; then "
        f"printf '%s\\n' {quoted_candidate}; fi"
    )
    try:
        direct = subprocess.run(
            ["ssh", *_ssh_options(args), target, direct_command],
            check=True,
            capture_output=True,
            text=True,
            timeout=args.remote_timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("ssh executable was not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            "Direct remote directory check timed out after "
            f"{args.remote_timeout:g}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise RuntimeError(
            f"Direct remote directory check failed with exit code {exc.returncode}"
            + (f": {detail}" if detail else "")
        ) from exc

    direct_match = direct.stdout.strip()
    if direct_match:
        return _validate_remote_match(direct_match, remote_root)

    remote_command = shlex.join(
        [
            "find",
            remote_root.as_posix(),
            "-type",
            "d",
            "-name",
            _literal_find_pattern(folder_name),
            "-print",
        ]
    )
    command = ["ssh", *_ssh_options(args), target, remote_command]
    print(
        "[batch_replay] local test_data not found; searching remote: "
        f"{target}:{remote_root}/{folder_name}",
        flush=True,
    )
    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=args.remote_timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("ssh executable was not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Remote directory search timed out after {args.remote_timeout:g}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise RuntimeError(
            f"Remote directory search failed with exit code {exc.returncode}"
            + (f": {detail}" if detail else "")
        ) from exc

    matches = sorted(
        {
            _validate_remote_match(line.strip(), remote_root)
            for line in completed.stdout.splitlines()
            if line.strip()
        }
    )
    if not matches:
        raise FileNotFoundError(
            f"No directory named {folder_name!r} below {remote_root} on {target}"
        )
    if len(matches) > 1:
        formatted = "\n  ".join(matches)
        raise RuntimeError(
            f"Remote folder name {folder_name!r} is ambiguous; matches:\n  "
            f"{formatted}"
        )
    return matches[0]


def _download_remote_test_data(
    remote_path: str,
    destination: Path,
    args: argparse.Namespace,
) -> None:
    _ensure_world_writable_dir(destination)
    target = _ssh_target(args.remote_host, args.remote_user)
    ssh_command = shlex.join(["ssh", *_ssh_options(args)])
    # A quoted remote path is interpreted by rsync's remote shell, not by the
    # local process (subprocess is deliberately invoked without shell=True).
    source = f"{target}:{shlex.quote(remote_path.rstrip('/') + '/')}"
    command = [
        "rsync",
        "-a",
        "--partial",
        "--prune-empty-dirs",
        "--info=progress2",
        "-e",
        ssh_command,
        "--include=*/",
        "--include=*.json",
        "--include=*.json.obdownload",
        "--include=*.mp4",
        "--include=*.MP4",
        "--include=*.h5",
        "--include=*.npy",
        "--include=*.yaml",
        "--include=*.yml",
        "--exclude=*",
        source,
        str(destination) + os.sep,
    ]
    print(
        f"[batch_replay] downloading JSON and MP4 files to {destination}",
        flush=True,
    )
    try:
        subprocess.run(command, cwd=str(_PKG_ROOT), check=True)
    except FileNotFoundError as exc:
        raise RuntimeError("rsync executable was not found") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Remote download failed with rsync exit code {exc.returncode}; "
            f"partial files remain in {destination} for the next retry"
        ) from exc

    episodes, _ = _discover_episodes(destination)
    if not episodes:
        raise RuntimeError(
            f"Remote download produced no episode subdirectory with JSON: "
            f"{destination}"
        )
    marker = destination / _REMOTE_FETCH_MARKER
    marker.write_text(
        json.dumps(
            {
                "remote": f"{target}:{remote_path}",
                "downloaded_extensions": [
                    ".json",
                    ".json.obdownload",
                    ".mp4",
                    ".MP4",
                    ".h5",
                    ".npy",
                    ".yaml",
                    ".yml",
                ],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    _chmod_tree_world_writable(destination)


def _safe_episode_name(name: str) -> str:
    if (
        not name
        or name in {".", ".."}
        or Path(name).name != name
        or any(character in name for character in "\x00\r\n")
    ):
        raise ValueError(f"Unsafe episode directory name: {name!r}")
    return name


def _list_remote_episode_names(
    remote_path: str, args: argparse.Namespace
) -> tuple[str, ...]:
    """List direct child directories containing their own episode JSON."""

    collection = PurePosixPath(remote_path)
    target = _ssh_target(args.remote_host, args.remote_user)
    remote_command = shlex.join(
        [
            "find",
            collection.as_posix(),
            "-mindepth", "2",
            "-maxdepth", "2",
            "-type", "f",
            "(", "-name", "*.json", "-o", "-name", "*.json.obdownload", ")",
            "-print",
        ]
    )
    try:
        completed = subprocess.run(
            ["ssh", *_ssh_options(args), target, remote_command],
            check=True,
            capture_output=True,
            text=True,
            timeout=args.remote_timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("ssh executable was not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Remote episode listing timed out after {args.remote_timeout:g}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise RuntimeError(
            f"Remote episode listing failed with exit code {exc.returncode}"
            + (f": {detail}" if detail else "")
        ) from exc

    names: set[str] = set()
    for line in completed.stdout.splitlines():
        candidate = PurePosixPath(line.strip())
        episode = candidate.parent
        if not candidate.is_absolute() or episode.parent != collection:
            continue
        name = _safe_episode_name(episode.name)
        episode_json = data_format.episode_json_name(name)
        if candidate.name in {episode_json, f"{episode_json}.obdownload"}:
            names.add(name)
    if not names:
        raise RuntimeError(f"Remote collection contains no episode JSON: {target}:{remote_path}")
    return tuple(sorted(names))


def _remote_rsync_prefix(args: argparse.Namespace) -> tuple[str, str]:
    target = _ssh_target(args.remote_host, args.remote_user)
    ssh_command = shlex.join(["ssh", *_ssh_options(args)])
    return target, ssh_command


def _episode_cache_complete(path: Path) -> bool:
    return (
        path.is_dir()
        and (path / _REMOTE_EPISODE_MARKER).is_file()
        and (path / data_format.episode_json_name(path.name)).is_file()
        and (path / WUJI_GLOVE_OFFLINE_H5).is_file()
        and all((path / name).is_file() for name in _SOURCE_VIDEO_NAMES)
    )


def _download_remote_collection_metadata(
    remote_path: str, destination: Path, args: argparse.Namespace
) -> None:
    """Fetch only small collection-level metadata used as episode fallbacks."""

    _ensure_world_writable_dir(destination)
    target, ssh_command = _remote_rsync_prefix(args)
    source = f"{target}:{shlex.quote(remote_path.rstrip('/') + '/')}"
    command = [
        "rsync", "-a", "--partial", "-e", ssh_command,
        "--include=diversity.json",
        "--include=instruction.json",
        "--include=instruction_meta.json",
        "--include=*.yaml",
        "--include=*.yml",
        "--exclude=*/",
        "--exclude=*",
        source,
        str(destination) + os.sep,
    ]
    try:
        subprocess.run(command, cwd=str(_PKG_ROOT), check=True)
    except FileNotFoundError as exc:
        raise RuntimeError("rsync executable was not found") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Remote collection metadata download failed with rsync exit code "
            f"{exc.returncode}"
        ) from exc
    _chmod_tree_world_writable(destination)


def _download_remote_episode(
    remote_collection: str,
    episode_name: str,
    destination_root: Path,
    args: argparse.Namespace,
) -> Path:
    """Download one complete episode and mark it as owned remote cache."""

    episode_name = _safe_episode_name(episode_name)
    destination = destination_root / episode_name
    if _episode_cache_complete(destination) and not args.refresh_remote:
        return destination
    if destination.exists() and not (destination / _REMOTE_EPISODE_MARKER).is_file():
        raise RuntimeError(f"Refusing to overwrite unowned episode cache: {destination}")
    final_destination = destination
    _ensure_world_writable_dir(destination_root)
    destination = Path(tempfile.mkdtemp(prefix=f".{episode_name}.download.", dir=destination_root))
    _chmod_world_writable(destination)
    try:
        marker = destination / _REMOTE_EPISODE_MARKER
        target, ssh_command = _remote_rsync_prefix(args)
        remote_episode = f"{remote_collection.rstrip('/')}/{episode_name}/"
        source = f"{target}:{shlex.quote(remote_episode)}"
        command = [
            "rsync", "-a", "--partial", "--info=progress2", "-e", ssh_command,
            "--include=*/",
            "--include=*.json",
            "--include=*.json.obdownload",
            "--include=*.mp4",
            "--include=*.MP4",
            "--include=*.h5",
            "--include=*.npy",
            "--include=*.yaml",
            "--include=*.yml",
            "--exclude=*",
            source,
            str(destination) + os.sep,
        ]
        _LOG.info("Downloading remote episode %s", episode_name)
        try:
            subprocess.run(command, cwd=str(_PKG_ROOT), check=True)
        except FileNotFoundError as exc:
            raise RuntimeError("rsync executable was not found") from exc
        except subprocess.CalledProcessError as exc:
            raise RuntimeError(
                f"Episode {episode_name} rsync failed with exit code {exc.returncode}; "
                f"partial cache will be removed"
            ) from exc

        required = [destination / data_format.episode_json_name(episode_name)] + [
            destination / name for name in _SOURCE_VIDEO_NAMES
        ] + [destination / WUJI_GLOVE_OFFLINE_H5]
        missing = [path.name for path in required if not path.is_file()]
        if missing:
            raise RuntimeError(
                f"Downloaded episode {episode_name} is incomplete; missing "
                + ", ".join(missing)
            )
        marker.write_text(
            json.dumps(
                {
                    "remote": f"{target}:{remote_episode}",
                    "episode": episode_name,
                },
                indent=2,
                ensure_ascii=False,
            )
            + "\n",
            encoding="utf-8",
        )
        if final_destination.exists():
            _cleanup_remote_episode_cache(final_destination, destination_root)
        os.replace(destination, final_destination)
        _chmod_tree_world_writable(final_destination)
        return final_destination
    finally:
        if destination.exists():
            shutil.rmtree(destination)


def _cleanup_remote_episode_cache(episode: Path, cache_root: Path) -> None:
    """Delete one verified, tool-owned episode cache and nothing else."""

    root = cache_root.resolve()
    if episode.is_symlink():
        raise RuntimeError(f"Refusing to clean symlinked episode cache: {episode}")
    candidate = episode.resolve()
    if candidate.parent != root or candidate.name != _safe_episode_name(candidate.name):
        raise RuntimeError(f"Episode cache is outside its resolved root: {episode}")
    if not (candidate / _REMOTE_EPISODE_MARKER).is_file():
        raise RuntimeError(f"Episode cache has no ownership marker: {candidate}")
    shutil.rmtree(candidate)


def _required_episode_output_names(episode_name: str) -> tuple[str, ...]:
    return data_format.required_episode_files(_safe_episode_name(episode_name))


def _remote_output_topic_path(remote_output_root: str) -> PurePosixPath:
    """Episode directories are published directly under the output root."""

    base = PurePosixPath(remote_output_root)
    if not base.is_absolute():
        raise ValueError("a remote output root must be an absolute POSIX path")
    return base


def _remote_complete_output_names(
    remote_topic: PurePosixPath, args: argparse.Namespace
) -> set[str]:
    """Return remotely published episode directories with every required file."""

    target = _ssh_target(args.remote_host, args.remote_user)
    quoted_topic = shlex.quote(remote_topic.as_posix())
    remote_command = (
        f"if test -d {quoted_topic}; then "
        f"find {quoted_topic} -mindepth 2 -maxdepth 2 -type f -print; fi"
    )
    try:
        completed = subprocess.run(
            ["ssh", *_ssh_options(args), target, remote_command],
            check=True,
            capture_output=True,
            text=True,
            timeout=args.remote_timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("ssh executable was not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Remote output listing timed out after {args.remote_timeout:g}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise RuntimeError(
            f"Remote output listing failed with exit code {exc.returncode}"
            + (f": {detail}" if detail else "")
        ) from exc

    files: dict[str, set[str]] = {}
    for line in completed.stdout.splitlines():
        candidate = PurePosixPath(line.strip())
        episode = candidate.parent
        if not candidate.is_absolute() or episode.parent != remote_topic:
            continue
        name = _safe_episode_name(episode.name)
        files.setdefault(name, set()).add(candidate.name)
    return {
        name
        for name, present in files.items()
        if set(_required_episode_output_names(name)).issubset(present)
    }


def _upload_remote_episode_output(
    local_episode: Path,
    remote_topic: PurePosixPath,
    args: argparse.Namespace,
) -> PurePosixPath:
    """Upload one verified output directory and verify its remote file set."""

    if not _is_complete_episode_directory(local_episode):
        raise RuntimeError(f"Local episode output is incomplete: {local_episode}")
    episode_name = _safe_episode_name(local_episode.name)
    remote_episode = remote_topic / episode_name
    target, ssh_command = _remote_rsync_prefix(args)
    try:
        writable_directories = (
            remote_topic.parent.parent,
            remote_topic.parent,
            remote_topic,
            remote_episode,
        )
        prepare_remote = " && ".join(
            (
                shlex.join(["mkdir", "-p", remote_episode.as_posix()]),
                shlex.join(
                    [
                        "chmod",
                        "777",
                        *(path.as_posix() for path in writable_directories),
                    ]
                ),
            )
        )
        subprocess.run(
            [
                "ssh", *_ssh_options(args), target,
                prepare_remote,
            ],
            check=True,
            timeout=args.remote_timeout,
        )
        subprocess.run(
            [
                "rsync", "-a", "--partial", "--info=progress2",
                f"--chmod={_REMOTE_OUTPUT_RSYNC_CHMOD}",
                "-e", ssh_command,
                "--include=*.json",
                "--include=*.npy",
                "--include=*.mp4",
                "--exclude=*",
                str(local_episode) + os.sep,
                f"{target}:{shlex.quote(remote_episode.as_posix() + '/')}",
            ],
            cwd=str(_PKG_ROOT),
            check=True,
        )
        subprocess.run(
            [
                "ssh", *_ssh_options(args), target,
                shlex.join(["chmod", "-R", "777", remote_episode.as_posix()]),
            ],
            check=True,
            timeout=args.remote_timeout,
        )
        checks = " && ".join(
            shlex.join(["test", "-f", (remote_episode / name).as_posix()])
            for name in _required_episode_output_names(episode_name)
        )
        subprocess.run(
            ["ssh", *_ssh_options(args), target, checks],
            check=True,
            timeout=args.remote_timeout,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("ssh or rsync executable was not found") from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Remote output verification timed out after {args.remote_timeout:g}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Remote output upload failed for {episode_name} with exit code "
            f"{exc.returncode}; local output retained at {local_episode}"
        ) from exc
    return remote_episode


def _cleanup_local_episode_output(episode: Path, topic_root: Path) -> None:
    """Remove one verified child of the tool-owned local output topic."""

    root = topic_root.resolve()
    if episode.is_symlink():
        raise RuntimeError(f"Refusing to clean symlinked local output: {episode}")
    candidate = episode.resolve()
    if candidate.parent != root or not _is_complete_episode_directory(candidate):
        raise RuntimeError(f"Refusing to clean incomplete/out-of-root output: {episode}")
    shutil.rmtree(candidate)


def _upload_remote_topic_files(
    local_topic: Path,
    remote_topic: PurePosixPath,
    args: argparse.Namespace,
) -> None:
    """Upload small batch logs and indexes after episode publication."""

    target, ssh_command = _remote_rsync_prefix(args)
    try:
        prepare_remote = " && ".join(
            (
                shlex.join(["mkdir", "-p", remote_topic.as_posix()]),
                shlex.join(
                    [
                        "chmod",
                        "777",
                        remote_topic.parent.parent.as_posix(),
                        remote_topic.parent.as_posix(),
                        remote_topic.as_posix(),
                    ]
                ),
            )
        )
        subprocess.run(
            [
                "ssh", *_ssh_options(args), target,
                prepare_remote,
            ],
            check=True,
            timeout=args.remote_timeout,
        )
        subprocess.run(
            [
                "rsync", "-a", "--partial",
                f"--chmod={_REMOTE_OUTPUT_RSYNC_CHMOD}",
                "-e", ssh_command,
                "--include=*.json", "--include=*.txt", "--include=*.log",
                "--exclude=*/", "--exclude=*",
                str(local_topic) + os.sep,
                f"{target}:{shlex.quote(remote_topic.as_posix() + '/')}",
            ],
            cwd=str(_PKG_ROOT),
            check=True,
        )
        subprocess.run(
            [
                "ssh", *_ssh_options(args), target,
                shlex.join(["chmod", "-R", "777", remote_topic.as_posix()]),
            ],
            check=True,
            timeout=args.remote_timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"Remote topic metadata upload failed: {exc}") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Remote topic metadata upload failed with exit code {exc.returncode}"
        ) from exc


def _resolve_batch_input(args: argparse.Namespace) -> BatchInput:
    """Resolve local input or prepare a bounded remote streaming cache."""

    raw_value = args.test_data if args.test_data is not None else args.root
    if raw_value is None:
        raise ValueError("Provide test data as a positional path or with --test_data")
    requested = Path(raw_value).expanduser()
    # In forced-remote mode, ``raw_value`` is a path in the remote host's
    # namespace.  Do not stat it locally: an identically named mount may be
    # inaccessible (or trigger an automounter) before SSH gets a chance to
    # resolve the input.
    if not args.force_remote_lookup and requested.is_dir():
        return BatchInput(root=requested.resolve())
    if not args.force_remote_lookup and requested.exists():
        raise NotADirectoryError(requested)
    if args.no_remote_fetch:
        raise FileNotFoundError(f"Local test_data directory does not exist: {requested}")

    folder_name = _safe_episode_name(requested.name)
    remote_path = _find_remote_directory(folder_name, args)
    episode_names = _list_remote_episode_names(remote_path, args)
    destination = args.replay_data_dir.expanduser().resolve() / folder_name
    _ensure_world_writable_dir(destination)
    _download_remote_collection_metadata(remote_path, destination, args)
    (destination / _REMOTE_STREAM_MARKER).write_text(
        json.dumps(
            {
                "remote": f"{_ssh_target(args.remote_host, args.remote_user)}:{remote_path}",
                "episodes": len(episode_names),
                "prefetch_requested": args.remote_prefetch_count,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    _chmod_tree_world_writable(destination)
    return BatchInput(
        root=destination,
        remote_path=remote_path,
        remote_episode_names=episode_names,
    )


def _resolve_test_data(args: argparse.Namespace) -> Path:
    raw_value = args.test_data if args.test_data is not None else args.root
    if raw_value is None:
        raise ValueError("Provide test data as a positional path or with --test_data")
    requested = Path(raw_value).expanduser()
    if requested.is_dir():
        return requested.resolve()
    if requested.exists():
        raise NotADirectoryError(requested)
    if args.no_remote_fetch:
        raise FileNotFoundError(
            f"Local test_data directory does not exist: {requested}"
        )

    folder_name = requested.name
    if folder_name in {"", ".", ".."} or any(
        character in folder_name for character in "\x00\r\n"
    ):
        raise ValueError(f"Cannot derive a safe remote folder name from {raw_value!r}")
    replay_data_root = args.replay_data_dir.expanduser().resolve()
    destination = replay_data_root / folder_name
    marker = destination / _REMOTE_FETCH_MARKER
    if marker.is_file() and not args.refresh_remote:
        episodes, _ = _discover_episodes(destination)
        if episodes:
            print(
                f"[batch_replay] using downloaded test_data cache: {destination}",
                flush=True,
            )
            return destination

    remote_path = _find_remote_directory(folder_name, args)
    _download_remote_test_data(remote_path, destination, args)
    return destination


def _contains_option(values: Sequence[str], option: str) -> bool:
    return any(value == option or value.startswith(option + "=") for value in values)


def _normalise_forwarded_args(values: Sequence[str]) -> list[str]:
    forwarded = list(values)
    if forwarded and forwarded[0] == "--":
        forwarded = forwarded[1:]
    controlled = (
        "--test_data",
        "--tast_data",
        "--episode",
        "--cached_motion",
        "--npz",
        "--out",
        "--augment-only",
        "--device",
        "--laplacian_device",
        "--initial_position",
        "--intial_position",
        "--right_pinch_activation_distance",
        "--left_pinch_target_distance",
        "--right_pinch_target_distance",
        "--right_pinch_distance_weight",
        "--contact_position_x_weight",
        "--contact_position_y_weight",
        "--contact_position_z_weight",
        "--model_config",
        "--model-config",
        "--generation",
    )
    overlap = [
        option for option in controlled if _contains_option(forwarded, option)
    ]
    if overlap:
        raise ValueError(
            "batch_replay controls input, output, mode, and GPU assignment; "
            f"remove forwarded options: {', '.join(overlap)}"
    )
    return forwarded


def _batch_solver_defaults(
    composite_urdf: str | Path | None = None,
    collision_config: str | Path | None = None,
    generation: str | None = None,
    initial_position: Sequence[float] | None = None,
) -> list[str]:
    """Return optimizer and geometry defaults for every batch solve.

    The 1 mm pinch targets are intentional execution targets.  The Laplacian
    stage writes these geometry-selected targets back into the alignment
    fields consumed by the trajectory optimizer, so active-contact frames no longer
    inherit the (often larger) separation recorded in ``--test_data``.
    """

    urdf = Path(composite_urdf) if composite_urdf is not None else _DEFAULT_COMPOSITE_URDF
    collision = (
        Path(collision_config)
        if collision_config is not None
        else _DEFAULT_COLLISION_CONFIG
    )
    from wuji_retarget.wuji_hand_names import (
        detect_generation_from_urdf,
        resolve_hand_urdfs_for_composite,
    )

    hand_urdfs = resolve_hand_urdfs_for_composite(urdf)
    if generation is None:
        generation = detect_generation_from_urdf(urdf)
    urdf_generation = detect_generation_from_urdf(urdf)
    if generation != urdf_generation:
        raise ValueError(
            f"arm/hand generation {generation!r} does not match "
            f"composite URDF {urdf} ({urdf_generation})"
        )
    command = [
        "--composite_urdf",
        str(urdf),
        "--generation",
        generation,
        "--left_hand_urdf",
        str(hand_urdfs["left"]),
        "--right_hand_urdf",
        str(hand_urdfs["right"]),
    ]
    explicit_model_config = os.environ.get("GEORT_WUJI_MODEL_CONFIG")
    if explicit_model_config:
        command.extend(("--model_config", explicit_model_config))
    command.extend(
        [
        "--collision_config",
        str(collision),
        "--solver",
        "hjcd",
        "--alignment_solver",
        "warp",
        "--arm_ik_solver",
        "hjcd",
        "--laplacian_iterations",
        "30",
        "--left_pinch_target_distance",
        f"{_DEFAULT_FINGER_DISTANCE_M:g}",
        "--right_pinch_target_distance",
        f"{_DEFAULT_FINGER_DISTANCE_M:g}",
        "--right_pinch_activation_distance",
        f"{_DEFAULT_PINCH_ACTIVATION_DISTANCE_M:g}",
        "--right_pinch_distance_weight",
        f"{_DEFAULT_PINCH_DISTANCE_WEIGHT:g}",
        "--contact_position_x_weight",
        f"{_DEFAULT_CONTACT_POSITION_AXIS_WEIGHT:g}",
        "--contact_position_y_weight",
        f"{_DEFAULT_CONTACT_POSITION_AXIS_WEIGHT:g}",
        "--contact_position_z_weight",
        f"{_DEFAULT_CONTACT_POSITION_AXIS_WEIGHT:g}",
        # Seed y from the URDF rest pose.  Tianji x is 0.6 m; z is 0.25 m
        # above the table top.  EX001 still uses rest-pose xy.  YAML
        # initial_position overrides the first-frame palm-midpoint delta.
        *worker_retarget_seed_args(urdf, initial_position),
        *(
            (
                "--table_top_z",
                f"{-_TIANJI_ARM_BASE_ABOVE_TABLE_M:g}",
            )
            if is_tianji_urdf(urdf)
            else ()
        ),
        ]
    )
    return command


def _is_complete_output(path: Path) -> bool:
    if not path.is_file():
        return False
    try:
        with np.load(path, allow_pickle=False) as archive:
            if not _REQUIRED_OUTPUT_KEYS.issubset(archive.files):
                return False
            arm_q = np.asarray(archive["arm_q"])
            hand_q = np.asarray(archive["wuji_hand_q"])
            success = np.asarray(archive["arm_ik_success"], dtype=bool)
    except (OSError, ValueError, KeyError):
        return False
    return (
        arm_q.ndim == 2
        and hand_q.ndim == 2
        and len(arm_q) > 0
        and len(arm_q) == len(hand_q)
        and success.shape == (len(arm_q),)
    )


def _replay_metrics_from_data(data: Mapping[str, np.ndarray]) -> tuple[int, int, int]:
    success = np.asarray(data["arm_ik_success"], dtype=bool)
    if success.ndim != 1 or success.size == 0:
        raise ValueError("arm_ik_success must be a non-empty vector")
    succeeded = int(np.count_nonzero(success))
    total = int(success.size)
    return succeeded, total, total - succeeded


def _trajectory_solve_seconds_from_data(data: Mapping[str, np.ndarray]) -> float:
    key = "trajectory_timing_total_trajectory_solve"
    if key not in data:
        raise KeyError(f"Replay archive has no {key} value")
    seconds = float(np.asarray(data[key]).item())
    if not math.isfinite(seconds) or seconds < 0.0:
        raise ValueError(f"Invalid trajectory solve time {seconds!r}")
    return seconds


def _load_replay_metrics(path: Path) -> tuple[int, int, int]:
    """Return successful, total, and failed arm-IK frame counts."""

    with np.load(path, allow_pickle=False) as archive:
        if "arm_ik_success" not in archive.files:
            raise KeyError(f"Replay archive has no arm_ik_success array: {path}")
        return _replay_metrics_from_data(
            {"arm_ik_success": archive["arm_ik_success"]}
        )


def _load_trajectory_solve_seconds(path: Path) -> float:
    """Read the solver-only wall time embedded by ``wuji_replay``."""

    key = "trajectory_timing_total_trajectory_solve"
    with np.load(path, allow_pickle=False) as archive:
        if key not in archive.files:
            raise KeyError(f"Replay archive has no {key} value: {path}")
        return _trajectory_solve_seconds_from_data({key: archive[key]})


def _rotation_from_rotvec(value: object) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float64)
    if vector.shape != (3,) or not np.all(np.isfinite(vector)):
        raise ValueError("rotation vector must contain three finite values")
    angle = float(np.linalg.norm(vector))
    if angle < 1e-12:
        skew = np.asarray(
            [[0.0, -vector[2], vector[1]],
             [vector[2], 0.0, -vector[0]],
             [-vector[1], vector[0], 0.0]],
            dtype=np.float64,
        )
        return np.eye(3, dtype=np.float64) + skew
    axis = vector / angle
    x, y, z = axis
    skew = np.asarray(
        [[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]], dtype=np.float64
    )
    return (
        np.eye(3, dtype=np.float64)
        + math.sin(angle) * skew
        + (1.0 - math.cos(angle)) * (skew @ skew)
    )


def _euler_xyz_from_rotation(rotation: np.ndarray) -> list[float]:
    """Return extrinsic XYZ/URDF roll-pitch-yaw for one rotation matrix."""

    matrix = np.asarray(rotation, dtype=np.float64)
    if matrix.shape != (3, 3) or not np.all(np.isfinite(matrix)):
        raise ValueError("rotation must be a finite 3x3 matrix")
    pitch = math.asin(float(np.clip(-matrix[2, 0], -1.0, 1.0)))
    if abs(math.cos(pitch)) > 1e-9:
        roll = math.atan2(float(matrix[2, 1]), float(matrix[2, 2]))
        yaw = math.atan2(float(matrix[1, 0]), float(matrix[0, 0]))
    else:
        # At gimbal lock choose roll=0 while preserving the represented pose.
        roll = 0.0
        yaw = math.atan2(float(-matrix[0, 1]), float(matrix[1, 1]))
    return [roll, pitch, yaw]


def _urdf_origin_transform(joint: ET.Element) -> np.ndarray:
    """Return a URDF joint's parent-to-child origin transform."""

    origin = joint.find("origin")
    xyz = np.fromstring(
        "0 0 0" if origin is None else origin.attrib.get("xyz", "0 0 0"),
        sep=" ",
        dtype=np.float64,
    )
    rpy = np.fromstring(
        "0 0 0" if origin is None else origin.attrib.get("rpy", "0 0 0"),
        sep=" ",
        dtype=np.float64,
    )
    if xyz.shape != (3,) or rpy.shape != (3,) or not np.all(
        np.isfinite(np.concatenate((xyz, rpy)))
    ):
        raise ValueError(f"URDF joint {joint.attrib.get('name')!r} has invalid origin")
    roll, pitch, yaw = rpy
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = np.asarray(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ],
        dtype=np.float64,
    )
    transform[:3, 3] = xyz
    return transform


def _fixed_urdf_transform(
    root: ET.Element, ancestor_link: str, descendant_link: str
) -> np.ndarray:
    """Compose an all-fixed URDF chain from ancestor to descendant."""

    child_to_joint = {
        child.attrib["link"]: joint
        for joint in root.findall("joint")
        if (child := joint.find("child")) is not None
    }
    link = descendant_link
    chain: list[ET.Element] = []
    visited: set[str] = set()
    while link != ancestor_link:
        if link in visited or link not in child_to_joint:
            raise ValueError(
                f"No URDF chain from {ancestor_link!r} to {descendant_link!r}"
            )
        visited.add(link)
        joint = child_to_joint[link]
        if joint.attrib.get("type", "fixed") != "fixed":
            raise ValueError(
                f"URDF chain {ancestor_link!r} -> {descendant_link!r} contains "
                f"non-fixed joint {joint.attrib.get('name')!r}"
            )
        chain.append(joint)
        parent = joint.find("parent")
        if parent is None:
            raise ValueError(f"URDF joint {joint.attrib.get('name')!r} has no parent")
        link = parent.attrib["link"]

    transform = np.eye(4, dtype=np.float64)
    for joint in reversed(chain):
        transform = transform @ _urdf_origin_transform(joint)
    return transform


def _controller_neutral_link6_transform() -> np.ndarray:
    """Return deployed desktop_wuji ``T_arm_base_link6(q=0)``."""

    transform = np.eye(4, dtype=np.float64)
    transform[:3, 3] = _DESKTOP_WUJI_NEUTRAL_LINK6_TRANSLATION_M
    return transform


def _controller_eef_from_base_palm(
    palm_position_base: Mapping[str, np.ndarray],
    palm_quaternion_base_xyzw: Mapping[str, np.ndarray],
    composite_urdf: str | Path,
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    """Convert composite-base palm poses to arm-neutral link6 command poses.

    The replay solver intentionally tracks ``*_palm_link`` in the composite
    URDF.  The deployed Cartesian controller instead commands ``*_arm_link6``
    in the corresponding ``*_arm_neutral`` frame.  For each side this applies

    ``T_neutral_link6 = inv(T_armbase_link6_zero) @ inv(T_base_armbase)``
    ``                    @ T_base_palm @ inv(T_link6_palm)``.

    This is an output-only rigid transform; it does not alter arm/hand q or any
    replay optimization target.
    """

    urdf = Path(composite_urdf).expanduser().resolve()
    if not urdf.is_file():
        raise FileNotFoundError(f"Composite URDF does not exist: {urdf}")
    cache_key = str(urdf)
    cached = _CONTROLLER_TRANSFORM_CACHE.get(cache_key)
    if cached is None:
        root = ET.parse(urdf).getroot()
        transforms = tuple(
            _fixed_urdf_transform(root, "base_link", f"{side}_arm_base_link")
            for side in ("left", "right")
        ) + tuple(
            _fixed_urdf_transform(root, f"{side}_arm_link6", f"{side}_palm_link")
            for side in ("left", "right")
        )
        if is_tianji_urdf(urdf):
            neutrals = tuple(
                zero_q_transform(
                    root, f"{side}_arm_base_link", f"{side}_arm_link6"
                )
                for side in ("left", "right")
            )
        else:
            neutrals = (
                _controller_neutral_link6_transform(),
                _controller_neutral_link6_transform(),
            )
        cached = transforms + neutrals  # type: ignore[assignment]
        with _CONTROLLER_TRANSFORM_CACHE_LOCK:
            cached = _CONTROLLER_TRANSFORM_CACHE.setdefault(cache_key, cached)
    left_base, right_base, left_palm, right_palm, left_neutral, right_neutral = cached
    fixed_transforms = {
        "left": (left_base, left_palm, left_neutral),
        "right": (right_base, right_palm, right_neutral),
    }
    positions: dict[str, np.ndarray] = {}
    rotations: dict[str, np.ndarray] = {}
    for side in ("left", "right"):
        source_positions = np.asarray(palm_position_base[side], dtype=np.float64)
        source_quaternions = np.asarray(
            palm_quaternion_base_xyzw[side], dtype=np.float64
        )
        if source_positions.ndim != 2 or source_positions.shape[1] != 3:
            raise ValueError(f"{side} palm positions must have shape [T,3]")
        if source_quaternions.shape != (len(source_positions), 4):
            raise ValueError(f"{side} palm quaternions must have shape [T,4]")

        base_to_arm_base, link6_to_palm, arm_base_to_link6_zero = fixed_transforms[side]
        prefix = np.linalg.inv(arm_base_to_link6_zero) @ np.linalg.inv(base_to_arm_base)
        suffix = np.linalg.inv(link6_to_palm)
        from scipy.spatial.transform import Rotation

        base_to_palm = np.zeros((len(source_positions), 4, 4), dtype=np.float64)
        base_to_palm[:, :3, :3] = Rotation.from_quat(source_quaternions).as_matrix()
        base_to_palm[:, :3, 3] = source_positions
        base_to_palm[:, 3, 3] = 1.0
        neutral_to_link6 = np.einsum(
            "ij,tjk,kl->til", prefix, base_to_palm, suffix
        )
        side_positions = neutral_to_link6[:, :3, 3]
        side_rotations = neutral_to_link6[:, :3, :3]
        positions[side] = side_positions
        rotations[side] = side_rotations
    return positions, rotations


def _rotation_from_quaternion_xyzw(value: object) -> np.ndarray:
    quaternion = np.asarray(value, dtype=np.float64)
    if quaternion.shape != (4,) or not np.all(np.isfinite(quaternion)):
        raise ValueError("quaternion must contain four finite XYZW values")
    norm = float(np.linalg.norm(quaternion))
    if norm <= 1e-12:
        raise ValueError("quaternion norm must be positive")
    x, y, z, w = quaternion / norm
    return np.asarray(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w),
             2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z),
             2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w),
             1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def _rotvec_from_quaternion_xyzw(value: object) -> list[float]:
    quaternion = np.asarray(value, dtype=np.float64)
    if quaternion.shape != (4,) or not np.all(np.isfinite(quaternion)):
        raise ValueError("quaternion must contain four finite XYZW values")
    norm = float(np.linalg.norm(quaternion))
    if norm <= 1e-12:
        raise ValueError("quaternion norm must be positive")
    quaternion = quaternion / norm
    if quaternion[3] < 0.0:
        quaternion = -quaternion
    vector_norm = float(np.linalg.norm(quaternion[:3]))
    if vector_norm <= 1e-12:
        return (2.0 * quaternion[:3]).tolist()
    angle = 2.0 * math.atan2(vector_norm, float(quaternion[3]))
    return (quaternion[:3] * (angle / vector_norm)).tolist()


def _normalise(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if not math.isfinite(norm) or norm <= 1e-10:
        raise ValueError("cannot normalise a degenerate vector")
    return vector / norm


def _canonical_wrist_rotation(points: np.ndarray, side: str) -> np.ndarray:
    """Build the data-format canonical wrist frame from MANO-21 points."""

    wrist, index, middle, pinky = points[0], points[1], points[5], points[9]
    z_axis = _normalise(middle - wrist)
    palm_cross = np.cross(index - wrist, pinky - wrist)
    y_axis = _normalise(palm_cross if side == "left" else -palm_cross)
    y_axis = _normalise(y_axis - np.dot(y_axis, z_axis) * z_axis)
    x_axis = _normalise(np.cross(y_axis, z_axis))
    y_axis = _normalise(np.cross(z_axis, x_axis))
    return np.column_stack((x_axis, y_axis, z_axis))


def _normalise_rows(vectors: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vectors, axis=-1, keepdims=True)
    if not np.all(np.isfinite(norms)) or np.any(norms <= 1e-10):
        raise ValueError("cannot normalise a degenerate vector")
    return vectors / norms


def _canonical_wrist_rotation_batch(points: np.ndarray, side: str) -> np.ndarray:
    """Batched :func:`_canonical_wrist_rotation` for ``[N, 21, 3]``."""

    wrist, index, middle, pinky = (
        points[:, 0],
        points[:, 1],
        points[:, 5],
        points[:, 9],
    )
    z_axis = _normalise_rows(middle - wrist)
    palm_cross = np.cross(index - wrist, pinky - wrist)
    y_axis = _normalise_rows(palm_cross if side == "left" else -palm_cross)
    y_axis = _normalise_rows(
        y_axis - np.sum(y_axis * z_axis, axis=-1, keepdims=True) * z_axis
    )
    x_axis = _normalise_rows(np.cross(y_axis, z_axis))
    y_axis = _normalise_rows(np.cross(z_axis, x_axis))
    return np.stack((x_axis, y_axis, z_axis), axis=-1)


def _source_observation_fields_many(
    raw_frames: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    """Same fields as :func:`_source_observation_fields`, stacked per unique raw."""

    values = [data_format.source_passthrough_fields(frame) for frame in raw_frames]
    for side in ("left", "right"):
        key = data_format.source_mano21_key(side)
        stacked = np.full((len(raw_frames), 21, 3), np.nan, dtype=np.float64)
        valid = np.zeros(len(raw_frames), dtype=bool)
        for index, raw_source in enumerate(raw_frames):
            points = None
            if key in raw_source:
                value = raw_source[key]
                if value is not None:
                    candidate = np.asarray(value, dtype=np.float64)
                    if candidate.size == 63 and np.all(np.isfinite(candidate)):
                        points = candidate.reshape(21, 3)
            if points is None:
                points = _skeleton_mano21(raw_source, side)
            if points is None:
                continue
            stacked[index] = points
            valid[index] = True
        if not np.any(valid):
            for index in range(len(raw_frames)):
                values[index].update(
                    data_format.source_hand_fields(
                        side, mano21_points=None, wrist_rotation=None
                    )
                )
                values[index][data_format.source_hand_joint_key(side)] = None
            continue
        try:
            rotations = _canonical_wrist_rotation_batch(stacked[valid], side)
        except ValueError:
            rotations = None
        cursor = 0
        for index, is_valid in enumerate(valid):
            if not is_valid or rotations is None:
                values[index].update(
                    data_format.source_hand_fields(
                        side, mano21_points=None, wrist_rotation=None
                    )
                )
                values[index][data_format.source_hand_joint_key(side)] = None
                continue
            values[index].update(
                data_format.source_hand_fields(
                    side,
                    mano21_points=stacked[index],
                    wrist_rotation=rotations[cursor],
                )
            )
            cursor += 1
    return values


def _skeleton_mano21(frame: Mapping[str, object], side: str) -> np.ndarray | None:
    message = frame.get(f"{side}_glove_hand_skeleton_world")
    joints = message.get("joints") if isinstance(message, Mapping) else None
    if not isinstance(joints, list) or len(joints) < 21:
        return None
    raw = np.empty((21, 3), dtype=np.float64)
    try:
        for index, joint in enumerate(joints[:21]):
            position = joint["pose"]["position"]
            raw[index] = [float(position[axis]) for axis in "xyz"]
    except (KeyError, TypeError, ValueError):
        return None
    if not np.all(np.isfinite(raw)):
        return None
    return raw[_RAW_TO_MANO21]


def _tactile_values(frame: Mapping[str, object]) -> list[float] | None:
    values: list[float] = []
    for side in ("left", "right"):
        message = frame.get(f"{side}_glove_tactile")
        side_values = message.get("data") if isinstance(message, Mapping) else None
        if not isinstance(side_values, list):
            return None
        try:
            parsed = [float(value) for value in side_values]
        except (TypeError, ValueError):
            return None
        if not all(math.isfinite(value) for value in parsed):
            return None
        values.extend(parsed)
    return values


def _probe_video(path: Path) -> dict[str, object]:
    """Read container headers only. Never decode or scan the bitstream."""

    ffprobe = data_format.resolve_ffprobe()
    if ffprobe is not None:
        completed = subprocess.run(
            [
                ffprobe,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=avg_frame_rate,width,height,nb_frames,duration",
                "-of",
                "json",
                str(path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        stream = json.loads(completed.stdout)["streams"][0]
        numerator, denominator = str(stream["avg_frame_rate"]).split("/", 1)
        fps = float(numerator) / float(denominator)
        frame_count = int(
            stream.get("nb_frames")
            or round(float(stream["duration"]) * fps)
        )
        width, height = int(stream["width"]), int(stream["height"])
    else:
        import av

        container = av.open(str(path))
        try:
            stream = container.streams.video[0]
            rate = stream.average_rate or stream.base_rate
            fps = float(rate) if rate is not None else 0.0
            frame_count = int(stream.frames or 0)
            width, height = int(stream.width), int(stream.height)
        finally:
            container.close()
        if frame_count <= 0:
            raise ValueError(f"Video container reports no frame count: {path}")
    if fps <= 0.0 or frame_count <= 0 or width <= 0 or height <= 0:
        raise ValueError(f"Invalid encoded video metadata: {path}")
    return data_format.video_measurement(
        fps=fps, width=width, height=height, frame_count=frame_count
    )



def _normalised_instruction(path: Path, episode_id: str) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    source = payload.get(episode_id) if isinstance(payload, Mapping) else None
    return data_format.instruction_entry(source)


def _copy_if_present(source: Path, destination: Path) -> None:
    if source.is_file():
        shutil.copy2(source, destination)


def _ffmpeg_executable() -> str:
    return data_format.resolve_ffmpeg()


def _transcode_standard_video(source: Path, destination: Path) -> None:
    subprocess.run(
        data_format.video_transcode_command(
            _ffmpeg_executable(), source, destination
        ),
        check=True,
    )


def _ramp_joint_matrix(
    samples: Mapping[str, np.ndarray],
    names_by_group: Mapping[str, Sequence[str]],
    target_names: np.ndarray,
) -> np.ndarray:
    lookup: dict[str, tuple[str, int]] = {}
    for group, names in names_by_group.items():
        for index, name in enumerate(names):
            lookup[str(name)] = (group, index)
    columns: list[np.ndarray] = []
    for name in np.asarray(target_names).astype(str):
        try:
            group, index = lookup[name]
        except KeyError as exc:
            raise KeyError(f"Ramp has no joint named {name!r}") from exc
        columns.append(np.asarray(samples[group])[:, index])
    return np.stack(columns, axis=1)


def _warmup_ramp_modules() -> None:
    """Import ramp dependencies once, overlapping the first trajectory solve."""

    import publisher  # noqa: F401
    from interpolate_video import save_replay  # noqa: F401
    from naive.spline_hand_refine import refine_ramped_hand_q  # noqa: F401
    from calibrated.composite_fk_warp import composite_fk_links  # noqa: F401


def _prepend_move_from_start_ramp(
    replay_path: Path | Mapping[str, np.ndarray],
    fps: float,
    *,
    output_sink: dict[str, np.ndarray] | None = None,
) -> int:
    """Prepend the interactive publisher's constrained ramp to an NPZ.

    The ramp starts at the fixed-base URDF's zero configuration, which is the
    same pose exposed by interactive_replay's ``Zero`` action.  batch_replay
    normally calls this in-process after importing its dependency environment;
    the private ``--_prepend-ramp-worker`` entry point remains for isolation.
    """

    from scipy.spatial.transform import Rotation

    import publisher
    from optimize import DEFAULT_COMPOSITE_URDF
    from interpolate_video import save_replay

    if isinstance(replay_path, Mapping):
        replay = {key: np.asarray(value) for key, value in replay_path.items()}
    else:
        with np.load(replay_path, allow_pickle=False) as archive:
            replay = {key: archive[key] for key in archive.files}
    old_count = len(np.asarray(replay["arm_q"]))
    if old_count < 1 or len(np.asarray(replay["wuji_hand_q"])) != old_count:
        raise ValueError("Cannot add a ramp to an empty or misaligned replay")
    stored_fps = float(np.asarray(replay["playback_fps"]).item())
    if not math.isclose(stored_fps, fps, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError(f"Ramp FPS {fps} does not match replay FPS {stored_fps}")

    names_by_group, trajectory = publisher.load_trajectory(replay)
    minimum_ticks = max(
        1,
        int(math.ceil(publisher.RAMP_TICKS * fps / publisher.DEFAULT_RAMP_FPS)),
    )
    required: list[int] = []
    for group, values in trajectory.items():
        hand = group.startswith("wuji_")
        required.append(
            publisher._required_quintic_ramp_ticks(
                np.zeros_like(values[0]),
                values[0],
                fps=fps,
                minimum_ticks=minimum_ticks,
                max_velocity=(
                    publisher.RAMP_MAX_HAND_VELOCITY
                    if hand
                    else publisher.RAMP_MAX_VELOCITY
                ),
                max_acceleration=(
                    publisher.RAMP_MAX_HAND_ACCELERATION
                    if hand
                    else publisher.RAMP_MAX_ACCELERATION
                ),
                max_jerk=(
                    publisher.RAMP_MAX_HAND_JERK
                    if hand
                    else publisher.RAMP_MAX_JERK
                ),
            )
        )
    ramp_frames = max(required)
    from naive.spline_hand_refine import hand_ramp_matching_first_data

    ramp_groups = {}
    for group, values in trajectory.items():
        if group.startswith("wuji_"):
            ramp_groups[group] = hand_ramp_matching_first_data(values, ramp_frames)
        else:
            ramp_groups[group] = publisher._quintic_bspline_ramp(
                np.zeros_like(values[0]), values[0], ramp_frames
            )[:-1]
    arm_names = np.asarray(replay["arm_q_names"])
    hand_names = np.asarray(replay["wuji_hand_q_names"])
    ramp_arm = _ramp_joint_matrix(ramp_groups, names_by_group, arm_names)
    ramp_hand = _ramp_joint_matrix(ramp_groups, names_by_group, hand_names)

    # Preserve every frame-aligned diagnostic with a well-defined leading
    # value.  Joint commands, wrist FK, timestamps, and contact state are
    # replaced below with their physically meaningful ramp values.
    output: dict[str, np.ndarray] = {}
    for key, value in replay.items():
        array = np.asarray(value)
        if (
            array.ndim > 0
            and array.shape[0] == old_count
            and not key.endswith("_names")
            and not key.endswith("_transform")
        ):
            leading = np.repeat(array[0:1], ramp_frames, axis=0)
            output[key] = np.concatenate((leading, array), axis=0)
        else:
            output[key] = array.copy()

    output["arm_q"] = np.concatenate((ramp_arm, np.asarray(replay["arm_q"])), axis=0)
    output["wuji_hand_q"] = np.concatenate(
        (ramp_hand, np.asarray(replay["wuji_hand_q"])), axis=0
    )
    for side in ("left", "right"):
        group = f"wuji_{side}"
        key = f"{side}_hand_q"
        if key in replay:
            output[key] = np.concatenate(
                (ramp_groups[group], np.asarray(replay[key])), axis=0
            )

    frame_count = old_count + ramp_frames
    output["timestamps"] = np.arange(frame_count, dtype=np.float64) / fps
    from naive.spline_hand_refine import refine_ramped_hand_q

    output = refine_ramped_hand_q(
        output,
        ramp_frames=ramp_frames,
        fps=fps,
        verbose=True,
    )
    ramp_hand = np.asarray(output["wuji_hand_q"][:ramp_frames], dtype=np.float64)

    combined_names = np.concatenate((arm_names, hand_names)).astype(str)
    combined_ramp = np.concatenate((ramp_arm, ramp_hand), axis=1)
    stored_urdf = np.asarray(replay.get("composite_urdf_path", ""))
    urdf = (
        Path(str(stored_urdf.item())).expanduser()
        if stored_urdf.ndim == 0 and str(stored_urdf.item())
        else Path(DEFAULT_COMPOSITE_URDF)
    )
    if not urdf.is_file():
        raise FileNotFoundError(f"Ramp composite URDF does not exist: {urdf}")
    from calibrated.composite_fk_warp import composite_fk_links

    transforms = composite_fk_links(
        urdf,
        combined_names,
        combined_ramp,
        ("left_palm_link", "right_palm_link"),
    )
    for side in ("left", "right"):
        positions, rotations = transforms[f"{side}_palm_link"]
        ramp_positions = np.asarray(positions, dtype=np.float64)
        ramp_quaternions = Rotation.from_matrix(
            np.asarray(rotations, dtype=np.float64)
        ).as_quat()
        position_key = f"{side}_wrist_position_base"
        quaternion_key = f"{side}_wrist_quaternion_base_xyzw"
        output[position_key] = np.concatenate(
            (ramp_positions, np.asarray(replay[position_key])), axis=0
        )
        output[quaternion_key] = np.concatenate(
            (ramp_quaternions, np.asarray(replay[quaternion_key])), axis=0
        )

    combined_q = np.concatenate((output["arm_q"], output["wuji_hand_q"]), axis=1)
    velocity = (
        np.gradient(combined_q, 1.0 / fps, axis=0, edge_order=1)
        if frame_count > 1
        else np.zeros_like(combined_q)
    )
    acceleration = (
        np.gradient(velocity, 1.0 / fps, axis=0, edge_order=1)
        if frame_count > 1
        else np.zeros_like(velocity)
    )
    output["video_execution_velocity"] = velocity
    output["video_execution_acceleration"] = acceleration
    output["playback_duration_seconds"] = np.asarray(frame_count / fps)
    for key in (
        "video_source_execution_indices",
        "video_execution_arm_source_key_indices",
        "video_execution_hand_source_key_indices",
    ):
        if key in replay:
            output[key] = np.asarray(replay[key]) + ramp_frames
    if "video_frame_schedule_kind" in output:
        output["video_frame_schedule_kind"][:ramp_frames] = "ramp"
    for key, value in output.items():
        if value.ndim > 0 and value.shape[0] == frame_count and (
            "contact" in key or key.endswith("_tip_mask")
        ):
            value[:ramp_frames] = 0

    output.update(
        {
            "move_from_start": np.asarray(True, dtype=bool),
            "move_from_start_ramp_frame_count": np.asarray(ramp_frames, dtype=np.int64),
            "move_from_start_ramp_duration_seconds": np.asarray(ramp_frames / fps),
            "move_from_start_ramp_fps": np.asarray(fps),
            "move_from_start_ramp_start": np.asarray("URDF zero configuration"),
            "move_from_start_ramp_method": np.asarray(
                "v2.publisher quintic B-spline, then spline-hand over ramp+data"
            ),
        }
    )
    if output_sink is not None:
        output_sink.clear()
        output_sink.update(output)
    else:
        if not isinstance(replay_path, Path):
            raise TypeError("replay_path must be a Path when output_sink is omitted")
        save_replay(replay_path, output)
    return ramp_frames


def _apply_publish_clock(
    replay: Mapping[str, np.ndarray], fps: float
) -> dict[str, np.ndarray]:
    """Stamp a 1:1 source-frame clock. No RIFE / inserted RGB frames."""

    out = {key: np.asarray(value) for key, value in replay.items()}
    count = int(len(out["arm_q"]))
    out["playback_fps"] = np.asarray(float(fps))
    out["timestamps"] = np.arange(count, dtype=np.float64) / float(fps)
    out["video_source_execution_indices"] = np.arange(count, dtype=np.int64)
    return out


def _decoded_video_frame_count(path: Path, expected: int | None = None) -> int:
    """Count pictures OpenCV can actually decode, not container packet claims."""

    import cv2

    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise FileNotFoundError(f"Could not open input video: {path}")
    try:
        claimed = int(round(capture.get(cv2.CAP_PROP_FRAME_COUNT)))
        if expected is not None and claimed == int(expected):
            return claimed
        decoded = 0
        while True:
            ok, _ = capture.read()
            if not ok:
                break
            decoded += 1
        if decoded < 1:
            raise RuntimeError(f"Decoded no frames from {path}")
        if claimed > 0 and claimed != decoded:
            print(
                f"[batch_replay] {path.name}: container claims {claimed} "
                f"frames, decoded {decoded}",
                flush=True,
            )
        return decoded
    finally:
        capture.release()


def _nearest_time_indices(timeline: np.ndarray, queries: np.ndarray) -> np.ndarray:
    """Return, for each query, the index of the closest strictly-ordered time."""

    times = np.asarray(timeline, dtype=np.float64)
    values = np.asarray(queries, dtype=np.float64)
    if times.ndim != 1 or times.size < 1:
        raise ValueError("timeline must be a non-empty 1-D array")
    right = np.clip(np.searchsorted(times, values), 0, len(times) - 1)
    left = np.clip(right - 1, 0, len(times) - 1)
    pick_left = np.abs(times[left] - values) <= np.abs(times[right] - values)
    return np.where(pick_left, left, right).astype(np.int64)


def _kept_source_frame_indices(
    staging: Path, replay: Mapping[str, np.ndarray]
) -> np.ndarray:
    """JSON / ``face_timestamps.h5`` indices kept after EMF alignment."""

    count = int(len(replay["arm_q"]))
    stored = np.asarray(replay.get("frame_indices", []), dtype=np.int64)
    if stored.size == 0:
        stored = np.arange(count, dtype=np.int64)
    if stored.shape != (count,) or np.any(stored < 0):
        raise ValueError(
            f"replay frame_indices must be {count} non-negative integers, "
            f"got shape {stored.shape}"
        )
    if stored.size > 1 and np.any(np.diff(stored) < 0):
        raise ValueError("replay frame_indices must be non-decreasing")
    try:
        face_ts, _, _ = data_format.read_raw_head_timestamps(staging)
    except FileNotFoundError:
        return stored
    face_ts = np.asarray(face_ts, dtype=np.int64)
    if np.any(stored >= len(face_ts)):
        raise ValueError(
            f"replay frame_indices max {int(stored.max())} exceeds "
            f"{len(face_ts)} face_timestamps.h5 samples"
        )
    return stored


def _video_indices_for_kept_frames(
    video: Path, kept: np.ndarray, face_ts: np.ndarray | None
) -> np.ndarray:
    """Map kept JSON/face samples onto decoded pictures of ``video``."""

    decoded = _decoded_video_frame_count(
        video, expected=None if face_ts is None else int(len(face_ts))
    )
    if face_ts is None:
        if decoded == len(kept):
            return np.arange(len(kept), dtype=np.int64)
        raise ValueError(
            f"{video.name} has {decoded} decoded frames for {len(kept)} replay "
            "frames, and face_timestamps.h5 is missing"
        )
    n_face = int(len(face_ts))
    if decoded == n_face:
        return np.asarray(kept, dtype=np.int64)
    if decoded == len(kept):
        return np.arange(len(kept), dtype=np.int64)
    # Variable packet/PTS vs camera clock: pick the nearest picture by
    # normalised capture time from face_timestamps.h5.
    face_rel = (np.asarray(face_ts, dtype=np.float64) - float(face_ts[0])) / float(
        data_format.NANOSECONDS_PER_SECOND
    )
    video_rel = np.linspace(0.0, float(face_rel[-1]) if n_face > 1 else 0.0, decoded)
    indices = _nearest_time_indices(video_rel, face_rel[np.asarray(kept, dtype=np.int64)])
    if np.any(indices < 0) or np.any(indices >= decoded):
        raise ValueError(f"{video.name}: timestamp mapping produced out-of-range frames")
    return indices


def _write_selected_video_frames(
    source: Path,
    destination: Path,
    indices: Sequence[int],
    *,
    fps: float,
) -> None:
    """Encode the selected source pictures onto the publish fps grid."""

    import cv2

    wanted = [int(index) for index in indices]
    if not wanted:
        raise ValueError(f"No frames selected from {source}")
    if wanted != sorted(wanted):
        raise ValueError(f"Selected video frames must be non-decreasing: {source}")
    capture = cv2.VideoCapture(str(source))
    if not capture.isOpened():
        raise FileNotFoundError(f"Could not open input video: {source}")
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if width < 1 or height < 1:
        capture.release()
        raise ValueError(f"Invalid resolution for {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.stem}.select.mp4")
    command = [
        _ffmpeg_executable(),
        "-hide_banner",
        "-nostdin",
        "-y",
        "-v",
        "error",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{width}x{height}",
        "-r",
        f"{fps:.12g}",
        "-i",
        "pipe:0",
        "-an",
        *_contract_encode_args(fps=fps),
        str(temporary),
    ]
    process = subprocess.Popen(command, stdin=subprocess.PIPE)
    assert process.stdin is not None
    decoded = -1
    current = None
    try:
        for target in wanted:
            while decoded < target:
                ok, frame = capture.read()
                if not ok:
                    raise RuntimeError(
                        f"{source.name} ended at decoded frame {decoded}; "
                        f"needed {target}"
                    )
                decoded += 1
                current = np.ascontiguousarray(
                    cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                )
            if current is None:
                raise RuntimeError(f"{source.name}: no frame decoded for {target}")
            process.stdin.write(current.tobytes())
        process.stdin.close()
        status = process.wait()
        if status != 0:
            raise RuntimeError(f"ffmpeg exited {status} while writing {destination}")
        os.replace(temporary, destination)
    finally:
        capture.release()
        if process.poll() is None:
            process.kill()
        Path(temporary).unlink(missing_ok=True)


def _align_source_videos_to_replay(
    staging: Path,
    replay: Mapping[str, np.ndarray],
    *,
    fps: float,
) -> tuple[int, int]:
    """Keep only the camera pictures that still have a replayed action.

    Recorder MP4s are 1:1 with ``face_timestamps.h5`` / episode JSON.  The SDK
    drops JSON frames without an exact EMF match, so publishing the raw MP4
    would ship extra pictures.  Select the kept ``frame_indices`` instead.
    """

    kept = _kept_source_frame_indices(staging, replay)
    try:
        face_ts, _, _ = data_format.read_raw_head_timestamps(staging)
        face_ts = np.asarray(face_ts, dtype=np.int64)
        n_face = int(len(face_ts))
    except FileNotFoundError:
        face_ts = None
        n_face = int(kept.max()) + 1 if kept.size else 0
    written = 0
    for source_name, interpolated_name in zip(
        _SOURCE_VIDEO_NAMES, _INTERPOLATED_VIDEO_NAMES
    ):
        source = staging / source_name
        if not source.is_file():
            continue
        indices = _video_indices_for_kept_frames(source, kept, face_ts)
        destination = staging / interpolated_name
        if (
            len(indices) == n_face
            and n_face == len(kept)
            and np.array_equal(indices, np.arange(n_face))
        ):
            shutil.copy2(source, destination)
        else:
            _write_selected_video_frames(source, destination, indices, fps=fps)
        written += 1
    if written == 0:
        raise RuntimeError("No source camera MP4s found to align with replay")
    return len(kept), n_face


def _video_encode_threads() -> int:
    """Worker threads for libx264. Does not change the bitstream contract."""

    return max(1, min(8, os.cpu_count() or 4))


def _contract_encode_args(*, fps: float) -> list[str]:
    """libx264 contract args, locked to the episode clock."""

    encode_args = data_format.video_encode_args(threads=_video_encode_threads())
    fps_s = f"{fps:.12g}"
    clock_args: list[str] = []
    i = 0
    while i < len(encode_args):
        if encode_args[i] == "-fps_mode" and i + 1 < len(encode_args):
            clock_args.extend(("-fps_mode", "cfr", "-r", fps_s))
            i += 2
            continue
        clock_args.append(encode_args[i])
        i += 1
    return clock_args


def _prepend_frames_by_remux(
    video_path: Path,
    destination: Path,
    *,
    fps: float,
    frame_count: int,
) -> None:
    """Copy the first picture ``frame_count`` times, then concat the main stream.

    The prefix is one I-frame repeated, so its packet order is its display
    order and ``setts`` may stamp that prefix onto the publish clock.  The
    main stream is copied with the timestamps the encoder already wrote.
    ``setts=pts=N`` numbers packets in decode order.  On a stream with
    B-frames that is not display order, and players then show a future
    P-frame and jump back to the B-frames in front of it.
    """

    ffmpeg = _ffmpeg_executable()
    work_root = (
        Path("/dev/shm")
        if os.access("/dev/shm", os.W_OK)
        else Path(tempfile.gettempdir())
    )
    work = Path(tempfile.mkdtemp(prefix="rampvid_", dir=str(work_root)))
    temporary = destination.with_name(f".{destination.stem}.with_ramp.mp4")
    first = work / "first.mp4"
    prefix = work / "prefix.mp4"
    concat_list = work / "concat.txt"
    fps_s = f"{fps:.12g}"
    prefix_setts = f"setts=pts=N/TB/{fps_s}:dts=N/TB/{fps_s}:duration=TB/{fps_s}"
    try:
        subprocess.run(
            [
                ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-y",
                "-i", str(video_path),
                "-frames:v", "1", "-an", "-c", "copy",
                str(first),
            ],
            check=True,
        )
        subprocess.run(
            [
                ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-y",
                "-stream_loop", str(frame_count - 1),
                "-i", str(first),
                "-an", "-c", "copy",
                "-bsf:v", prefix_setts,
                str(prefix),
            ],
            check=True,
        )
        concat_list.write_text(
            "file " + repr(str(prefix)) + "\n"
            + "file " + repr(str(video_path)) + "\n",
            encoding="utf-8",
        )
        subprocess.run(
            [
                ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-y",
                "-f", "concat", "-safe", "0", "-i", str(concat_list),
                "-map", "0:v:0", "-an", "-c", "copy",
                str(temporary),
            ],
            check=True,
        )
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
        shutil.rmtree(work, ignore_errors=True)


def _prepend_frames_by_reencode(
    video_path: Path,
    background_video: Path,
    destination: Path,
    *,
    fps: float,
    frame_count: int,
    background_is_inpainted: bool,
) -> None:
    """Prepend cloned pictures and stamp PTS in filter order.

    ``setpts=N`` here is the decoded picture index, which is display order,
    including streams that contain B-frames.
    """

    ffmpeg = _ffmpeg_executable()
    temporary = destination.with_name(f".{destination.stem}.with_ramp.mp4")
    fps_s = f"{fps:.12g}"
    encode_args = _contract_encode_args(fps=fps)
    if background_is_inpainted:
        command = [
            ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-y",
            "-i", str(background_video),
            "-i", str(video_path),
            "-filter_complex",
            (
                f"[0:v]select='eq(n,0)',loop=loop={frame_count - 1}:size=1:start=0,"
                f"setpts=N/{fps_s}/TB[pre];"
                f"[1:v]setpts=N/{fps_s}/TB[main];"
                f"[pre][main]concat=n=2:v=1:a=0[v]"
            ),
            "-map", "[v]", "-an",
            *encode_args,
            str(temporary),
        ]
    else:
        command = [
            ffmpeg, "-hide_banner", "-nostdin", "-v", "error", "-y",
            "-i", str(video_path),
            "-vf", f"tpad=start_mode=clone:start={frame_count},setpts=N/{fps_s}/TB",
            "-map", "0:v:0", "-an",
            *encode_args,
            str(temporary),
        ]
    try:
        subprocess.run(command, check=True)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def _remux_clock_matches(
    path: Path,
    *,
    fps: float,
    frame_count: int,
) -> bool:
    """True when a remuxed file still advertises the publish clock."""

    produced = data_format.probe_video_stream(_ffmpeg_executable(), path)
    produced_fps = produced.get("fps")
    return (
        int(produced["frame_count"]) == int(frame_count)
        and produced_fps is not None
        and math.isclose(float(produced_fps), float(fps), abs_tol=0.05)
    )


def _prepend_background_frames(
    video_path: Path,
    background_video: Path,
    *,
    fps: float,
    frame_count: int,
    background_is_inpainted: bool = False,
    output_path: Path | None = None,
) -> None:
    """Clone the first picture, keeping the main stream's display timestamps.

    A compliant main stream is remuxed: the prefix is stamped in display
    order, and the main packets keep the PTS/DTS the encoder wrote.  A short
    B-frame stream can make the container rate drift after that concat; those
    files are re-encoded.  Re-encode is also used when the source is not
    compliant or the background is inpainted.
    """

    if frame_count < 1:
        return
    destination = output_path or video_path
    ffmpeg = _ffmpeg_executable()
    if not background_is_inpainted:
        measured = data_format.probe_video_stream(ffmpeg, video_path)
        if data_format.video_stream_compliant(measured):
            temporary = destination.with_name(f".{destination.stem}.remux_ramp.mp4")
            try:
                _prepend_frames_by_remux(
                    video_path, temporary, fps=fps, frame_count=frame_count
                )
                expected = int(measured["frame_count"]) + int(frame_count)
                if _remux_clock_matches(temporary, fps=fps, frame_count=expected):
                    os.replace(temporary, destination)
                    return
                print(
                    f"[batch_replay] {video_path.name}: remuxed ramp clock is not "
                    f"{fps:g} fps; re-encoding the prepend",
                    flush=True,
                )
            finally:
                temporary.unlink(missing_ok=True)
    _prepend_frames_by_reencode(
        video_path,
        background_video,
        destination,
        fps=fps,
        frame_count=frame_count,
        background_is_inpainted=background_is_inpainted,
    )


def _named_joint_columns(
    values: np.ndarray,
    names: np.ndarray,
    prefix: str,
    expected: int,
) -> np.ndarray:
    indices = [index for index, name in enumerate(names.tolist()) if str(name).startswith(prefix)]
    if len(indices) != expected:
        raise ValueError(
            f"Expected {expected} joints named {prefix}*, found {len(indices)}"
        )
    return np.asarray(values[:, indices], dtype=np.float64)


def _named_arm_side_columns(
    values: np.ndarray,
    names: np.ndarray,
    side: str,
) -> np.ndarray:
    """Publish every arm DoF, including Tianji ``*_wrist_pitch_joint``."""

    prefixes = (f"{side}_arm_joint", f"{side}_wrist_pitch_joint")
    indices = [
        index
        for index, name in enumerate(names.tolist())
        if any(str(name).startswith(prefix) for prefix in prefixes)
    ]
    if len(indices) not in (6, 7):
        raise ValueError(
            f"Expected 6 or 7 {side} arm joints, found {len(indices)}: "
            f"{[str(names[i]) for i in indices]}"
        )
    return np.asarray(values[:, indices], dtype=np.float64)


def _named_hand_joint_columns(
    values: np.ndarray,
    names: np.ndarray,
    side: str,
) -> np.ndarray:
    """Select 20 hand columns for Hand 1 (``left_``/``right_``) or Hand 2 (``l_``/``r_``)."""

    from wuji_retarget.wuji_hand_names import name_matches_hand_side

    indices = [
        index
        for index, name in enumerate(names.tolist())
        if name_matches_hand_side(name, side)
    ]
    if len(indices) != 20:
        raise ValueError(
            f"Expected 20 joints for {side} hand, found {len(indices)}"
        )
    return np.asarray(values[:, indices], dtype=np.float64)


def _source_frame_mapping(anchors, stored_raw_indices, *, frame_count, raw_count, ramp_frames):
    """Map execution frames to preceding anchors, then to actual raw frame IDs."""
    anchors = np.asarray(anchors)
    if anchors.size == 0:
        if frame_count != raw_count or ramp_frames:
            raise ValueError("Retimed replay is missing video_source_execution_indices")
        anchors = np.arange(frame_count, dtype=np.int64)
    if (anchors.ndim != 1 or not np.issubdtype(anchors.dtype, np.integer)
            or anchors[0] != ramp_frames or anchors[-1] >= frame_count
            or np.any(np.diff(anchors) <= 0)):
        raise ValueError("Invalid source execution anchor indices")
    stored = np.asarray(stored_raw_indices)
    if stored.size:
        if stored.ndim != 1 or not np.issubdtype(stored.dtype, np.integer):
            raise ValueError("frame_indices must be one-dimensional integers")
        if len(stored) == frame_count:
            raw_keys = stored[anchors]
        elif len(stored) == len(anchors):
            raw_keys = stored
        else:
            raise ValueError("frame_indices cannot be aligned to source anchors")
    else:
        if len(anchors) != raw_count:
            raise ValueError("Source/raw frame counts differ and frame_indices is missing")
        raw_keys = np.arange(raw_count, dtype=np.int64)
    if np.any(raw_keys < 0) or np.any(raw_keys >= raw_count) or np.any(np.diff(raw_keys) < 0):
        raise ValueError("Source anchors reference invalid raw frame indices")
    # Leading move-from-start frames hold the first raw observation.
    positions = np.maximum(0, np.searchsorted(anchors, np.arange(frame_count), side="right") - 1)
    return raw_keys[positions], positions


def _source_observation_fields(raw_source):
    """Convert the known raw glove wire to source MANO; never use planned poses."""
    values = data_format.source_passthrough_fields(raw_source)
    for side in ("left", "right"):
        key = data_format.source_mano21_key(side)
        if key in raw_source:
            value = raw_source[key]
            points = None if value is None else np.asarray(value, dtype=np.float64)
            if points is not None:
                if points.size != 63 or not np.all(np.isfinite(points)):
                    raise ValueError(f"Invalid raw {key}")
                points = points.reshape(21, 3)
        else:
            points = _skeleton_mano21(raw_source, side)
        rotation = None
        if points is not None:
            try:
                rotation = _canonical_wrist_rotation(points, side)
            except ValueError:
                points = None
        values.update(
            data_format.source_hand_fields(
                side, mano21_points=points, wrist_rotation=rotation
            )
        )
        if points is None:
            values[data_format.source_hand_joint_key(side)] = None
    return values


# Standard MANO-21: index / middle / ring / pinky MCP.
_MANO21_MCP_INDICES = (1, 5, 13, 9)


def _follow_mcp_positions_base(
    hand_q: np.ndarray,
    wrist_position: np.ndarray,
    wrist_quaternion_xyzw: np.ndarray,
    urdf: str | Path,
    side: str,
) -> np.ndarray:
    """FK index–pinky MCP origins in base_link from follow wrist + hand q."""

    from scipy.spatial.transform import Rotation
    from wuji2_retarget.skeleton_mapping import four_finger_mcp_poses_wrist_local

    local, _ = four_finger_mcp_poses_wrist_local(urdf, side, hand_q)
    rotation = Rotation.from_quat(
        np.asarray(wrist_quaternion_xyzw, dtype=np.float64)
    ).as_matrix()
    return (
        np.einsum("tij,tnj->tni", rotation, local)
        + np.asarray(wrist_position, dtype=np.float64)[:, None, :]
    )


def _report_published_mcp_alignment(
    frames: Sequence[Mapping[str, object]],
    *,
    hand_q: Mapping[str, np.ndarray],
    wrist_position: Mapping[str, np.ndarray],
    wrist_quaternion: Mapping[str, np.ndarray],
    composite_urdf: str | Path,
    keyframe_indices: np.ndarray | None = None,
) -> None:
    """Print source_ vs follow-FK MCP error after publishing to base_link."""

    from wuji2_retarget.hand_retarget import DEFAULT_HAND_URDFS
    from wuji_retarget.wuji_hand_names import resolve_hand_urdfs_for_composite

    hand_urdfs = resolve_hand_urdfs_for_composite(
        composite_urdf, DEFAULT_HAND_URDFS
    )
    for side in ("left", "right"):
        source = []
        valid = []
        for frame in frames:
            value = frame.get(data_format.source_mano21_key(side))
            if value is None:
                source.append(np.full((4, 3), np.nan))
                valid.append(False)
                continue
            points = np.asarray(value, dtype=np.float64).reshape(21, 3)
            source.append(points[np.asarray(_MANO21_MCP_INDICES)])
            valid.append(True)
        source_mcp = np.stack(source, axis=0)
        mask = np.asarray(valid, dtype=bool)
        if keyframe_indices is not None and len(keyframe_indices):
            keys = np.asarray(keyframe_indices, dtype=np.int64)
            mask = mask & np.isin(np.arange(len(frames)), keys)
        if not np.any(mask):
            print(f"[batch_replay] {side} MCP check skipped: no valid source frames")
            continue
        selected = np.flatnonzero(mask)
        follow_mcp = np.full((len(frames), 4, 3), np.nan, dtype=np.float64)
        follow_mcp[selected] = _follow_mcp_positions_base(
            hand_q[side][selected],
            wrist_position[side][selected],
            wrist_quaternion[side][selected],
            hand_urdfs[side],
            side,
        )
        delta = follow_mcp[mask] - source_mcp[mask]
        error = np.linalg.norm(delta, axis=-1)
        rmse = float(np.sqrt(np.mean(np.square(error))))
        print(
            f"[batch_replay] {side} source vs follow-FK MCP error in base_link: "
            f"rmse={rmse * 1e3:.2f} mm "
            f"mean={float(error.mean()) * 1e3:.2f} mm "
            f"p95={float(np.quantile(error, 0.95)) * 1e3:.2f} mm "
            f"max={float(error.max()) * 1e3:.2f} mm "
            f"({int(np.count_nonzero(mask))} frames × 4 MCP)",
            flush=True,
        )


def _write_reference_episode(
    source: Path,
    destination: Path,
    replay_path: Path | None,
    *,
    published_directory: Path,
    measured_videos: Mapping[str, Mapping[str, object]] | None = None,
    replay_data: Mapping[str, np.ndarray] | None = None,
    source_document: Mapping[str, object] | None = None,
) -> None:
    """Write every non-video file of the published episode.

    All of it -- the JSON, the numeric sidecar, the head timestamps, the
    calibration and the replay provenance -- is assembled through
    :mod:`data_format`, which owns every name and convention.
    ``measured_videos`` maps a published MP4 name to what was actually measured in
    it, so ``calibration.json`` describes the streams that shipped.
    """

    # ``published_directory`` is used to record deterministic sidecar identity.

    episode_id = source.name
    write_parts: dict[str, float] = {}
    part_started = time.monotonic()
    staged_json = data_format.episode_json_path(destination)
    source_json = (
        staged_json if staged_json.is_file() else data_format.episode_json_path(source)
    )
    raw = (
        dict(source_document)
        if source_document is not None
        else data_format.load_episode_json(source_json)
    )
    write_parts["load_source_json"] = time.monotonic() - part_started
    part_started = time.monotonic()
    raw_frames = raw.get("data")
    if not isinstance(raw_frames, list) or not raw_frames:
        raise ValueError(f"Episode JSON has no non-empty data[]: {source_json}")
    try:
        source_timestamp = data_format.timestamp_as_int(
            raw_frames[0][data_format.TIMESTAMP_KEY]
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"First source frame has no integer timestamp: {source_json}") from exc

    if replay_data is None and replay_path is None:
        raise ValueError("replay_path is required when replay_data is None")
    archive_context = _ReplayArchiveContext(
        replay_data
        if replay_data is not None
        else np.load(replay_path, allow_pickle=False)
    )
    with archive_context as archive:
        required = {
            "timestamps", "playback_fps", "arm_q", "arm_q_names",
            "wuji_hand_q", "wuji_hand_q_names",
            "left_wrist_position_base", "right_wrist_position_base",
            "left_wrist_quaternion_base_xyzw",
            "right_wrist_quaternion_base_xyzw",
        }
        archive_names = (
            set(archive.files)
            if hasattr(archive, "files")
            else set(archive.keys())
        )
        missing = sorted(required.difference(archive_names))
        if missing:
            raise KeyError(f"Interpolated replay is missing arrays: {', '.join(missing)}")
        relative_time = np.asarray(archive["timestamps"], dtype=np.float64)
        from json_replay import _replay_transforms
        transforms = _replay_transforms(archive, required=True)
        thumb_table_clearance_m = float(np.asarray(archive.get("thumb_table_clearance_m", np.nan)).item())
        table_thumb_height_correction_m = float(np.asarray(archive.get("table_thumb_height_correction_m", np.nan)).item())
        source_execution_indices = np.asarray(
            archive.get("video_source_execution_indices", []), dtype=np.int64
        )
        raw_frame_indices = np.asarray(archive.get("frame_indices", []))
        fps = float(np.asarray(archive["playback_fps"]).item())
        arm_q = np.asarray(archive["arm_q"], dtype=np.float64)
        arm_names = np.asarray(archive["arm_q_names"])
        left_arm = _named_arm_side_columns(arm_q, arm_names, "left")
        right_arm = _named_arm_side_columns(arm_q, arm_names, "right")
        combined_hand_q = np.asarray(archive["wuji_hand_q"], dtype=np.float64)
        combined_hand_names = np.asarray(archive["wuji_hand_q_names"])
        hand_q = {
            side: _named_hand_joint_columns(
                combined_hand_q, combined_hand_names, side
            )
            for side in ("left", "right")
        }
        wrist_position = {
            side: np.asarray(archive[f"{side}_wrist_position_base"], dtype=np.float64)
            for side in ("left", "right")
        }
        wrist_quaternion = {
            side: np.asarray(
                archive[f"{side}_wrist_quaternion_base_xyzw"], dtype=np.float64
            )
            for side in ("left", "right")
        }
        stored_urdf = np.asarray(archive.get("composite_urdf_path", ""))
        archived_urdf = (
            Path(str(stored_urdf.item())).expanduser()
            if stored_urdf.ndim == 0 and str(stored_urdf.item())
            else None
        )
        composite_urdf = (
            archived_urdf
            if archived_urdf is not None and archived_urdf.is_file()
            else _DEFAULT_COMPOSITE_URDF
        )
        move_from_start = bool(
            np.asarray(archive.get("move_from_start", False)).item()
        )
        ramp_frame_count = int(
            np.asarray(archive.get("move_from_start_ramp_frame_count", 0)).item()
        )
        arm_ik_success = np.asarray(
            archive.get("arm_ik_success", np.ones(len(arm_q), dtype=bool)),
            dtype=bool,
        )
        alignment_workspace_points_world = np.asarray(
            archive.get("alignment_workspace_points_world", np.empty((0, 3))),
            dtype=np.float64,
        )
        alignment_workspace_points_base = np.asarray(
            archive.get("alignment_workspace_points_base", np.empty((0, 3))),
            dtype=np.float64,
        )
        alignment_workspace_targets_base = np.asarray(
            archive.get("alignment_workspace_point_targets_base", np.empty((0, 3))),
            dtype=np.float64,
        )
        alignment_iterations = int(
            np.asarray(archive.get("alignment_iterations", 0)).item()
        )
        alignment_converged = bool(
            np.asarray(archive.get("alignment_converged", False)).item()
        )
        alignment_cost_total = float(
            np.asarray(archive.get("cost_total", np.nan)).item()
        )
        sdk_source_skeletons = {
            side: np.asarray(archive[f"{side}_skeleton_position_world"], dtype=np.float64)
            for side in ("left", "right")
            if f"{side}_skeleton_position_world" in archive_names
        }
        sdk_emf_metadata = str(np.asarray(
            archive.get("hand_sdk_emf_metadata_json", "")).item())
    frame_count = len(relative_time)
    if not math.isfinite(fps) or fps <= 0.0:
        raise ValueError(f"Invalid interpolated playback_fps: {fps}")
    expected_shapes = {
        "left_arm": left_arm.shape,
        "right_arm": right_arm.shape,
        "left_hand": hand_q["left"].shape,
        "right_hand": hand_q["right"].shape,
    }
    if (
        left_arm.shape[0] != frame_count
        or right_arm.shape[0] != frame_count
        or left_arm.shape[1] not in (6, 7)
        or right_arm.shape[1] not in (6, 7)
        or left_arm.shape[1] != right_arm.shape[1]
    ):
        raise ValueError(f"Interpolated arm trajectory shape mismatch: {expected_shapes}")
    for side in ("left", "right"):
        if hand_q[side].shape != (frame_count, 20):
            raise ValueError(f"Interpolated {side} hand_q must have shape [T,20]")
        if wrist_position[side].shape != (frame_count, 3):
            raise ValueError(f"Interpolated {side} wrist positions must have shape [T,3]")
        if wrist_quaternion[side].shape != (frame_count, 4):
            raise ValueError(f"Interpolated {side} wrist quaternions must have shape [T,4]")
    write_parts["archive_extract"] = time.monotonic() - part_started

    part_started = time.monotonic()
    eef_position, eef_rotation = _controller_eef_from_base_palm(
        wrist_position, wrist_quaternion, composite_urdf
    )
    write_parts["eef"] = time.monotonic() - part_started

    # The episode clock, the head timestamps and the video presentation times are
    # all this one grid, so data[i] and frame i of every stream are one instant.
    part_started = time.monotonic()
    timestamps = data_format.frame_timestamps_ns(source_timestamp, frame_count, fps)
    data_format.validate_relative_timestamps(relative_time, fps)
    # Batch the numeric control block once. A CUDA JSON kernel cannot emit
    # the published text document; the cost here is host dict assembly.
    control_lists = {
        data_format.arm_joint_key("left"): np.asarray(left_arm, dtype=np.float64).tolist(),
        data_format.arm_joint_key("right"): np.asarray(right_arm, dtype=np.float64).tolist(),
        data_format.eef_position_key("left"): np.asarray(
            eef_position["left"], dtype=np.float64
        ).tolist(),
        data_format.eef_position_key("right"): np.asarray(
            eef_position["right"], dtype=np.float64
        ).tolist(),
        data_format.eef_rotation_6d_key("left"): data_format.rotation_6d_batch(
            eef_rotation["left"]
        ),
        data_format.eef_rotation_6d_key("right"): data_format.rotation_6d_batch(
            eef_rotation["right"]
        ),
        data_format.hand_joint_key("left"): np.asarray(
            hand_q["left"], dtype=np.float64
        ).tolist(),
        data_format.hand_joint_key("right"): np.asarray(
            hand_q["right"], dtype=np.float64
        ).tolist(),
    }
    control_keys = data_format.control_frame_keys()
    timestamp_list = [int(value) for value in timestamps]
    relative_list = np.asarray(relative_time, dtype=np.float64).tolist()
    frames: list[dict[str, object]] = []
    for index in range(frame_count):
        frame: dict[str, object] = {
            data_format.TIMESTAMP_KEY: timestamp_list[index],
            data_format.RELATIVE_TIMESTAMP_KEY: float(relative_list[index]),
        }
        for key in control_keys:
            frame[key] = control_lists[key][index]
        frames.append(frame)
    write_parts["build_control_frames"] = time.monotonic() - part_started

    part_started = time.monotonic()
    raw_indices, anchor_positions = _source_frame_mapping(
        source_execution_indices, raw_frame_indices,
        frame_count=frame_count, raw_count=len(raw_frames), ramp_frames=ramp_frame_count,
    )
    world_to_base = transforms["world_to_base_transform"]
    unique_raw = []
    seen_raw: set[int] = set()
    for raw_index in (int(value) for value in raw_indices):
        if raw_index in seen_raw:
            continue
        seen_raw.add(raw_index)
        unique_raw.append(raw_index)
    source_observations = [raw_frames[index] for index in unique_raw]
    if sdk_source_skeletons:
        # The source is the measured EMF derivative from this solve, not robot FK
        # or the collection's older builtin-default hand skeleton. Hold it at the
        # same original anchors as source Wuji q; never use interpolated bones.
        from wuji_retarget.hand_retarget import STANDARD_MANO_TO_MEDIAPIPE
        to_mano = np.argsort(STANDARD_MANO_TO_MEDIAPIPE)
        for side, skeletons in sdk_source_skeletons.items():
            if skeletons.shape != (frame_count, 21, 3) or not np.isfinite(skeletons).all():
                raise ValueError(f"{side}: calibrated source skeleton is misaligned or nonfinite")
        anchor_by_raw = {}
        for execution_index in (source_execution_indices if len(source_execution_indices)
                                else np.arange(frame_count)):
            anchor_by_raw[int(raw_indices[execution_index])] = int(execution_index)
        source_observations = []
        for raw_index in unique_raw:
            observation = dict(raw_frames[raw_index])
            anchor_index = anchor_by_raw[raw_index]
            for side, skeletons in sdk_source_skeletons.items():
                observation[data_format.source_mano21_key(side)] = (
                    skeletons[anchor_index, to_mano].reshape(-1).tolist())
                observation[data_format.source_hand_joint_key(side)] = hand_q[side][anchor_index].tolist()
            source_observations.append(observation)
    converted_unique = data_format.transform_source_fields_world_to_base_many(
        _source_observation_fields_many(source_observations),
        world_to_base,
    )
    source_by_raw = {
        raw_index: fields
        for raw_index, fields in zip(unique_raw, converted_unique)
    }
    for index, frame in enumerate(frames):
        raw_index = int(raw_indices[index])
        cached_source = source_by_raw[raw_index]
        source_values = dict(cached_source)
        # Source Wuji q is a retargeted value at the preceding original anchor,
        # never the interpolated follow_* command at this execution frame.
        anchor_index = int(source_execution_indices[anchor_positions[index]]) if len(source_execution_indices) else index
        for side in ("left", "right"):
            key = data_format.source_hand_joint_key(side)
            if key not in source_values:
                source_values[key] = (
                    hand_q[side][anchor_index].tolist()
                    if source_values.get(data_format.source_mano21_key(side)) is not None
                    else None
                )
        frame.update(source_values)
    write_parts["source_transform"] = time.monotonic() - part_started

    part_started = time.monotonic()
    document = data_format.episode_document(episode_id, frames)
    payload = data_format.dump_episode_json(document)
    data_format.validate_episode_document(document)
    episode_json = destination / data_format.episode_json_name(episode_id)
    if episode_json.is_symlink():
        episode_json.unlink()
    data_format.invalidate_episode_json_cache(episode_json)
    data_format.atomic_write_bytes(episode_json, payload)
    write_parts["dump+json_io"] = time.monotonic() - part_started

    def _write_sidecars() -> None:
        metadata_document = data_format.replay_metadata_document(
                episode_id=episode_id,
                total=frame_count,
                fps=fps,
                transforms={key: value.tolist() for key, value in transforms.items()},
                source_episode_path=source.resolve(),
                source_frame_indices=raw_indices.tolist(),
                thumb_table_clearance_m=thumb_table_clearance_m,
                table_thumb_height_correction_m=table_thumb_height_correction_m,
                move_from_start=move_from_start,
                move_from_start_ramp_frame_count=ramp_frame_count,
                arm_ik_success_count=int(np.count_nonzero(arm_ik_success)),
                arm_ik_total_count=int(arm_ik_success.size),
                arm_ik_failure_count=int(
                    arm_ik_success.size - np.count_nonzero(arm_ik_success)
                ),
            )
        if sdk_source_skeletons:
            metadata_document["source_wuji_policy"] = "same calibrated EMF solve at previous source anchor"
            metadata_document["source_skeleton_policy"] = "same calibrated EMF solve used for finger q and MCP alignment"
        if sdk_emf_metadata:
            metadata_document["hand_sdk_emf_metadata"] = json.loads(sdk_emf_metadata)
        data_format.write_replay_metadata(destination, metadata_document)
        data_format.write_action_npy(
            episode_json,
            frames,
            converter=_CONVERTER_NAME,
            published_directory=published_directory,
        )
        data_format.write_timestamps_h5(
            destination / data_format.TIMESTAMPS_NAME,
            timestamps,
            fps=fps,
            topic=data_format.head_camera_topic(
                destination
                if (destination / data_format.RAW_TIMESTAMPS_NAME).is_file()
                else source
            ),
            provenance={
                "source_episode_path": str(source.resolve()),
                "timestamp_source": "replay_uniform_grid_anchored_on_raw_first_frame",
                "ramp_frame_count": np.int64(ramp_frame_count),
                "ramp_note": data_format.RAMP_TIMESTAMP_NOTE,
            },
        )
        data_format.write_calibration(
            destination,
            data_format.build_calibration(
                source.resolve(), measured_videos, head_fps=fps
            ),
        )
        for name in _COPIED_EPISODE_METADATA:
            candidate = source / name
            if not candidate.is_file():
                candidate = source.parent / name
            _copy_if_present(candidate, destination / name)

    def _timed_mcp() -> float:
        started = time.monotonic()
        _report_published_mcp_alignment(
            frames,
            hand_q=hand_q,
            wrist_position=wrist_position,
            wrist_quaternion=wrist_quaternion,
            composite_urdf=composite_urdf,
            keyframe_indices=source_execution_indices
            if len(source_execution_indices)
            else None,
        )
        return time.monotonic() - started

    def _timed_sidecars() -> float:
        started = time.monotonic()
        _write_sidecars()
        return time.monotonic() - started

    with ThreadPoolExecutor(max_workers=2) as pool:
        sidecar_future = pool.submit(_timed_sidecars)
        mcp_future = pool.submit(_timed_mcp)
        write_parts["sidecars"] = sidecar_future.result()
        write_parts["mcp_report"] = mcp_future.result()
    print(
        "[batch_replay][timing] write_episode_parts "
        + " ".join(f"{name}={seconds:.3f}s" for name, seconds in write_parts.items()),
        flush=True,
    )


def _trajectory_publish_rejection(replay: Mapping[str, np.ndarray]) -> str | None:
    """Reject a trajectory whose source frames go backwards or drop in a run.

    Ramp holds repeat the first source index and are not drops.  A step of
    more than one source index is a hole.  The hole limit is the same one
    the EMF aligner uses before the arm solve.
    """

    from wuji_retarget.emf_offline import (
        MAX_CONSECUTIVE_DROPPED_FRAMES,
        longest_consecutive_dropped,
    )

    count = int(len(np.asarray(replay["arm_q"])))
    stored = np.asarray(replay.get("frame_indices", []), dtype=np.int64).reshape(-1)
    if stored.size == 0:
        stored = np.arange(count, dtype=np.int64)
    if stored.shape != (count,):
        return (
            f"trajectory frame_indices length {stored.size} does not match "
            f"{count} solved frames"
        )
    if np.any(stored < 0):
        return "trajectory frame_indices contain a negative source index"
    if stored.size > 1 and np.any(np.diff(stored) < 0):
        backward = int(np.flatnonzero(np.diff(stored) < 0)[0])
        return (
            "trajectory source frames go backwards at solved frame "
            f"{backward}: {int(stored[backward])} -> {int(stored[backward + 1])}"
        )
    dropped: list[int] = []
    for previous, current in zip(stored[:-1], stored[1:]):
        gap = int(current) - int(previous)
        if gap > 1:
            dropped.extend(range(int(previous) + 1, int(current)))
    run = longest_consecutive_dropped(dropped)
    if run >= int(MAX_CONSECUTIVE_DROPPED_FRAMES):
        preview = dropped[:20]
        return (
            f"trajectory drops {len(dropped)} source frames, longest consecutive "
            f"run {run} (limit {int(MAX_CONSECUTIVE_DROPPED_FRAMES)}): {preview}"
        )
    return None


def _video_presentation_rejection(path: Path, *, frames: int) -> str | None:
    """Reject a video whose decoded pictures are not in PTS order.

    The decoder yields pictures in display order.  A player that honors PTS
    shows a rollback when those timestamps go backwards, which is what
    ``setts=pts=N`` does to a B-frame stream.
    """

    import av

    container = av.open(str(path))
    try:
        if not container.streams.video:
            return f"{path.name}: no video stream"
        stream = container.streams.video[0]
        previous: int | None = None
        count = 0
        for frame in container.decode(stream):
            if frame.pts is None:
                return (
                    f"{path.name}: decoded frame {count} has no presentation timestamp"
                )
            current = int(frame.pts)
            if previous is not None and current <= previous:
                return (
                    f"{path.name}: picture order is wrong at decoded frame {count} "
                    f"(pts {previous} -> {current})"
                )
            previous = current
            count += 1
    finally:
        container.close()
    if count != int(frames):
        return f"{path.name}: decoded {count} frames, trajectory has {int(frames)}"
    return None


def _publish_rejection(
    staging: Path,
    replay: Mapping[str, np.ndarray],
    videos: Mapping[str, Mapping[str, object]],
) -> str | None:
    """Last check before an episode is written.  ``None`` means publish it."""

    reason = _trajectory_publish_rejection(replay)
    if reason is not None:
        return reason
    frames = int(len(np.asarray(replay["arm_q"])))
    names = [name for name in videos if (staging / name).is_file()]
    if not names:
        return "no camera videos to check"
    with ThreadPoolExecutor(max_workers=len(names)) as pool:
        reasons = list(
            pool.map(
                lambda name: _video_presentation_rejection(
                    staging / name, frames=frames
                ),
                names,
            )
        )
    for reason in reasons:
        if reason is not None:
            return reason
    return None


def _publish_interpolated_videos(
    staging: Path,
    replay_path: Path | None,
    replay_data: Mapping[str, np.ndarray] | None = None,
) -> dict[str, dict[str, object]]:
    """Rename each stream, enforce the video contract, and measure the result.

    The measurements are returned rather than discarded because they are what
    ``calibration.json`` has to register for every stream that shipped.
    """
    if replay_data is None:
        if replay_path is None:
            raise ValueError("replay_path is required when replay_data is None")
        with np.load(replay_path, allow_pickle=False) as archive:
            frame_count = len(np.asarray(archive["arm_q"]))
            fps = float(np.asarray(archive["playback_fps"]).item())
    else:
        frame_count = len(np.asarray(replay_data["arm_q"]))
        fps = float(np.asarray(replay_data["playback_fps"]).item())
    prepared: list[tuple[str, Path]] = []
    for source_name, interpolated_name, published_name in zip(
        _SOURCE_VIDEO_NAMES, _INTERPOLATED_VIDEO_NAMES, _PUBLISHED_VIDEO_NAMES
    ):
        source_path = staging / source_name
        interpolated_path = staging / interpolated_name
        published_path = staging / published_name
        candidate = interpolated_path if interpolated_path.is_file() else source_path
        if not candidate.is_file():
            continue
        if published_path.is_symlink() or published_path.exists():
            if published_path.is_symlink():
                published_path.unlink()
            else:
                raise FileExistsError(f"Cannot replace existing video: {published_path}")
        if candidate.is_symlink():
            shutil.copy2(candidate.resolve(), published_path)
        else:
            os.replace(candidate, published_path)
        prepared.append((published_name, published_path))
    if not prepared:
        raise RuntimeError("No source camera MP4s found to publish")

    ffmpeg = data_format.resolve_ffmpeg()
    encode_threads = _video_encode_threads()

    def _comply(item: tuple[str, Path]) -> tuple[str, dict[str, object], str]:
        published_name, published_path = item
        info, action = data_format.ensure_compliant_video(
            ffmpeg, published_path, threads=encode_threads
        )
        data_format.validate_video_alignment(
            published_name, info, frames=frame_count, fps=fps
        )
        return published_name, dict(info), action

    published: dict[str, dict[str, object]] = {}
    with ThreadPoolExecutor(max_workers=len(prepared)) as pool:
        for published_name, info, action in pool.map(_comply, prepared):
            published[published_name] = info
            if action != "ok":
                print(
                    f"[batch_replay] {published_name}: {action} for video contract",
                    flush=True,
                )
    return published


def _source_json_cache_root() -> Path:
    configured = os.environ.get("GEORT_JSON_CACHE", "").strip()
    if configured:
        return Path(configured)
    shm = Path("/dev/shm/umr_episode_json")
    if os.access("/dev/shm", os.W_OK):
        return shm
    return Path(tempfile.gettempdir()) / "umr_episode_json"


def _materialize_source_json_cache(source_json: Path) -> Path:
    """Local byte-identical copy of the source episode JSON.

    The published ``<episode>.json`` is still written by
    :func:`data_format.write_episode_json`. This cache is only a faster
    read of the raw collection file.
    """

    resolved = source_json.resolve()
    stat = resolved.stat()
    digest = hashlib.sha256(
        f"{resolved}:{stat.st_size}:{stat.st_mtime_ns}".encode("utf-8")
    ).hexdigest()[:16]
    cache = _source_json_cache_root() / f"{resolved.stem}.{digest}.json"
    if cache.is_file() and cache.stat().st_size == stat.st_size:
        return cache
    cache.parent.mkdir(parents=True, exist_ok=True)
    temporary = cache.with_name(f".{cache.name}.{os.getpid()}.tmp")
    try:
        temporary.write_bytes(resolved.read_bytes())
        os.replace(temporary, cache)
    finally:
        temporary.unlink(missing_ok=True)
    return cache


def _link_episode_inputs(source: Path, staging: Path, *, log_name: str) -> None:
    """Expose immutable source files while keeping all generated caches staged."""

    source_json_name = data_format.episode_json_name(source.name)
    known = (
        source_json_name,
        f"{source_json_name}.obdownload",
        *_SOURCE_VIDEO_NAMES,
        *data_format.COPIED_METADATA_NAMES,
        data_format.CALIBRATION_NAME,
        data_format.TIMESTAMPS_NAME,
        data_format.RAW_TIMESTAMPS_NAME,
        WUJI_GLOVE_OFFLINE_H5,
        WUJI_GLOVE_TF_H5,
    )
    source_h5 = source / WUJI_GLOVE_OFFLINE_H5
    if not source_h5.is_file():
        raise FileNotFoundError(
            f"Raw EMF is required for wuji-v3 SDK retarget: {source_h5}"
        )
    for name in known:
        item = source / name
        if not item.is_file():
            continue
        destination = staging / item.name
        if item.name == f"{source_json_name}.obdownload":
            shutil.copy2(item, destination)
        elif item.name == source_json_name:
            cached = _materialize_source_json_cache(item)
            if destination.exists() or destination.is_symlink():
                destination.unlink()
            os.symlink(cached, destination)
        else:
            os.symlink(item.resolve(), destination)


def _remove_staged_source_files(source: Path, staging: Path, *, log_name: str) -> None:
    """Drop raw staging inputs. List staging only — never readdir JFS."""

    retained = set(_PUBLISHED_VIDEO_NAMES)
    retained.add(data_format.episode_json_name(source.name))
    retained.add(data_format.RAW_TIMESTAMPS_NAME)
    retained.add(log_name)
    for path in list(staging.iterdir()):
        if path.name in retained:
            continue
        if path.suffix == ".npz" and path.name in {
            "wuji_replay.npz",
            "wuji_replay_interpolate.npz",
        }:
            continue
        if path.is_symlink() or path.is_file():
            path.unlink(missing_ok=True)


def _reference_json_metrics(path: Path) -> tuple[int, int, int]:
    """Read the compact IK summary embedded in a published action JSON."""

    payload = data_format.load_episode_json(path)
    frames = payload.get("data")
    if not isinstance(frames, list) or not frames:
        raise ValueError(f"Published action JSON has no frames: {path}")
    from json_replay import _load_replay_metadata
    payload = _load_replay_metadata(path, payload)
    total = int(payload.get("arm_ik_total_count", len(frames)))
    successes = int(payload.get("arm_ik_success_count", total))
    failures = int(payload.get("arm_ik_failure_count", total - successes))
    if total < 1 or successes < 0 or failures < 0 or successes + failures != total:
        raise ValueError(f"Invalid arm-IK summary in {path}")
    return successes, total, failures


def _is_complete_episode_directory(path: Path) -> bool:
    if not path.is_dir():
        return False
    required = tuple(path / name for name in _required_episode_output_names(path.name))
    if not all(item.is_file() for item in required):
        return False
    try:
        _reference_json_metrics(data_format.episode_json_path(path))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return False
    return True


def _inspect_worker(json_path: Path, video_path: Path, output_path: Path) -> None:
    """Render the standard MANO-21 projection check required by data_format.md."""

    import cv2

    episode = json.loads(json_path.read_text(encoding="utf-8"))
    camera_matrix, distortion = data_format.intrinsic_from_calibration(
        data_format.read_calibration(json_path.parent)
    )
    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise RuntimeError(f"Could not open inspection source video: {video_path}")
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    temporary_path = output_path.with_name(f".{output_path.stem}.raw.mp4")
    writer = cv2.VideoWriter(
        str(temporary_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )
    if not writer.isOpened():
        capture.release()
        raise RuntimeError(f"Could not create inspection video: {temporary_path}")
    edges = (
        (0, 1), (1, 2), (2, 3), (3, 4),
        (0, 5), (5, 6), (6, 7), (7, 8),
        (0, 9), (9, 10), (10, 11), (11, 12),
        (0, 13), (13, 14), (14, 15), (15, 16),
        (0, 17), (17, 18), (18, 19), (19, 20),
    )
    try:
        for frame_index, data in enumerate(episode[data_format.ENVELOPE_DATA_KEY]):
            ok, image = capture.read()
            if not ok:
                raise RuntimeError(
                    f"Inspection video ended at frame {frame_index}"
                )
            position = data.get(data_format.SOURCE_HEAD_POSITION_KEY)
            rotation_6d = data.get(data_format.SOURCE_HEAD_ROTATION_6D_KEY)
            if position is not None and rotation_6d is not None:
                columns = np.asarray(rotation_6d, dtype=np.float64).reshape(
                    3, 2, order="F"
                )
                first = _normalise(columns[:, 0])
                second = _normalise(
                    columns[:, 1] - np.dot(columns[:, 1], first) * first
                )
                camera_rotation = np.column_stack(
                    (first, second, np.cross(first, second))
                )
                camera_position = np.asarray(position, dtype=np.float64)
                for side, colour in (("left", (255, 128, 0)), ("right", (0, 200, 80))):
                    flattened = data.get(data_format.source_mano21_key(side))
                    if flattened is None:
                        continue
                    world = np.asarray(flattened, dtype=np.float64).reshape(21, 3)
                    camera = (world - camera_position) @ camera_rotation
                    if np.any(camera[:, 2] <= 1e-6):
                        continue
                    pixels, _ = cv2.projectPoints(
                        camera,
                        np.zeros(3),
                        np.zeros(3),
                        camera_matrix,
                        distortion,
                    )
                    pixels = np.rint(pixels.reshape(-1, 2)).astype(int)
                    for parent, child in edges:
                        cv2.line(
                            image,
                            tuple(pixels[parent]),
                            tuple(pixels[child]),
                            colour,
                            2,
                            cv2.LINE_AA,
                        )
                    for pixel in pixels:
                        cv2.circle(image, tuple(pixel), 3, colour, -1, cv2.LINE_AA)
            writer.write(image)
    finally:
        capture.release()
        writer.release()
    try:
        _transcode_standard_video(temporary_path, output_path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _timestamps_worker(
    source_path: Path,
    output_path: Path,
    *,
    fps: float,
    frame_count: int,
) -> None:
    """Copy a raw head timestamp series into the published layout."""

    import h5py

    with h5py.File(source_path, "r", locking=False) as source:
        groups = [value for value in source.values() if isinstance(value, h5py.Group)]
        if len(groups) != 1 or data_format.TIMESTAMPS_DATASET not in groups[0]:
            raise ValueError(f"Unexpected source timestamp layout: {source_path}")
        source_group = groups[0]
        timestamps = np.asarray(
            source_group[data_format.TIMESTAMPS_DATASET], dtype=np.int64
        )
        topic = str(
            source_group.attrs.get(
                data_format.TIMESTAMPS_TOPIC_ATTR, data_format.DEFAULT_HEAD_CAMERA_TOPIC
            )
        )
    if timestamps.shape != (frame_count,):
        raise ValueError(
            f"Timestamp count does not match video: {timestamps.shape}, "
            f"expected ({frame_count},)"
        )
    data_format.write_timestamps_h5(output_path, timestamps, fps=fps, topic=topic)


def _device_args(device: str) -> list[str]:
    return [
        "--device",
        device,
        "--laplacian_device",
        device,
    ]


def _tail(path: Path, line_count: int = 20) -> str:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-line_count:])


def _add_move_from_start_outputs(
    staging: Path,
    replay_path: Path | None,
    *,
    fps: float,
    environment: Mapping[str, str],
    log_handle: Any,
    inpaint_background: bool = False,
    replay_data: dict[str, np.ndarray] | None = None,
) -> int:
    """Build the ramp and a frame-aligned prefix for all three videos."""

    ramp_started = time.monotonic()
    # Ramp generation is a small CPU-side array/FK operation. Running a fresh
    # subprocess used to cost ~5 s per episode just to import Torch, SciPy and
    # the URDF stack. Keep it in the long-lived batch process so those modules
    # are imported once. Set GEORT_RAMP_SUBPROCESS=1 for the isolated fallback.
    if os.environ.get("GEORT_RAMP_SUBPROCESS", "0") == "1" and replay_data is None:
        if replay_path is None:
            raise ValueError("replay_path is required when replay_data is None")
        ramp_command = [
            *_worker_prefix(),
            "-m",
            "calibrated.batch_replay",
            "--_prepend-ramp-worker",
            str(replay_path),
            str(fps),
        ]
        log_handle.write(
            f"[batch_replay] ramp command: {shlex.join(ramp_command)}\n"
        )
        log_handle.flush()
        completed = subprocess.run(
            ramp_command,
            cwd=str(_PKG_ROOT),
            env=dict(environment),
            check=False,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
        )
        if completed.returncode not in {0, None}:
            complete_ramp = False
            if replay_path is not None and replay_path.is_file():
                try:
                    with np.load(replay_path, allow_pickle=False) as archive:
                        complete_ramp = (
                            "move_from_start_ramp_frame_count" in archive.files
                            and _is_complete_output(replay_path)
                        )
                except (OSError, ValueError):
                    complete_ramp = False
            if completed.returncode in {-11, 139} and complete_ramp:
                log_handle.write(
                    "[batch_replay] ignoring ramp worker "
                    f"SIGSEGV ({completed.returncode}) after a complete replay\n"
                )
                log_handle.flush()
            else:
                raise subprocess.CalledProcessError(
                    completed.returncode, ramp_command
                )
    else:
        if replay_data is None:
            if replay_path is None:
                raise ValueError("replay_path is required when replay_data is None")
            _prepend_move_from_start_ramp(replay_path, fps)
        else:
            ramp_output: dict[str, np.ndarray] = {}
            _prepend_move_from_start_ramp(
                replay_data, fps, output_sink=ramp_output
            )
            replay_data.clear()
            replay_data.update(ramp_output)
    if replay_data is None:
        with np.load(replay_path, allow_pickle=False) as archive:
            ramp_frames = int(
                np.asarray(archive["move_from_start_ramp_frame_count"]).item()
            )
    else:
        ramp_frames = int(
            np.asarray(replay_data["move_from_start_ramp_frame_count"]).item()
        )
    if ramp_frames < 1:
        raise RuntimeError("move_from_start produced no ramp frames")
    log_handle.write(
        f"[batch_replay][timing] ramp trajectory worker = "
        f"{time.monotonic() - ramp_started:.3f}s\n"
    )
    log_handle.flush()

    def _ramp_one_video(source_name: str, interpolated_name: str) -> str:
        source_video = staging / source_name
        interpolated_video = staging / interpolated_name
        main_video = (
            interpolated_video if interpolated_video.is_file() else source_video
        )
        video_started = time.monotonic()
        _prepend_background_frames(
            main_video,
            source_video,
            fps=fps,
            frame_count=ramp_frames,
            background_is_inpainted=False,
            output_path=interpolated_video,
        )
        elapsed = time.monotonic() - video_started
        return (
            f"[batch_replay][timing] ramp video {source_name} = {elapsed:.3f}s\n"
        )

    log_handle.write(
        "[batch_replay] ramp background inpainting disabled; "
        "repeating the first source frame of each camera\n"
    )
    log_handle.flush()
    with ThreadPoolExecutor(max_workers=3) as pool:
        notes = list(
            pool.map(
                lambda pair: _ramp_one_video(*pair),
                zip(_SOURCE_VIDEO_NAMES, _INTERPOLATED_VIDEO_NAMES),
            )
        )
    for note in notes:
        log_handle.write(note)
    log_handle.flush()
    return ramp_frames


def _run_episode(
    episode: Path,
    *,
    device: str,
    gpu_selector: str,
    forwarded: Sequence[str],
    output_root: Path,
    log_name: str,
    skip_existing: bool,
    overwrite: bool,
    dry_run: bool,
    trajectory_execution: str,
    interpolation_execution: str,
    rife_worker: _PersistentRifeWorker | None,
    cpu_threads: int,
    ik_failure_limit: int,
    interpolation_backend: str,
    interpolation_output_fps: float,
    interpolation_candidate_count: int,
    interpolation_pose_method: str,
    interpolation_max_velocity: float,
    interpolation_max_hand_velocity: float,
    interpolation_max_acceleration: float,
    interpolation_max_hand_acceleration: float,
    interpolation_minimum_playback_rate: float,
    interpolation_maximum_playback_rate: float,
    rife_batch_size: int,
    rife_scale: float,
    rife_fp16: bool,
    move_from_start: bool,
    move_from_start_inpaint_background: bool,
    composite_urdf: Path | None = None,
    collision_config: Path | None = None,
    generation: str | None = None,
    initial_position: Sequence[float] | None = None,
) -> EpisodeResult:
    final_directory = output_root / episode.name
    output = data_format.episode_json_path(final_directory)
    worker_log = final_directory / log_name
    started = time.monotonic()
    if skip_existing and _is_complete_episode_directory(final_directory):
        successes, total, failures = _reference_json_metrics(output)
        return EpisodeResult(
            episode=episode.name,
            output=str(output),
            log=str(worker_log),
            device=device,
            status="skipped",
            duration_seconds=0.0,
            ik_successes=successes,
            ik_total=total,
            ik_failures=failures,
            interpolated_videos=tuple(
                str(final_directory / name)
                for name in _SOURCE_VIDEO_NAMES
                if (final_directory / name).is_file()
            ),
        )
    if final_directory.exists() and not overwrite:
        raise FileExistsError(
            f"Output episode already exists (use --overwrite or --skip-existing): "
            f"{final_directory}"
        )

    if dry_run:
        command = [
            *_worker_prefix(), "-m", REPLAY_ENTRY,
            "--test_data", str(episode), "--out", "<replay-archive>",
            *_batch_solver_defaults(
                composite_urdf,
                collision_config,
                generation=generation,
                initial_position=initial_position,
            ),
            *forwarded, *_device_args(device),
        ]
        print(f"[{device}] {episode.name}: {shlex.join(command)}", flush=True)
        return EpisodeResult(
            episode=episode.name,
            output=str(output),
            log=str(worker_log),
            device=device,
            status="dry-run",
            duration_seconds=0.0,
        )

    _ensure_world_writable_dir(output_root)
    staging = Path(tempfile.mkdtemp(prefix=f".{episode.name}.", dir=output_root))
    _chmod_world_writable(staging)
    staged_log = staging / log_name
    link_started = time.monotonic()
    _link_episode_inputs(episode, staging, log_name=log_name)
    staged_json = data_format.episode_json_path(staging)
    source_document = None
    if staged_json.is_file():
        source_document = data_format.load_episode_json(staged_json)
    link_s = time.monotonic() - link_started
    trajectory_replay_data: dict[str, np.ndarray] | None = None

    environment = os.environ.copy()
    environment["PYTHONPATH"] = _pythonpath_with_layout()
    environment["PYTHONUNBUFFERED"] = "1"
    environment.update(_sdk_env_updates())
    environment.setdefault("OMP_NUM_THREADS", str(cpu_threads))
    environment.setdefault("MKL_NUM_THREADS", str(cpu_threads))
    no_npz_transport = (
        trajectory_execution == "inprocess"
        and interpolation_execution == "inprocess"
        and interpolation_backend == "rife"
    )
    previous_no_npz = os.environ.get("GEORT_NO_NPZ")
    staged_output: Path | None = None
    worker_arguments = [
        "--test_data",
        str(staging),
    ]
    if not no_npz_transport:
        shm = Path("/dev/shm")
        npz_dir = shm if os.access(shm, os.W_OK) else staging
        staged_output = npz_dir / f".{episode.name}.{os.getpid()}.wuji_replay.npz"
        worker_arguments.extend(["--out", str(staged_output)])
    worker_arguments.extend(
        [
            *_batch_solver_defaults(
                composite_urdf,
                collision_config,
                generation=generation,
                initial_position=initial_position,
            ),
            *forwarded,
            *_device_args(device),
        ]
    )
    command = [
        *_worker_prefix(),
        "-m",
        REPLAY_ENTRY,
        *worker_arguments,
    ]

    os.environ.update(_sdk_env_updates())
    if no_npz_transport:
        os.environ["GEORT_NO_NPZ"] = "1"
    else:
        os.environ.pop("GEORT_NO_NPZ", None)
    environment.pop("GEORT_NO_NPZ", None)
    try:
        with staged_log.open("w", encoding="utf-8") as log_handle:
            log_handle.write(f"[batch_replay] device: {device}\n")
            log_handle.write(
                "[batch_replay] wuji_sdk_model_config: "
                f"{environment.get('GEORT_WUJI_MODEL_CONFIG') or 'glove URDF'}\n"
            )
            log_handle.write(f"[batch_replay] command: {shlex.join(command)}\n")
            log_handle.write(
                f"[batch_replay][timing] link+prefetch_json = {link_s:.3f}s\n"
            )
            if no_npz_transport:
                log_handle.write(
                    "[batch_replay] replay transport: in-memory (no NPZ)\n"
                )
            log_handle.flush()
            try:
                trajectory_started = time.monotonic()
                if trajectory_execution == "inprocess":
                    import importlib

                    replay_module = importlib.import_module(REPLAY_ENTRY)
                    replay_module.clear_last_replay()
                    stdout_router, stderr_router = _install_thread_local_output_routers()
                    frame_loss_reason = None
                    with stdout_router.route(log_handle), stderr_router.route(
                        log_handle
                    ):
                        try:
                            replay_module.main(worker_arguments)
                        except Exception as exc:
                            if type(exc).__name__ != "TrajectoryFrameLoss":
                                raise
                            frame_loss_reason = str(exc)
                    if frame_loss_reason is not None:
                        log_handle.write(f"[batch_replay] {frame_loss_reason}\n")
                        log_handle.flush()
                        print(
                            f"[batch_replay] skipping trajectory {episode.name}: "
                            f"{frame_loss_reason}",
                            flush=True,
                        )
                        if final_directory.exists():
                            shutil.rmtree(final_directory)
                        return EpisodeResult(
                            episode=episode.name,
                            output="",
                            log="",
                            device=device,
                            status="skipped",
                            duration_seconds=time.monotonic() - started,
                        )
                    trajectory_replay_data = replay_module.get_last_replay()
                    if trajectory_replay_data is None:
                        raise RuntimeError(
                            "in-process trajectory worker did not return replay data"
                        )
                else:
                    worker = _thread_local_trajectory_worker(
                        selector=gpu_selector, environment=environment
                    )
                    try:
                        worker.solve(worker_arguments, staged_log)
                    except Exception:
                        complete_archive = (
                            staged_output is not None
                            and _is_complete_output(staged_output)
                        )
                        if complete_archive:
                            log_handle.write(
                                "[batch_replay] ignoring persistent worker "
                                "error after a complete replay archive\n"
                            )
                            log_handle.flush()
                        else:
                            raise
                    log_handle.write(
                        "[batch_replay] persistent trajectory worker reused "
                        f"pid={getattr(worker._proc, 'pid', None)}\n"
                    )
                log_handle.write(
                    "[batch_replay][timing] trajectory worker = "
                    f"{time.monotonic() - trajectory_started:.3f}s\n"
                )
                log_handle.flush()
            except subprocess.CalledProcessError as exc:
                detail = _tail(staged_log)
                raise RuntimeError(
                    f"trajectory worker exited with code {exc.returncode}; "
                    f"log={staged_log}" + (f"\n{detail}" if detail else "")
                ) from exc
            except (Exception, SystemExit) as exc:
                traceback.print_exc(file=log_handle)
                log_handle.flush()
                detail = _tail(staged_log)
                raise RuntimeError(
                    f"in-process trajectory worker failed: {type(exc).__name__}: "
                    f"{exc}; log={staged_log}"
                    + (f"\n{detail}" if detail else "")
                ) from exc

            if trajectory_replay_data is None:
                if staged_output is None:
                    raise RuntimeError(
                        "trajectory worker returned no in-memory replay data"
                    )
                if not _is_complete_output(staged_output):
                    raise RuntimeError(
                        "worker finished but did not create a complete replay "
                        f"archive: {staged_output}"
                    )
                with np.load(staged_output, allow_pickle=False) as archive:
                    validation_replay_data = {
                        name: archive[name] for name in archive.files
                    }
                successes, total, failures = _replay_metrics_from_data(
                    validation_replay_data
                )
                trajectory_solve_seconds = _trajectory_solve_seconds_from_data(
                    validation_replay_data
                )
            else:
                validation_replay_data = trajectory_replay_data
                successes = int(
                    np.count_nonzero(trajectory_replay_data["arm_ik_success"])
                )
                total = int(trajectory_replay_data["arm_ik_success"].size)
                failures = total - successes
                trajectory_solve_seconds = float(
                    np.asarray(
                        trajectory_replay_data[
                            "trajectory_timing_total_trajectory_solve"
                        ]
                    ).item()
                )
            if failures > ik_failure_limit:
                log_handle.write(
                    f"[batch_replay] IK failures {failures} exceed "
                    f"--ik-failure-limit {ik_failure_limit}; publishing anyway\n"
                )
                log_handle.flush()

            stable_contact, contact_detail = _validate_two_grasp_contact(
                validation_replay_data
            )
            log_handle.write(
                f"[batch_replay] two-grasp contact validation: "
                f"{'matched' if stable_contact else 'unmatched'}; "
                f"{contact_detail}\n"
            )
            log_handle.flush()

            interpolated_replay = None
            interpolation_environment = environment.copy()
            interpolation_environment["CUDA_VISIBLE_DEVICES"] = gpu_selector
            interpolation_started = time.monotonic()
            source_replay = (
                trajectory_replay_data
                if trajectory_replay_data is not None
                else validation_replay_data
            )
            interpolated_replay_data = _apply_publish_clock(
                source_replay, interpolation_output_fps
            )
            execution_count = int(len(interpolated_replay_data["arm_q"]))
            source_count = int(len(validation_replay_data["arm_q"]))
            kept_frames, raw_camera_frames = _align_source_videos_to_replay(
                staging,
                interpolated_replay_data,
                fps=interpolation_output_fps,
            )
            log_handle.write(
                "[batch_replay] aligned source videos to kept replay frames "
                f"(no RIFE); camera={raw_camera_frames}, kept={kept_frames}\n"
            )
            log_handle.write(
                "[batch_replay][timing] video interpolation = "
                f"{time.monotonic() - interpolation_started:.3f}s\n"
            )
            log_handle.write(
                f"[batch_replay] interpolation statistics: source_frames={source_count}, "
                f"execution_frames={execution_count}, retimed_inserted=0 "
                "(0.00%), video_pose_inserted=0\n"
            )
            log_handle.flush()

            postprocess_started = time.monotonic()
            if interpolated_replay_data is None and interpolated_replay is not None and not interpolated_replay.is_file():
                raise RuntimeError(
                    f"Interpolation did not create aligned replay: {interpolated_replay}"
                )
            if move_from_start:
                try:
                    ramp_started = time.monotonic()
                    ramp_frames = _add_move_from_start_outputs(
                        staging,
                        interpolated_replay,
                        fps=interpolation_output_fps,
                        environment=interpolation_environment,
                        log_handle=log_handle,
                        inpaint_background=move_from_start_inpaint_background,
                        replay_data=interpolated_replay_data,
                    )
                except subprocess.CalledProcessError as exc:
                    detail = _tail(staged_log)
                    raise RuntimeError(
                        f"move_from_start worker exited with code {exc.returncode}; "
                        f"log={staged_log}" + (f"\n{detail}" if detail else "")
                    ) from exc
                log_handle.write(
                    f"[batch_replay] prepended {ramp_frames} ramp frames at "
                    f"{interpolation_output_fps:g} fps "
                    f"({time.monotonic() - ramp_started:.3f}s)\n"
                )
            publish_started = time.monotonic()
            measured_videos = _publish_interpolated_videos(
                staging, interpolated_replay, interpolated_replay_data
            )
            publish_s = time.monotonic() - publish_started
            published_videos = tuple(measured_videos)
            if set(published_videos) != set(_PUBLISHED_VIDEO_NAMES):
                raise RuntimeError(
                    "All three source camera streams are required; produced "
                    + ", ".join(published_videos)
                )
            if interpolated_replay_data is None:
                raise RuntimeError("publish check requires the in-memory replay")
            rejection = _publish_rejection(
                staging, interpolated_replay_data, measured_videos
            )
            if rejection is not None:
                log_handle.write(f"[batch_replay] {rejection}\n")
                log_handle.flush()
                print(
                    f"[batch_replay] abandoning {episode.name}: {rejection}",
                    flush=True,
                )
                if final_directory.exists():
                    shutil.rmtree(final_directory)
                return EpisodeResult(
                    episode=episode.name,
                    output="",
                    log="",
                    device=device,
                    status="skipped",
                    duration_seconds=time.monotonic() - started,
                    trajectory_solve_seconds=trajectory_solve_seconds,
                    ik_successes=successes,
                    ik_total=total,
                    ik_failures=failures,
                )
            remove_started = time.monotonic()
            _remove_staged_source_files(episode, staging, log_name=log_name)
            remove_s = time.monotonic() - remove_started
            write_started = time.monotonic()
            _write_reference_episode(
                episode,
                staging,
                interpolated_replay,
                published_directory=final_directory,
                measured_videos=measured_videos,
                replay_data=interpolated_replay_data,
                source_document=source_document,
            )
            write_s = time.monotonic() - write_started
            (staging / data_format.RAW_TIMESTAMPS_NAME).unlink(missing_ok=True)
            # Replay archives are only transient transport for the worker
            # path. The published dataset consumes action JSON and MP4.
            if staged_output is not None:
                staged_output.unlink(missing_ok=True)
            if interpolated_replay is not None:
                interpolated_replay.unlink(missing_ok=True)
            log_handle.write(
                "[batch_replay][timing] interpolation postprocess = "
                f"{time.monotonic() - postprocess_started:.3f}s "
                f"(publish_videos={publish_s:.3f}s, remove_sources={remove_s:.3f}s, "
                f"write_episode={write_s:.3f}s)\n"
            )
            log_handle.flush()
            interpolated_videos = tuple(
                str(final_directory / name) for name in published_videos
            )

        commit_started = time.monotonic()
        if final_directory.exists():
            shutil.rmtree(final_directory)
        os.replace(staging, final_directory)
        _chmod_tree_world_writable(final_directory)
        print(
            f"[batch_replay][timing] commit={time.monotonic() - commit_started:.3f}s",
            flush=True,
        )
        return EpisodeResult(
            episode=episode.name,
            output=str(data_format.episode_json_path(final_directory)),
            log=str(final_directory / log_name),
            device=device,
            status="completed",
            duration_seconds=time.monotonic() - started,
            trajectory_solve_seconds=trajectory_solve_seconds,
            ik_successes=successes,
            ik_total=total,
            ik_failures=failures,
            interpolated_videos=interpolated_videos,
        )
    finally:
        if previous_no_npz is None:
            os.environ.pop("GEORT_NO_NPZ", None)
        else:
            os.environ["GEORT_NO_NPZ"] = previous_no_npz
        try:
            if staging.exists():
                shutil.rmtree(staging)
        except OSError as exc:
            print(
                f"[batch_replay] failed to remove staging {staging.name}: {exc}",
                flush=True,
            )


def _auto_slots(
    gpus: Sequence[GpuInfo],
    *,
    memory_per_worker_gb: float,
    memory_reserve_gb: float,
    maximum: int,
) -> dict[str, int]:
    per_worker_mib = memory_per_worker_gb * 1024.0
    reserve_mib = memory_reserve_gb * 1024.0
    slots: dict[str, int] = {}
    for gpu in gpus:
        if gpu.free_mib is None:
            count = 1
        else:
            count = max(
                0,
                math.floor((gpu.free_mib - reserve_mib) / per_worker_mib),
            )
        slots[gpu.device] = min(count, maximum)
    return slots


def _slot_counts(
    args: argparse.Namespace, gpus: Sequence[GpuInfo]
) -> dict[str, int]:
    if args.workers_per_gpu != "auto":
        try:
            workers = int(args.workers_per_gpu)
        except ValueError as exc:
            raise ValueError(
                "--workers-per-gpu must be 'auto' or a positive integer"
            ) from exc
        if workers < 1:
            raise ValueError("--workers-per-gpu must be >= 1")
        return {gpu.device: workers for gpu in gpus}
    return _auto_slots(
        gpus,
        memory_per_worker_gb=args.gpu_memory_per_worker_gb,
        memory_reserve_gb=args.gpu_memory_reserve_gb,
        maximum=args.max_workers_per_gpu,
    )


def _parse_args(
    argv: Sequence[str] | None = None,
) -> tuple[argparse.Namespace, list[str]]:
    values = list(sys.argv[1:] if argv is None else argv)
    # Preserve the original ``batch_replay.py ROOT ...`` form. Extracting the
    # leading positional ourselves prevents argparse.parse_known_args() from
    # mistaking the value of a forwarded option (for example ``--max_frames
    # 100``) for an optional positional root when --test_data is used.
    positional_root: Path | None = None
    if values and not values[0].startswith("-"):
        positional_root = Path(values.pop(0))
    parser = argparse.ArgumentParser(
        description=__doc__.split("\n", 1)[0],
        usage="%(prog)s [-h] [ROOT | --test_data TEST_DATA] [options]",
        epilog=(
            "Unknown options are forwarded to wuji_replay.py. "
            "Use '--' before forwarded options if one conflicts with this parser."
        ),
    )
    parser.add_argument(
        "--robot",
        choices=tuple(_ROBOT_COMPOSITE_URDFS),
        default=_DEFAULT_ROBOT,
        help=(
            "Composite URDF preset when not using --config: ex001_wuji, "
            "ex001_wuji2, or tianji_wuji2. YAML 'arm' replaces this flag. "
            f"(default: {_DEFAULT_ROBOT})"
        ),
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help=(
            "YAML containing list, output, num_per_folder, fps, "
            "move_from_start, required arm (ex001_wuji / ex001_wuji2 / "
            "tianji_wuji2; replaces --robot), left_glove_urdf / "
            "right_glove_urdf (wearer glove URDFs for SDK EMF→q; null = "
            "builtin_default; left_hand_urdf / right_hand_urdf aliases), "
            "optional grasp_type in [1, 33], optional model_config "
            "(legacy JSON; glove URDFs are left_glove_urdf / "
            "right_glove_urdf and are used directly when this is omitted), "
            "optional initial_position [x, y, z] first-frame dual-palm "
            "midpoint offset from the two arm-base midpoint (null = URDF "
            "seed), optional anchor (mcp default, fingertips, tips, thumb_tip, or wrist; "
            "which_to_track is an alias), and optional retarget_weight "
            "(normal keeps official weights; tip/tips raises fingertip position and orientation weights); "
            "each listed folder is resolved "
            "on the remote host"
        ),
    )
    parser.add_argument(
        "--test_data",
        "--test-data",
        "--data",
        dest="test_data",
        type=Path,
        default=None,
        help=(
            "Local collection directory or folder name. If it is absent "
            "locally, stream its episodes from the configured SSH data root."
        ),
    )
    parser.add_argument(
        "--devices",
        nargs="+",
        default=None,
        help="CUDA devices (default: every visible NVIDIA GPU)",
    )
    parser.add_argument(
        "--workers-per-gpu",
        default="auto",
        help="Concurrent episodes per GPU, or 'auto' (default: auto)",
    )
    parser.add_argument(
        "--trajectory-execution",
        choices=("subprocess", "inprocess"),
        default="inprocess",
        help=(
            "inprocess: solve in this process after a lazy Torch import. "
            "subprocess: one long-lived worker per GPU slot (Torch loaded "
            "once, not per episode)"
        ),
    )
    parser.add_argument(
        "--fused-fk-microbatch-wait-us",
        type=int,
        default=200,
        help=(
            "Maximum collection window for cross-episode fused Warp FK/J "
            "requests in inprocess mode (default: 200 microseconds)"
        ),
    )
    parser.add_argument(
        "--gpu-memory-per-worker-gb",
        type=float,
        default=8.0,
        help="Estimated peak memory used by one worker in auto mode (default: 8)",
    )
    parser.add_argument(
        "--gpu-memory-reserve-gb",
        type=float,
        default=1.0,
        help="Free GPU memory kept unused in auto mode (default: 1)",
    )
    parser.add_argument(
        "--max-workers-per-gpu",
        type=int,
        default=1,
        help=(
            "Safety cap for auto mode (default: 1). Unified sparse GN saturates "
            "one GPU; concurrent episodes increase each solve from about "
            "10-15s to about 50-60s"
        ),
    )
    parser.add_argument(
        "--output-name",
        default="wuji_replay.npz",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=_DEFAULT_OUTPUT_ROOT,
        help=(
            "Directory that receives each episode folder directly "
            f"(default: {_DEFAULT_OUTPUT_ROOT})"
        ),
    )
    parser.add_argument(
        "--model_config",
        "--model-config",
        dest="model_config",
        type=Path,
        default=None,
        help=(
            "Optional legacy wuji-v3 SDK model JSON. Glove URDFs come "
            "from YAML left_glove_urdf / right_glove_urdf or CLI "
            "--left_glove_urdf / --right_glove_urdf and are used directly "
            "when this is omitted."
        ),
    )
    parser.add_argument(
        "--retargeting_solver",
        "--retargeting-solver",
        dest="retargeting_solver",
        default=None,
        help=(
            "Deprecated. Finger q always comes from the wuji-v3 SDK "
            "offline pipeline; this flag is ignored."
        ),
    )
    parser.add_argument(
        "--device-id",
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--log-name",
        default="batch_replay.log",
        help="Worker log filename inside each episode (default: batch_replay.log)",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        help="Skip outputs containing a complete action JSON and three MP4 files",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Replace an existing output episode after its replacement succeeds",
    )
    parser.add_argument(
        "--ik-failure-limit",
        type=int,
        default=5,
        help=(
            "Log when failed arm-IK frames exceed this count. Episodes are "
            "still published (default: 5)"
        ),
    )
    interpolation = parser.add_argument_group("video interpolation")
    interpolation.add_argument(
        "--interpolation-execution",
        choices=("inprocess", "subprocess"),
        default="inprocess",
        help=(
            "Keep one RIFE model resident per GPU in the batch process "
            "(default), or launch an isolated interpolation subprocess"
        ),
    )
    interpolation.add_argument(
        "--interpolation-backend", choices=("rife", "blend"), default="rife"
    )
    interpolation.add_argument(
        "--interpolation-output-fps",
        type=float,
        default=_DEFAULT_BATCH_OUTPUT_FPS,
        help=argparse.SUPPRESS,
    )
    interpolation.add_argument(
        "--interpolation-candidate-count", type=int, default=20
    )
    interpolation.add_argument(
        "--interpolation-pose-method",
        choices=("cartesian", "lie_group"),
        default="cartesian",
    )
    interpolation.add_argument(
        "--interpolation-max-velocity",
        type=float,
        default=_DEFAULT_BATCH_MAX_VELOCITY,
        help="Arm joint velocity limit for near-source-rate replay (default: 15.75 rad/s)",
    )
    interpolation.add_argument(
        "--interpolation-max-hand-velocity",
        type=float,
        default=_DEFAULT_BATCH_MAX_HAND_VELOCITY,
        help="Hand joint velocity limit for near-source-rate replay (default: 31.5 rad/s)",
    )
    interpolation.add_argument(
        "--interpolation-max-acceleration",
        type=float,
        default=_DEFAULT_BATCH_MAX_ACCELERATION,
        help="Arm acceleration limit used for replay retiming (default: 5000 rad/s^2)",
    )
    interpolation.add_argument(
        "--interpolation-max-hand-acceleration",
        type=float,
        default=_DEFAULT_BATCH_MAX_HAND_ACCELERATION,
        help="Hand acceleration limit used for replay retiming (default: 20000 rad/s^2)",
    )
    interpolation.add_argument(
        "--interpolation-maximum-playback-rate",
        type=float,
        default=_DEFAULT_BATCH_MAX_PLAYBACK_RATE,
        help="Playback ceiling (default: 1, preserves the natural FPS baseline)",
    )
    interpolation.add_argument(
        "--interpolation-minimum-playback-rate",
        type=float,
        default=_DEFAULT_BATCH_MIN_PLAYBACK_RATE,
        help="Playback floor (default: 1, do not slow normal source motion)",
    )
    interpolation.add_argument(
        "--rife-scale", type=float, choices=(0.25, 0.5, 1.0, 2.0, 4.0), default=1.0
    )
    interpolation.add_argument("--rife-batch-size", type=int, default=4)
    interpolation.add_argument(
        "--rife-fp16",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Use CUDA FP16 RIFE inference (default: enabled; use "
            "--no-rife-fp16 for the FP32 reference path)"
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print worker commands without running them",
    )
    remote = parser.add_argument_group("remote test_data fallback")
    remote.add_argument("--remote-host", default=_DEFAULT_REMOTE_HOST)
    remote.add_argument("--remote-port", type=int, default=_DEFAULT_REMOTE_PORT)
    remote.add_argument(
        "--remote-user",
        default=None,
        help="SSH user (default: use ~/.ssh/config or the local username)",
    )
    remote.add_argument("--remote-root", default=_DEFAULT_REMOTE_ROOT)
    remote.add_argument(
        "--replay-data-dir",
        type=Path,
        default=_DEFAULT_REPLAY_DATA,
        help=f"Download cache root (default: {_DEFAULT_REPLAY_DATA})",
    )
    remote.add_argument(
        "--refresh-remote",
        action="store_true",
        help="Re-run per-episode rsync even when a completed cache exists",
    )
    remote.add_argument(
        "--no-remote-fetch",
        action="store_true",
        help="Fail instead of using SSH when test_data is absent locally",
    )
    remote.add_argument(
        "--ssh-interactive",
        action="store_true",
        help="Allow SSH password/passphrase prompts (default: BatchMode=yes)",
    )
    remote.add_argument("--ssh-connect-timeout", type=int, default=15)
    remote.add_argument(
        "--remote-timeout",
        type=float,
        default=120.0,
        help="Remote directory-search timeout in seconds (default: 120)",
    )
    remote.add_argument(
        "--remote-prefetch-count",
        type=int,
        default=5,
        help=(
            "Maximum active/downloaded remote episodes, automatically raised "
            "to the GPU worker count to avoid idle GPUs (default: 5)"
        ),
    )
    remote.add_argument(
        "--keep-remote-cache",
        action="store_true",
        help="Keep successfully processed episodes in --replay-data-dir",
    )
    remote.add_argument(
        "--remote-output-root",
        default=None,
        help=(
            "Upload each completed episode directory directly under this "
            "absolute path on --remote-host"
        ),
    )
    remote.add_argument(
        "--keep-local-output",
        action="store_true",
        help="Keep local episode outputs after verified remote upload",
    )
    parser.add_argument("--num-per-folder", type=int, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--random-seed", type=int, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--move-from-start", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--initial_position",
        "--intial_position",
        nargs=3,
        type=float,
        default=None,
        metavar=("X", "Y", "Z"),
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--move-from-start-inpaint-background",
        action="store_true",
        help=(
            "Run SAM 3.1 + EffectErase on all three ramp backgrounds; disabled "
            "by default because it adds tens of minutes per episode"
        ),
    )
    parser.add_argument("--force-remote-lookup", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--replay-args",
        nargs=argparse.REMAINDER,
        default=[],
        help="Arguments forwarded to wuji_replay; must be last",
    )
    args, unknown = parser.parse_known_args(values)
    args.root = positional_root
    return args, [*unknown, *args.replay_args]


def _validate_args(args: argparse.Namespace) -> None:
    if args.root is not None and args.test_data is not None:
        raise ValueError("Use either positional root or --test_data, not both")
    if args.root is None and args.test_data is None:
        if args.config is None:
            raise ValueError("Provide --config, positional test data, or --test_data")
    if args.num_per_folder is not None and args.num_per_folder < 1:
        raise ValueError("--num-per-folder must be >= 1")
    for option in ("gpu_memory_per_worker_gb", "gpu_memory_reserve_gb"):
        value = getattr(args, option)
        if not math.isfinite(value) or value < 0.0:
            raise ValueError(f"--{option.replace('_', '-')} must be non-negative")
    if args.gpu_memory_per_worker_gb == 0.0:
        raise ValueError("--gpu-memory-per-worker-gb must be positive")
    if args.max_workers_per_gpu < 1:
        raise ValueError("--max-workers-per-gpu must be >= 1")
    if args.fused_fk_microbatch_wait_us < 0:
        raise ValueError("--fused-fk-microbatch-wait-us must be >= 0")
    if args.ik_failure_limit < 0:
        raise ValueError("--ik-failure-limit must be >= 0")
    if args.interpolation_candidate_count < 1:
        raise ValueError("--interpolation-candidate-count must be >= 1")
    if args.rife_batch_size < 1:
        raise ValueError("--rife-batch-size must be >= 1")
    if (
        not math.isfinite(args.interpolation_output_fps)
        or args.interpolation_output_fps <= 0.0
    ):
        raise ValueError("--interpolation-output-fps must be finite and positive")
    for option in (
        "interpolation_max_velocity",
        "interpolation_max_hand_velocity",
        "interpolation_max_acceleration",
        "interpolation_max_hand_acceleration",
        "interpolation_minimum_playback_rate",
        "interpolation_maximum_playback_rate",
    ):
        value = getattr(args, option)
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(
                f"--{option.replace('_', '-')} must be finite and positive"
            )
    if args.skip_existing and args.overwrite:
        raise ValueError("Use either --skip-existing or --overwrite, not both")
    if args.initial_position is not None:
        if len(args.initial_position) != 3 or any(
            not math.isfinite(float(value)) for value in args.initial_position
        ):
            raise ValueError("--initial_position must be three finite metres")
    if not 1 <= args.remote_port <= 65535:
        raise ValueError("--remote-port must be in [1, 65535]")
    if args.ssh_connect_timeout < 1:
        raise ValueError("--ssh-connect-timeout must be >= 1")
    if not math.isfinite(args.remote_timeout) or args.remote_timeout <= 0.0:
        raise ValueError("--remote-timeout must be positive")
    if args.remote_prefetch_count < 1:
        raise ValueError("--remote-prefetch-count must be >= 1")
    if args.remote_output_root is not None and not PurePosixPath(
        args.remote_output_root
    ).is_absolute():
        raise ValueError("--remote-output-root must be an absolute POSIX path")
    for option in ("output_name", "log_name"):
        value = Path(getattr(args, option))
        if value.name != str(value) or value.name in {"", ".", ".."}:
            raise ValueError(f"--{option.replace('_', '-')} must be a filename")


def _configure_logging(root: Path) -> Path:
    _ensure_world_writable_dir(root)
    path = root / "batch_replay.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.StreamHandler(),
            _ResilientFileHandler(path, mode="w"),
        ],
        force=True,
    )
    _chmod_world_writable(path)
    return path


def _write_topic_indexes(
    topic_root: Path,
    results: Sequence[EpisodeResult],
    *,
    captured_instructions: Mapping[str, object] | None = None,
    captured_instruction_meta: Mapping[str, object] | None = None,
) -> None:
    successful = {
        result.episode
        for result in results
        if result.status in {"completed", "skipped"}
    }
    instructions: dict[str, object] = {
        key: value
        for key, value in (captured_instructions or {}).items()
        if key in successful
    }
    instruction_meta: dict[str, object] = {
        key: value
        for key, value in (captured_instruction_meta or {}).items()
        if key in successful
    }
    for result in results:
        if result.status not in {"completed", "skipped"}:
            continue
        episode_root = topic_root / result.episode
        instruction_path = episode_root / data_format.INSTRUCTION_NAME
        if instruction_path.is_file():
            payload = json.loads(instruction_path.read_text(encoding="utf-8"))
            if isinstance(payload, Mapping) and result.episode in payload:
                instructions[result.episode] = payload[result.episode]
        meta_path = episode_root / data_format.INSTRUCTION_META_NAME
        if meta_path.is_file():
            payload = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(payload, Mapping) and result.episode in payload:
                instruction_meta[result.episode] = payload[result.episode]
    data_format.atomic_write_bytes(
        topic_root / data_format.INSTRUCTION_NAME,
        data_format.dump_readable_json(instructions),
    )
    if instruction_meta:
        data_format.atomic_write_bytes(
            topic_root / data_format.INSTRUCTION_META_NAME,
            data_format.dump_readable_json(instruction_meta),
        )
    _chmod_tree_world_writable(topic_root)


def _format_ik_table(
    results: Sequence[EpisodeResult], failures: Sequence[tuple[str, str]]
) -> str:
    rows: list[list[str]] = []
    for result in results:
        rate = (
            f"{100.0 * result.ik_successes / result.ik_total:.2f}%"
            if result.ik_total
            else "n/a"
        )
        rows.append(
            [
                result.episode,
                result.status,
                result.device,
                f"{result.ik_successes}/{result.ik_total}",
                str(result.ik_failures),
                rate,
                f"{result.duration_seconds:.1f}",
            ]
        )
    rows.extend([episode, "error", "-", "0/0", "-", "n/a", "-"] for episode, _ in failures)
    headers = ["episode", "status", "device", "IK success", "IK failed", "rate", "seconds"]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        if rows
        else len(headers[index])
        for index in range(len(headers))
    ]
    separator = "+" + "+".join("-" * (width + 2) for width in widths) + "+"

    def format_row(row: Sequence[str]) -> str:
        return "|" + "|".join(
            f" {value:<{width}} " for value, width in zip(row, widths)
        ) + "|"

    lines = [separator, format_row(headers), separator]
    lines.extend(format_row(row) for row in rows)
    lines.append(separator)
    successes = sum(result.ik_successes for result in results)
    total = sum(result.ik_total for result in results)
    rate = 100.0 * successes / total if total else float("nan")
    lines.append(
        f"TOTAL episodes={len(results)}, processing_errors={len(failures)}, "
        f"IK={successes}/{total} ({rate:.2f}%)"
    )
    lines.append(_format_runtime_summary(results, wall_seconds=None))
    return "\n".join(lines)


def _format_runtime_summary(
    results: Sequence[EpisodeResult], *, wall_seconds: float | None
) -> str:
    """Format cumulative IK and trajectory timing metrics for batch logs."""

    completed = [result for result in results if result.status == "completed"]
    total_solve_seconds = sum(
        result.trajectory_solve_seconds for result in completed
    )
    average_solve_seconds = (
        total_solve_seconds / len(completed) if completed else 0.0
    )
    total_episode_seconds = sum(result.duration_seconds for result in completed)
    average_episode_seconds = (
        total_episode_seconds / len(completed) if completed else 0.0
    )
    successes = sum(result.ik_successes for result in results)
    ik_total = sum(result.ik_total for result in results)
    ik_rate = 100.0 * successes / ik_total if ik_total else float("nan")
    wall_text = (
        "n/a" if wall_seconds is None else f"{max(0.0, wall_seconds):.1f}s"
    )
    return (
        f"RUNTIME completed={len(completed)}, "
        f"IK_success_rate={successes}/{ik_total} ({ik_rate:.2f}%), "
        f"trajectory_solve_avg={average_solve_seconds:.1f}s, "
        f"trajectory_solve_total={total_solve_seconds:.1f}s, "
        f"episode_end_to_end_avg={average_episode_seconds:.1f}s, "
        f"episode_end_to_end_total={total_episode_seconds:.1f}s, "
        f"batch_wall_total={wall_text}"
    )


def _summary_payload(
    *,
    root: Path,
    slots: Mapping[str, int],
    results: Sequence[EpisodeResult],
    failures: Sequence[tuple[str, str]],
    invalid: Sequence[Path],
) -> dict[str, object]:
    return {
        "root": str(root),
        "gpu_slots": dict(slots),
        "results": [asdict(result) for result in results],
        "failures": [
            {"episode": episode, "error": error} for episode, error in failures
        ],
        "invalid_subdirectories": [path.name for path in invalid],
    }


def _without_config_option(values: Sequence[str]) -> list[str]:
    """Remove exactly one --config option while preserving all other CLI text."""

    result: list[str] = []
    skip_next = False
    removed = False
    for value in values:
        if skip_next:
            skip_next = False
            continue
        if not removed and value == "--config":
            removed = True
            skip_next = True
            continue
        if not removed and value.startswith("--config="):
            removed = True
            continue
        result.append(value)
    if skip_next:
        raise ValueError("--config requires a YAML path")
    return result


def _with_batch_child_options(
    values: Sequence[str], config: BatchYamlConfig, folder: str
) -> list[str]:
    local_folder = Path(folder).expanduser().is_dir()
    options = [
        "--test_data", folder,
        "--interpolation-output-fps", str(config.fps),
    ]
    if local_folder:
        # The same YAML is intentionally usable both on the data server and on
        # a separate inference host.  On the server, do not SSH back into the
        # current machine: read and publish through the mounted paths directly.
        options.extend(("--output-root", config.output))
    else:
        options.extend(
            (
                "--remote-output-root",
                config.output,
                "--force-remote-lookup",
            )
        )
    if config.num_per_folder is not None and "--num-per-folder" not in values:
        options.extend(("--num-per-folder", str(config.num_per_folder)))
    if config.random_seed is not None:
        options.extend(("--random-seed", str(config.random_seed)))
    if config.move_from_start:
        options.append("--move-from-start")
    if config.thumb_table_clearance_m is not None:
        options.extend(("--thumb_table_clearance_m", str(config.thumb_table_clearance_m)))
    left_glove = config.left_glove_urdf or config.left_hand_urdf
    right_glove = config.right_glove_urdf or config.right_hand_urdf
    # Always forward YAML glove URDFs, including empty → SDK builtin_default.
    # Do not inherit left_urdf / right_urdf from model_config.
    options.extend(("--left_glove_urdf", left_glove or ""))
    options.extend(("--right_glove_urdf", right_glove or ""))
    if config.grasp_type is not None:
        options.extend(("--grasp_type", str(config.grasp_type)))
    if config.anchor:
        options.extend(("--anchor", config.anchor))
    elif config.which_to_track:
        options.extend(("--which_to_track", config.which_to_track))
    if config.retarget_weight:
        options.extend(("--retarget_weight", config.retarget_weight))
    if config.initial_position is not None:
        options.extend(
            (
                "--initial_position",
                f"{config.initial_position[0]:.9g}",
                f"{config.initial_position[1]:.9g}",
                f"{config.initial_position[2]:.9g}",
            )
        )
    if config.model_config is not None and not _contains_option(
        values, "--model_config"
    ) and not _contains_option(values, "--model-config"):
        options.extend(("--model_config", config.model_config))
    if not _contains_option(values, "--robot"):
        options.extend(("--robot", config.arm))
    for key, value in (("interpolation-max-velocity", config.interpolation_max_velocity), ("interpolation-max-hand-velocity", config.interpolation_max_hand_velocity), ("interpolation-max-acceleration", config.interpolation_max_acceleration), ("interpolation-max-hand-acceleration", config.interpolation_max_hand_acceleration)):
        if value is not None:
            options.extend((f"--{key}", str(value)))
    result = list(values)
    boundaries = [
        index
        for index, value in enumerate(result)
        if value in {"--", "--replay-args"}
    ]
    insertion = min(boundaries) if boundaries else len(result)
    return [*result[:insertion], *options, *result[insertion:]]


def main(argv: Sequence[str] | None = None) -> int:
    values = list(sys.argv[1:] if argv is None else argv)
    if values and values[0] == "--_inspect-worker":
        if len(values) != 4:
            raise ValueError(
                "--_inspect-worker requires STANDARD_JSON INPUT_MP4 OUTPUT_MP4"
            )
        _inspect_worker(Path(values[1]), Path(values[2]), Path(values[3]))
        return 0
    if values and values[0] == "--_timestamps-worker":
        if len(values) != 5:
            raise ValueError(
                "--_timestamps-worker requires SOURCE_H5 OUTPUT_H5 FPS FRAME_COUNT"
            )
        _timestamps_worker(
            Path(values[1]),
            Path(values[2]),
            fps=float(values[3]),
            frame_count=int(values[4]),
        )
        return 0
    if values and values[0] == "--_trajectory-worker":
        _trajectory_worker_loop()
        return 0
    if values and values[0] == "--_prepend-ramp-worker":
        if len(values) != 3:
            raise ValueError("--_prepend-ramp-worker requires REPLAY_NPZ FPS")
        ramp_frames = _prepend_move_from_start_ramp(
            Path(values[1]), float(values[2])
        )
        print(f"[batch_replay] ramp frames: {ramp_frames}", flush=True)
        return 0
    args, forwarded_values = _parse_args(argv)
    _validate_args(args)
    if args.config is not None:
        if args.root is not None or args.test_data is not None:
            raise ValueError("Do not combine --config with positional/--test_data input")
        if _contains_option(values, "--fps") or _contains_option(
            values, "--interpolation-output-fps"
        ):
            raise ValueError("Set fps in the batch YAML, not on the command line")
        if _contains_option(values, "--remote-output-root"):
            raise ValueError(
                "Set the remote output path with 'output' in the batch YAML, "
                "not --remote-output-root"
            )
        if _contains_option(values, "--robot"):
            raise ValueError("Set the composite preset with 'arm' in the batch YAML, not --robot")
        if _contains_option(values, "--initial_position") or _contains_option(
            values, "--intial_position"
        ):
            raise ValueError(
                "Set the first-frame palm-midpoint target with "
                "'initial_position' in the batch YAML, not --initial_position"
            )
        config = _load_batch_yaml(args.config)
        generation = _hand_generation_for_robot(config.arm)
        print(
            f"[batch_replay] YAML arm={config.arm} "
            f"hand_sdk={'WujiHand2' if generation == 'hand2' else 'WujiHand'} "
            f"retarget_weight={config.retarget_weight}",
            flush=True,
        )
        child_base = _without_config_option(values)
        status = 0
        for index, folder in enumerate(config.folders, start=1):
            print(
                f"[batch_replay] YAML folder {index}/{len(config.folders)}: {folder}",
                flush=True,
            )
            child_values = _with_batch_child_options(child_base, config, folder)
            try:
                status |= main(child_values)
            except Exception as exc:
                status = 1
                print(
                    f"[batch_replay] folder {folder!r} failed: "
                    f"{type(exc).__name__}: {exc}",
                    file=sys.stderr,
                    flush=True,
                )
        return status
    forwarded = _normalise_forwarded_args(forwarded_values)
    if args.retargeting_solver:
        print(
            "[batch_replay] ignoring --retargeting_solver; "
            "finger q uses the pinned wuji-v3 SDK offline pipeline",
            flush=True,
        )
    model_config = _sdk_model_config_path(args.model_config)
    if model_config is not None:
        os.environ.update(_sdk_env_updates(model_config))
    else:
        os.environ.pop("GEORT_WUJI_MODEL_CONFIG", None)
    batch_input = _resolve_batch_input(args)
    root = batch_input.root
    topic_root = args.output_root.expanduser().resolve()
    atexit.register(_remove_leaked_staging_directories, topic_root)
    _remove_leaked_staging_directories(topic_root)
    remote_output_topic = (
        _remote_output_topic_path(args.remote_output_root)
        if args.remote_output_root is not None
        else None
    )

    inventory = _gpu_inventory()
    devices = list(args.devices or [gpu.device for gpu in inventory])
    if not devices:
        raise RuntimeError(
            "No visible NVIDIA GPU found; pass --devices cuda:0 (or explicit devices)"
        )
    if len(set(devices)) != len(devices):
        raise ValueError("--devices contains duplicates")
    gpus = _selected_gpu_info(devices)
    slots = _slot_counts(args, gpus)
    if not any(slots.values()):
        raise RuntimeError(
            "No selected GPU has enough free memory for an automatic worker; "
            "reduce --gpu-memory-per-worker-gb/--gpu-memory-reserve-gb or "
            "wait for GPU memory to become available"
        )
    if batch_input.streams_remote_episodes:
        episodes = [root / name for name in batch_input.remote_episode_names]
        invalid: list[Path] = []
    else:
        episodes, invalid = _discover_episodes(root)
    available_episode_count = len(episodes)
    episodes = _sample_episodes(
        episodes,
        args.num_per_folder,
        seed=args.random_seed,
        folder_name=root.name,
    )
    if not episodes:
        raise RuntimeError(
            f"No child directory containing an episode JSON found in {root}"
        )

    batch_log = _configure_logging(topic_root)
    batch_started = time.monotonic()
    if (
        args.num_per_folder is not None
        and args.num_per_folder >= available_episode_count
    ):
        _LOG.info(
            "num_per_folder=%d is at least the %d available episodes; "
            "processing every episode in %s",
            args.num_per_folder,
            available_episode_count,
            root.name,
        )
    remote_complete_names: set[str] = set()
    if remote_output_topic is not None and args.skip_existing and not args.dry_run:
        remote_complete_names = _remote_complete_output_names(
            remote_output_topic, args
        )
        _LOG.info(
            "Found %d complete episodes at remote output %s:%s",
            len(remote_complete_names),
            _ssh_target(args.remote_host, args.remote_user),
            remote_output_topic,
        )
    for path in invalid:
        _LOG.warning("Skipping %s: no *.json or *.json.obdownload", path.name)
    generation = _hand_generation_for_robot(args.robot)
    _LOG.info(
        "Discovered %d episodes; GPU slots=%s; arm=%s; hand_sdk=%s; "
        "wuji_sdk_model_config=%s; forwarded args=%s",
        len(episodes),
        slots,
        args.robot,
        "WujiHand2" if generation == "hand2" else "WujiHand",
        model_config or "glove URDF",
        shlex.join(forwarded) if forwarded else "(none)",
    )
    _LOG.info("Standard output topic: %s", topic_root)
    for gpu in gpus:
        memory = (
            "unknown"
            if gpu.free_mib is None
            else f"{gpu.free_mib / 1024.0:.2f} GiB"
        )
        _LOG.info(
            "%s: free memory=%s, concurrent workers=%d",
            gpu.device,
            memory,
            slots[gpu.device],
        )

    slot_queue: Queue[str] = Queue()
    # Interleave devices so a batch smaller than the total slot count still
    # spreads over all GPUs instead of filling the first GPU exclusively.
    for slot_index in range(max(slots.values())):
        for device, count in slots.items():
            if slot_index < count:
                slot_queue.put(device)
    total_workers = min(len(episodes), slot_queue.qsize())
    cpu_threads = min(
        8, max(1, (os.cpu_count() or 1) // max(1, total_workers))
    )
    if args.trajectory_execution == "inprocess" and not args.dry_run:
        # Concurrent episode threads must not swap the process-wide stdout;
        # route prints through a thread-local log handle instead.
        _install_thread_local_output_routers()
        # Torch is imported on the first episode, not here. Reloading it
        # for every trajectory was the extra ~2 s in subprocess mode.
        os.environ["GEORT_FUSED_FK_BATCH_SIZE"] = str(max(slots.values()))
        os.environ["GEORT_FUSED_FK_WAIT_US"] = str(
            args.fused_fk_microbatch_wait_us
        )
        os.environ.setdefault("OMP_NUM_THREADS", str(cpu_threads))
        os.environ.setdefault("MKL_NUM_THREADS", str(cpu_threads))
        os.environ.setdefault("OPENBLAS_NUM_THREADS", str(cpu_threads))
        _LOG.info(
            "In-process trajectory runtime: lazy Torch import, workers=%d, "
            "CPU threads=%d",
            total_workers,
            cpu_threads,
        )
        # Warp's wp.init() builds the CUDA runtime when `runtime is None`,
        # with no lock. The ramp warmup thread and the episode workers all
        # hit that path together and segfault. Initialize once here, before
        # either of those threads starts.
        import warp as wp

        wp.init()
    elif args.trajectory_execution == "subprocess" and not args.dry_run:
        _LOG.info(
            "Persistent trajectory workers: one long-lived process per GPU "
            "slot; Torch is imported on the first episode"
        )
    if args.move_from_start and not args.dry_run:
        threading.Thread(
            target=_warmup_ramp_modules, name="warmup-ramp", daemon=True
        ).start()

    rife_workers: dict[str, _PersistentRifeWorker] = {}
    if (
        args.interpolation_execution == "inprocess"
        and args.interpolation_backend == "rife"
        and not args.dry_run
    ):
        # Construct lightweight handles now; each handle loads its model on
        # first use and retains it for every subsequent episode on that GPU.
        # The per-GPU lock prevents concurrent RIFE calls from creating several
        # copies of the model when workers-per-gpu is greater than one.
        _install_thread_local_output_routers()
        rife_workers = {
            gpu.device: _PersistentRifeWorker(
                gpu.device,
                scale=args.rife_scale,
                fp16=args.rife_fp16,
                batch_size=args.rife_batch_size,
            )
            for gpu in gpus
        }
        _LOG.info(
            "Persistent RIFE workers enabled for %s",
            ", ".join(sorted(rife_workers)),
        )

    def run_with_available_gpu(episode: Path) -> EpisodeResult:
        device = slot_queue.get()
        try:
            _LOG.info("Starting %s on %s", episode.name, device)
            return _run_episode(
                episode,
                device=device,
                gpu_selector=next(
                    gpu.selector for gpu in gpus if gpu.device == device
                ),
                forwarded=forwarded,
                output_root=topic_root,
                log_name=args.log_name,
                skip_existing=args.skip_existing,
                overwrite=args.overwrite,
                dry_run=args.dry_run,
                trajectory_execution=args.trajectory_execution,
                interpolation_execution=args.interpolation_execution,
                rife_worker=rife_workers.get(device),
                cpu_threads=cpu_threads,
                ik_failure_limit=args.ik_failure_limit,
                interpolation_backend=args.interpolation_backend,
                interpolation_output_fps=args.interpolation_output_fps,
                interpolation_candidate_count=args.interpolation_candidate_count,
                interpolation_pose_method=args.interpolation_pose_method,
                interpolation_max_velocity=args.interpolation_max_velocity,
                interpolation_max_hand_velocity=args.interpolation_max_hand_velocity,
                interpolation_max_acceleration=args.interpolation_max_acceleration,
                interpolation_max_hand_acceleration=(
                    args.interpolation_max_hand_acceleration
                ),
                interpolation_minimum_playback_rate=(
                    args.interpolation_minimum_playback_rate
                ),
                interpolation_maximum_playback_rate=(
                    args.interpolation_maximum_playback_rate
                ),
                rife_batch_size=args.rife_batch_size,
                rife_scale=args.rife_scale,
                rife_fp16=args.rife_fp16,
                move_from_start=args.move_from_start,
                move_from_start_inpaint_background=(
                    args.move_from_start_inpaint_background
                ),
                composite_urdf=_composite_urdf_for_robot(args.robot),
                collision_config=_collision_config_for_robot(args.robot),
                generation=_hand_generation_for_robot(args.robot),
                initial_position=args.initial_position,
            )
        finally:
            slot_queue.put(device)

    results: list[EpisodeResult] = []
    failures: list[tuple[str, str]] = []
    prefetch_window = (
        min(len(episodes), max(args.remote_prefetch_count, total_workers))
        if batch_input.streams_remote_episodes
        else len(episodes)
    )
    if batch_input.streams_remote_episodes:
        _LOG.info(
            "Remote streaming enabled: requested prefetch=%d, active window=%d, "
            "cleanup=%s",
            args.remote_prefetch_count,
            prefetch_window,
            "disabled" if args.keep_remote_cache else "after successful episode",
        )

    def collection_index(filename: str) -> dict[str, object]:
        path = root / filename
        if not path.is_file():
            return {}
        payload = json.loads(path.read_text(encoding="utf-8"))
        return dict(payload) if isinstance(payload, Mapping) else {}

    captured_instructions = collection_index(data_format.INSTRUCTION_NAME)
    captured_instruction_meta = collection_index(data_format.INSTRUCTION_META_NAME)

    def capture_episode_indexes(local_episode: Path, episode_name: str) -> None:
        for filename, destination in (
            (data_format.INSTRUCTION_NAME, captured_instructions),
            (data_format.INSTRUCTION_META_NAME, captured_instruction_meta),
        ):
            path = local_episode / filename
            if not path.is_file():
                continue
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, Mapping) and episode_name in payload:
                destination[episode_name] = payload[episode_name]

    def prepare_episode(episode: Path) -> Path:
        if not batch_input.streams_remote_episodes or args.dry_run:
            return episode
        if args.skip_existing and _is_complete_episode_directory(
            topic_root / episode.name
        ):
            return episode
        if batch_input.remote_path is None:  # narrowed by streams_remote_episodes
            raise RuntimeError("Remote batch input has no remote collection path")
        return _download_remote_episode(
            batch_input.remote_path,
            episode.name,
            root,
            args,
        )

    def clean_completed_cache(
        episode: Path, result: EpisodeResult, *, output_verified: bool
    ) -> None:
        if (
            not batch_input.streams_remote_episodes
            or args.keep_remote_cache
            or args.dry_run
            or result.status not in {"completed", "skipped"}
            or not episode.is_dir()
        ):
            return
        if not output_verified:
            raise RuntimeError(
                f"Refusing to clean {episode}: published output was not verified"
            )
        _cleanup_remote_episode_cache(episode, root)
        _LOG.info("Cleaned remote episode cache: %s", episode)

    episode_iterator = iter(episodes)
    completed_count = 0
    exhausted = False
    with ThreadPoolExecutor(max_workers=total_workers) as executor:
        futures: dict[Future[EpisodeResult], Path] = {}
        with tqdm(
            total=len(episodes), desc="batch replay", unit="episode", dynamic_ncols=True
        ) as progress:

            def fill_prefetch_window() -> None:
                nonlocal completed_count, exhausted
                while not exhausted and len(futures) < prefetch_window:
                    try:
                        requested_episode = next(episode_iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    if requested_episode.name in remote_complete_names:
                        if remote_output_topic is None:
                            raise RuntimeError("Remote skip has no output topic")
                        completed_count += 1
                        remote_episode = remote_output_topic / requested_episode.name
                        target = _ssh_target(args.remote_host, args.remote_user)
                        results.append(
                            EpisodeResult(
                                episode=requested_episode.name,
                                output=(
                                    f"{target}:{remote_episode}/"
                                    f"{data_format.episode_json_name(requested_episode.name)}"
                                ),
                                log=f"{target}:{remote_episode}/{args.log_name}",
                                device="remote",
                                status="skipped",
                                duration_seconds=0.0,
                                interpolated_videos=tuple(
                                    f"{target}:{remote_episode}/{name}"
                                    for name in _SOURCE_VIDEO_NAMES
                                ),
                            )
                        )
                        if (
                            batch_input.streams_remote_episodes
                            and not args.keep_remote_cache
                            and requested_episode.is_dir()
                            and (requested_episode / _REMOTE_EPISODE_MARKER).is_file()
                        ):
                            _cleanup_remote_episode_cache(requested_episode, root)
                        _LOG.info(
                            "[%d/%d] skipped complete remote output %s",
                            completed_count,
                            len(episodes),
                            requested_episode.name,
                        )
                        progress.set_postfix_str(
                            f"skipped={requested_episode.name}", refresh=False
                        )
                        progress.update()
                        continue
                    try:
                        prepared_episode = prepare_episode(requested_episode)
                    except Exception as exc:
                        completed_count += 1
                        error = f"DownloadError: {type(exc).__name__}: {exc}"
                        failures.append((requested_episode.name, error))
                        _LOG.error(
                            "[%d/%d] FAILED download %s: %s",
                            completed_count,
                            len(episodes),
                            requested_episode.name,
                            error,
                        )
                        progress.set_postfix_str(
                            f"download_error={requested_episode.name}", refresh=False
                        )
                        progress.update()
                        continue
                    future = executor.submit(
                        run_with_available_gpu, prepared_episode
                    )
                    futures[future] = prepared_episode

            fill_prefetch_window()
            while futures:
                done, _ = wait(tuple(futures), return_when=FIRST_COMPLETED)
                for future in done:
                    episode = futures.pop(future)
                    completed_count += 1
                    try:
                        result = future.result()
                    except Exception as exc:  # independent episodes keep running
                        error = f"{type(exc).__name__}: {exc}"
                        failures.append((episode.name, error))
                        _LOG.error(
                            "[%d/%d] FAILED %s: %s",
                            completed_count,
                            len(episodes),
                            episode.name,
                            error,
                        )
                        if batch_input.streams_remote_episodes and episode.is_dir():
                            try:
                                _cleanup_remote_episode_cache(episode, root)
                            except Exception as cleanup_exc:
                                _LOG.error("Failed to remove failed cache %s: %s", episode, cleanup_exc)
                        progress.set_postfix_str(
                            f"error={episode.name}", refresh=False
                        )
                    else:
                        _LOG.info(
                            "[%d/%d] %s %s on %s in %.1fs; IK=%d/%d -> %s",
                            completed_count,
                            len(episodes),
                            result.status,
                            result.episode,
                            result.device,
                            result.duration_seconds,
                            result.ik_successes,
                            result.ik_total,
                            result.output,
                        )
                        published_result = result
                        output_verified = False
                        publication_ok = True
                        if result.status in {"completed", "skipped"}:
                            local_output_episode = topic_root / episode.name
                            output_verified = _is_complete_episode_directory(
                                local_output_episode
                            )
                            if output_verified:
                                capture_episode_indexes(
                                    local_output_episode, episode.name
                                )
                            if remote_output_topic is not None:
                                try:
                                    remote_episode = _upload_remote_episode_output(
                                        local_output_episode,
                                        remote_output_topic,
                                        args,
                                    )
                                    target = _ssh_target(
                                        args.remote_host, args.remote_user
                                    )
                                    published_result = replace(
                                        result,
                                        output=(
                                            f"{target}:{remote_episode}/"
                                            f"{data_format.episode_json_name(episode.name)}"
                                        ),
                                        log=f"{target}:{remote_episode}/{args.log_name}",
                                        interpolated_videos=tuple(
                                            f"{target}:{remote_episode}/{name}"
                                            for name in _SOURCE_VIDEO_NAMES
                                        ),
                                    )
                                    output_verified = True
                                    _LOG.info(
                                        "Uploaded and verified remote output: %s:%s",
                                        target,
                                        remote_episode,
                                    )
                                    if not args.keep_local_output:
                                        _cleanup_local_episode_output(
                                            local_output_episode, topic_root
                                        )
                                        _LOG.info(
                                            "Cleaned local episode output: %s",
                                            local_output_episode,
                                        )
                                except Exception as exc:
                                    publication_ok = False
                                    output_verified = False
                                    error = (
                                        f"RemoteUploadError: {type(exc).__name__}: {exc}"
                                    )
                                    failures.append((episode.name, error))
                                    _LOG.error("%s", error)
                        results.append(published_result)
                        _LOG.info(
                            "%s",
                            _format_runtime_summary(
                                results,
                                wall_seconds=time.monotonic() - batch_started,
                            ),
                        )
                        if publication_ok:
                            try:
                                clean_completed_cache(
                                    episode,
                                    result,
                                    output_verified=output_verified,
                                )
                            except Exception as exc:
                                error = (
                                    f"CacheCleanupError: {type(exc).__name__}: {exc}"
                                )
                                failures.append((episode.name, error))
                                _LOG.error("%s", error)
                        progress.set_postfix_str(
                            (
                                f"{result.status}={episode.name}"
                                if publication_ok
                                else f"upload_error={episode.name}"
                            ),
                            refresh=False,
                        )
                    progress.update()
                fill_prefetch_window()

    results.sort(key=lambda item: item.episode)
    failures.sort()
    if not args.dry_run:
        _write_topic_indexes(
            topic_root,
            results,
            captured_instructions=captured_instructions,
            captured_instruction_meta=captured_instruction_meta,
        )
    summary_path = topic_root / "batch_replay_summary.json"
    summary_path.write_text(
        json.dumps(
            _summary_payload(
                root=topic_root,
                slots=slots,
                results=results,
                failures=failures,
                invalid=invalid,
            ),
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    _LOG.info(
        "Finished: %d succeeded/skipped, %d failed; summary=%s; log=%s",
        len(results),
        len(failures),
        summary_path,
        batch_log,
    )
    _LOG.info(
        "%s",
        _format_runtime_summary(
            results, wall_seconds=time.monotonic() - batch_started
        ),
    )
    table = _format_ik_table(results, failures)
    tqdm.write("\nIK success summary\n" + table)
    with (topic_root / "ik_success_table.txt").open("w", encoding="utf-8") as handle:
        handle.write(table + "\n")
    if remote_output_topic is not None and not args.dry_run:
        for handler in logging.getLogger().handlers:
            try:
                handler.flush()
            except OSError:
                continue
        try:
            _upload_remote_topic_files(topic_root, remote_output_topic, args)
        except Exception as exc:
            _LOG.error("Remote topic metadata upload failed: %s", exc)
            _remove_leaked_staging_directories(topic_root)
            return 1
    _remove_leaked_staging_directories(topic_root)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
